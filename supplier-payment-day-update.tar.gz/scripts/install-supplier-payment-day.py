from pathlib import Path
import sys

payload = Path(__file__).resolve().parent.parent
root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
before = payload / 'outputs/price-patch-check'

def read(base, name):
    return (base / name).read_text(encoding='utf-8')

def section(text, start, end):
    if text.count(start) != 1:
        raise SystemExit('Ambiguous API anchor; no changes made')
    a = text.index(start)
    b = text.find(end, a)
    if b < 0:
        raise SystemExit('Missing API end anchor; no changes made')
    return text[a:b]

api = 'apps/api/src/main.ts'
web = 'apps/web/src/purchase-control.tsx'
api_old, api_new, api_target = (read(p, api) for p in (before, payload, root))
start, end = "  @Post('payments') async pay", "  @Get('orders')"
old_method = section(api_old, start, end)
new_method = section(api_new, start, end)
if api_target.count(old_method) != 1:
    raise SystemExit('Live supplier payment differs from expected baseline; no changes made')
api_result = api_target.replace(old_method, new_method, 1)

web_old, web_new, web_target = (read(p, web) for p in (before, payload, root))
anchors = ['  const [paymentForm,', '  const pay=async', '  const openPay=', '    {paymentForm&&']
for anchor in anchors:
    old = [line for line in web_old.splitlines() if line.startswith(anchor)]
    new = [line for line in web_new.splitlines() if line.startswith(anchor)]
    if len(old) != 1 or len(new) != 1 or web_target.count(old[0]) != 1:
        raise SystemExit('Live payment form differs from expected baseline; no changes made')
    web_target = web_target.replace(old[0], new[0], 1)

(root / api).write_text(api_result, encoding='utf-8')
(root / web).write_text(web_target, encoding='utf-8')
print('Supplier payment date update installed')
