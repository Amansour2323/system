const base = process.env.E2E_BASE_URL;
if (process.env.E2E_ALLOW_MUTATIONS !== '1') throw new Error('Refusing to write: set E2E_ALLOW_MUTATIONS=1 only for the isolated E2E database.');
if (!base || !/^http:\/\/(localhost|127\.0\.0\.1):3001\/?$/.test(base)) throw new Error('Mutating E2E is restricted to the isolated API at http://localhost:3001.');

const email = process.env.E2E_OWNER_EMAIL || 'owner@draft-e2e.local';
const password = process.env.E2E_OWNER_PASSWORD || 'E2E-Only-Password-123!';
const assert = (condition, message) => { if (!condition) throw new Error(message); };
let activeToken;
let activeRefreshToken;
const send = (path, { token, body, method }) => fetch(`${base}${path}`, {
    method,
    headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...(token ? { authorization: `Bearer ${token}` } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
const read = async response => {
  const text = await response.text();
  let data;
  try { data = text ? JSON.parse(text) : undefined; } catch { data = text; }
  return data;
};
const rotateTokens = async oldRefreshToken => {
  const response = await send('/auth/refresh', { method: 'POST', body: { refreshToken: oldRefreshToken } });
  const data = await read(response);
  assert(response.ok && data.accessToken && data.refreshToken && data.refreshToken !== oldRefreshToken, `refresh token rotation failed: ${JSON.stringify(data)}`);
  activeToken = data.accessToken;
  activeRefreshToken = data.refreshToken;
  return data;
};
const call = async (path, { token: suppliedToken, body, method = body ? 'POST' : 'GET' } = {}) => {
  let response = await send(path, { token: activeToken || suppliedToken, body, method });
  let data = await read(response);
  if (response.status === 401 && activeRefreshToken && !path.startsWith('/auth/')) {
    await rotateTokens(activeRefreshToken);
    response = await send(path, { token: activeToken, body, method });
    data = await read(response);
  }
  assert(response.ok, `${method} ${path} failed (${response.status}): ${JSON.stringify(data)}`);
  return data;
};

const login = await call('/auth/login', { body: { email, password } });
activeToken = login.accessToken;
activeRefreshToken = login.refreshToken;
const originalRefreshToken = login.refreshToken;
const token = login.accessToken;
const warehouse = await call('/pos/context', { token });
const registers = await call('/drawer/registers', { token });
assert(registers.length, 'test seed has no register');
const suffix = `${Date.now()}-${Math.floor(Math.random() * 10000)}`;
const category = await call('/catalog/categories', { token, body: { name: `E2E-${suffix}` } });
const supplier = await call('/purchases/suppliers', { token, body: { name: `E2E Supplier ${suffix}` } });
const product = await call('/catalog/products', { token, body: {
  name: `E2E Product ${suffix}`, sku: `E2E-${suffix}`, categoryId: category.id, supplierId: supplier.id,
  variants: [
    { name: 'Standard', barcode: `E2E${suffix}`, price: 100, cost: 40, openingQty: 10, warehouseId: warehouse.warehouseId },
    { name: 'Large', barcode: `E2EL${suffix}`, price: 100, cost: 40, openingQty: 5, warehouseId: warehouse.warehouseId },
  ],
} });
const variantId = product.variants[0].id;
const replacementVariantId = product.variants[1].id;

// These checks run only against the explicitly isolated E2E database above.
const historicalDay = '2001-02-03';
const historicalSupplier = await call('/purchases/suppliers', { token, body: { name: `E2E Historical Supplier ${suffix}` } });
const historicalProduct = await call('/catalog/products', { token, body: {
  name: `E2E Historical ${suffix}`, sku: `HIST-${suffix}`, supplierId: historicalSupplier.id,
  variants: [{ name: 'Standard', barcode: `HIST${suffix}`, price: 15, cost: 10, openingQty: 0, warehouseId: warehouse.warehouseId }],
} });
const historicalDeposit = await call('/drawer/safe/deposit', { token, body: { amount: 20, paymentMethod: 'CASH', reason: 'E2E historical funding', businessDay: historicalDay, source: 'OWNER_CAPITAL' } });
assert(historicalDeposit.businessDate.slice(0, 10) === historicalDay, 'deposit business date not preserved');
const historicalPurchase = await call('/purchases', { token, body: {
  supplierId: historicalSupplier.id, warehouseId: warehouse.warehouseId, invoiceNo: `HIST-${suffix}`, paymentTerms: 'CREDIT', paid: 10,
  paymentMethod: 'CASH', businessDay: historicalDay,
  items: [{ variantId: historicalProduct.variants[0].id, quantity: 2, unitCost: 10, salePrice: 15 }],
} });
assert(historicalPurchase.businessDate.slice(0, 10) === historicalDay, 'purchase business date not preserved');
await call('/purchases/payments', { token, body: { purchaseId: historicalPurchase.id, amount: 5, method: 'CASH', reference: `Historical payment ${suffix}`, businessDay: historicalDay } });
const historicalRecorded = (await call('/purchases', { token })).find(row => row.id === historicalPurchase.id);
const historicalPayment = historicalRecorded.payments.find(row => Number(row.amount) === 5);
assert(historicalPayment && historicalPayment.businessDate.slice(0, 10) === historicalDay, 'supplier payment business date not preserved');
const invalidEarlyPayment = await send('/purchases/payments', { token, method: 'POST', body: { purchaseId: historicalPurchase.id, amount: 1, method: 'CASH', reference: 'Too early', businessDay: '2001-02-02' } });
assert(invalidEarlyPayment.status === 400, 'payment before invoice date must be rejected');
const historicalEntries = await call('/accounts/journal-entries', { token });
for (const [kind, id] of [['CashMovement', historicalDeposit.id], ['Purchase', historicalPurchase.id], ['SupplierPayment', historicalPayment.id]]) {
  const entry = historicalEntries.find(row => row.referenceType === kind && row.referenceId === id);
  assert(entry && entry.businessDate.slice(0, 10) === historicalDay, `${kind} journal business date not preserved`);
  assert(entry.lines.reduce((sum, line) => sum + Number(line.debit), 0) === entry.lines.reduce((sum, line) => sum + Number(line.credit), 0), `${kind} journal is not balanced`);
  if (kind === 'CashMovement') assert(entry.lines.some(line => line.account.code === '3001' && Number(line.credit) === 20), 'owner capital not credited');
}
const closed = await call('/accounts/periods', { token, body: { name: `E2E closed ${suffix}`, startsAt: '2000-01-01T00:00:00.000Z', endsAt: '2000-12-31T23:59:59.999Z' } });
await call('/accounts/periods/close', { token, body: { periodId: closed.id } });
await rotateTokens(activeRefreshToken);
const rejected = await send('/drawer/safe/deposit', { token: activeToken, method: 'POST', body: { amount: 1, paymentMethod: 'CASH', reason: 'E2E closed period', businessDay: '2000-02-01' } });
assert(rejected.status === 400, `closed-period deposit was not rejected: ${rejected.status}`);

const drawerState = await call('/drawer/overview', { token });
if (drawerState.current) await call('/drawer/close', { token, body: { closingAmount: Number(drawerState.current.expectedAmount || drawerState.current.openingAmount || 0) } });
const opened = await call('/drawer/open', { token, body: { registerId: registers[0].id, openingAmount: 0 } });
const sale = await call('/pos/sales', { token, body: {
  warehouseId: warehouse.warehouseId, paymentMethod: 'CASH', payments: [{ method: 'CARD', amount: 40 }, { method: 'CASH', amount: 60 }],
  discount: 0, idempotencyKey: `e2e-${suffix}-sale`, items: [{ variantId, quantity: 1 }],
} });
assert(Number(sale.total) === 100, 'mixed-tender sale total is incorrect');
const codOrder = await call('/pos/sales', { token, body: {
  warehouseId: warehouse.warehouseId, channel: 'ONLINE', shippingName: `COD ${suffix}`, shippingPhone: '01000000000', shippingAddress: 'عنوان اختبار الشحن، القاهرة',
  payments: [], discount: 0, idempotencyKey: `e2e-${suffix}-shipping-cod`, items: [{ variantId, quantity: 1 }],
} });
assert(codOrder.channel === 'ONLINE' && Number(codOrder.paid) === 0 && Number(codOrder.due) === 100, 'cash-on-delivery order was not recorded as fully due');
const partialOrder = await call('/pos/sales', { token, body: {
  warehouseId: warehouse.warehouseId, channel: 'ONLINE', shippingName: `Partial ${suffix}`, shippingPhone: '01000000001', shippingAddress: 'عنوان اختبار الشحن، الجيزة',
  payments: [{ method: 'VODAFONE_CASH', amount: 40 }], discount: 0, idempotencyKey: `e2e-${suffix}-shipping-partial`, items: [{ variantId, quantity: 1 }],
} });
assert(Number(partialOrder.paid) === 40 && Number(partialOrder.due) === 60, 'partial shipping order payment was not recorded');
const shippingOrders = await call('/pos/shipping-orders', { token });
assert(shippingOrders.some(row => row.id === codOrder.id) && shippingOrders.some(row => row.id === partialOrder.id), 'shipping review page API did not return new orders');
const codOrderForCloseout = shippingOrders.find(row => row.id === codOrder.id);
await call(`/pos/shipping-orders/${codOrder.id}/status`, { token, body: { status: 'PREPARING' } });
await call(`/pos/shipping-orders/${codOrder.id}/status`, { token, body: { status: 'SHIPPED' } });
const failedDelivery = await call(`/pos/shipping-orders/${codOrder.id}/closeout`, { token, body: { reason: 'تعذر التسليم', returnedItems: codOrderForCloseout.items.map(item => ({ saleItemId: item.id, quantity: item.quantity })) } });
assert(failedDelivery.shippingStatus === 'RETURNED' && Number(failedDelivery.due) === 0, 'undelivered COD shipment was not returned and settled');
await call(`/pos/shipping-orders/${partialOrder.id}/status`, { token, body: { status: 'PREPARING' } });
await call(`/pos/shipping-orders/${partialOrder.id}/status`, { token, body: { status: 'SHIPPED' } });
const partialOrderForCloseout = shippingOrders.find(row => row.id === partialOrder.id);
const exchangedAtDelivery = await call(`/pos/shipping-orders/${partialOrder.id}/closeout`, { token, body: { reason: 'تبديل مقاس عند التسليم', returnedItems: [{ saleItemId: partialOrderForCloseout.items[0].id, quantity: 1, replacementVariantId, replacementQuantity: 1 }], payments: [{ method: 'CASH', amount: 60 }] } });
assert(exchangedAtDelivery.shippingStatus === 'DELIVERED' && exchangedAtDelivery.replacementInvoiceNo && Number(exchangedAtDelivery.due) === 0, 'partial size exchange and delivery collection failed');
const settledOrders = await call('/pos/shipping-orders', { token });
const settled = settledOrders.find(row => row.id === partialOrder.id);
assert(Number(settled?.netPaid) === 100 && Number(settled.replacementTotal) === 100 && settled.shippingStatus === 'DELIVERED', 'shipping exchange totals or fulfillment status failed');
const expense = await call('/expenses', { token, body: { category: 'E2E test', description: `E2E expense ${suffix}`, amount: 5, paymentMethod: 'CARD' } });
assert(Number(expense.amount) === 5, 'expense was not recorded');

const count = await call('/inventory/counts', { token, body: { warehouseId: warehouse.warehouseId, scope: 'PRODUCT', productId: product.id } });
await call('/inventory/counts/items', { token, body: { countId: count.id, variantId, countedQuantity: 10 } });
await call('/inventory/counts/items', { token, body: { countId: count.id, variantId: replacementVariantId, countedQuantity: 5 } });
await call('/inventory/counts/submit', { token, body: { countId: count.id } });
const approvedCount = await call('/inventory/counts/approve', { token, body: { countId: count.id } });
assert(approvedCount.status === 'APPROVED', 'inventory count did not reach APPROVED');

const order = await call('/purchases/orders', { token, body: { supplierId: supplier.id, warehouseId: warehouse.warehouseId, items: [{ variantId, quantity: 3, unitCost: 40 }] } });
await call('/purchases/orders/approve', { token, body: { orderId: order.id } });
const receipt = await call('/purchases/orders/receipts', { token, body: { orderId: order.id, invoiceNo: `E2E-${suffix}`, items: [{ variantId, acceptedQuantity: 1, damagedQuantity: 1 }] } });
assert(receipt.damagedQuantity === 1 && receipt.purchase, 'partial receipt with damaged quantity failed');
const ledger = await call('/purchases/ledger', { token });
assert(ledger.some(row => row.id === supplier.id && Number(row.invoiced) === 40), 'supplier balance does not include the partial receipt');

const current = await call('/drawer/current', { token });
assert(current.id === opened.id, 'opened drawer session was not found');
await call('/drawer/close', { token, body: { closingAmount: 60 } });
const stock = await call('/pos/products', { token });
const refreshed = stock.find(row => row.id === variantId);
assert(refreshed?.balances?.some(balance => balance.warehouseId === warehouse.warehouseId && balance.quantity === 11), 'stock did not reconcile after sale, count and partial receipt');

const safeBefore = Number((await call('/drawer/overview', { token })).wallets.CASH || 0);
await call('/drawer/safe/deposit', { token, body: { amount: 500, paymentMethod: 'CASH', reason: `E2E supplier purchase ${suffix}` } });
const safeAfterDeposit = Number((await call('/drawer/overview', { token })).wallets.CASH || 0);
assert(safeAfterDeposit - safeBefore === 500, 'safe cash deposit did not update the cash wallet');
const directInvoice = await call('/purchases', { token, body: {
  supplierId: supplier.id, warehouseId: warehouse.warehouseId, invoiceNo: `DIRECT-${suffix}`, paid: 30, paymentMethod: 'CASH',
  items: [{ variantId, quantity: 2, unitCost: 40, salePrice: 120 }],
} });
assert(Number(directInvoice.total) === 80 && Number(directInvoice.paid) === 30, 'direct purchase invoice totals are wrong');
const safeAfterInvoice = Number((await call('/drawer/overview', { token })).wallets.CASH || 0);
assert(safeAfterDeposit - safeAfterInvoice === 30, 'direct invoice payment was not removed from safe cash');
await call('/purchases/payments', { token, body: { purchaseId: directInvoice.id, amount: 10, method: 'CASH', reference: `E2E partial payment ${suffix}` } });
const safeAfterPayment = Number((await call('/drawer/overview', { token })).wallets.CASH || 0);
assert(safeAfterInvoice - safeAfterPayment === 10, 'later supplier payment was not removed from safe cash');
const supplierReturn = await call('/purchases/returns', { token, body: {
  supplierId: supplier.id, purchaseId: directInvoice.id, warehouseId: warehouse.warehouseId, reason: 'اختبار مرتجع مورد',
  items: [{ variantId, quantity: 1, unitCost: 999 }],
} });
assert(Number(supplierReturn.items[0].unitCost) === 40, 'supplier return did not use the invoice cost');
const refreshedPurchases = await call('/purchases', { token });
const refreshedInvoice = refreshedPurchases.find(row => row.id === directInvoice.id);
assert(Number(refreshedInvoice.outstanding) === 0 && Number(refreshedInvoice.returned) === 40, 'supplier return and payment were not reflected in invoice balance');
const finalSafe = Number((await call('/drawer/overview', { token })).wallets.CASH || 0);
assert(finalSafe === safeAfterPayment, 'supplier return incorrectly changed the safe wallet');
const ledgerAfterDirectPayment = await call('/purchases/ledger', { token });
assert(ledgerAfterDirectPayment.some(row => row.id === supplier.id && Number(row.invoiced) === 120 && Number(row.paid) === 40 && Number(row.returned) === 40 && Number(row.outstanding) === 40), 'supplier ledger totals did not reconcile after invoice, payment and return');

await new Promise(resolve => setTimeout(resolve, 2200));
const expired = await fetch(`${base}/auth/me`, { headers: { authorization: `Bearer ${activeToken}` } });
assert(expired.status === 401, 'short-lived access token did not expire in test environment');
const lastRefreshToken = activeRefreshToken;
await rotateTokens(lastRefreshToken);
await call('/auth/me');
const reusedOldToken = await fetch(`${base}/auth/refresh`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ refreshToken: originalRefreshToken }) });
assert(reusedOldToken.status === 401, 'consumed refresh token was accepted again');

console.log(JSON.stringify({ status: 'passed', checked: ['login-and-refresh-rotation', 'catalog-and-supplier-setup', 'mixed-tender-sale', 'shipping-cash-on-delivery', 'shipping-undelivered-full-return', 'shipping-partial-size-exchange-and-collection', 'expense', 'inventory-count-approval', 'partial-purchase-receipt', 'supplier-ledger', 'drawer-close', 'stock-reconciliation', 'direct-purchase-invoice', 'safe-balance-on-supplier-payment', 'partial-supplier-payment', 'invoice-costed-supplier-return'], isolatedBase: base }));
