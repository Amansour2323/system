from pathlib import Path
import sys
root = Path(sys.argv[1]).resolve()
api = root / 'apps/api/src/main.ts'
web = root / 'apps/web/src/advanced-pos.tsx'
css = root / 'apps/web/src/advanced-pos.css'
a, w, c = [p.read_text(encoding='utf8') for p in (api,web,css)]
def swap(text, before, after, expected=1):
    count = text.count(before)
    if count != expected: raise SystemExit(f'Anchor mismatch, expected {expected}, got {count}: {before[:90]}')
    return text.replace(before,after,expected)
sale_start=a.index("  @Post('sales')")
sale_end=a.index("  @Post('suspended')",sale_start)
block=a[sale_start:sale_end]
block=swap(block,'quantity: z.coerce.number().int().positive(), discount: nonnegativeCurrency.default(0)','quantity: z.coerce.number().int().positive(), unitPrice: positiveCurrency.optional(), discount: nonnegativeCurrency.default(0)')
block=swap(block,'const lineTotal = money(Math.max(0, Number(v.price) * line.quantity - (line.discount ?? 0))); subtotal += lineTotal; return { ...line, unitPrice: Number(v.price),','const unitPrice = line.unitPrice ?? Number(v.price); if (unitPrice < Number(v.price)) throw new BadRequestException(\'سعر البيع أقل من السعر الأساسي؛ استخدم خصم الصنف عند الحاجة\'); const lineTotal = money(Math.max(0, unitPrice * line.quantity - (line.discount ?? 0))); subtotal += lineTotal; return { ...line, unitPrice,')
block=swap(block,'channel: data.channel, total, paid: paidAmount, due, change: money(Math.max(0, tendered - total))','channel: data.channel, total, paid: paidAmount, due, change: money(Math.max(0, tendered - total)), priceOverrides: prepared.filter(line => line.unitPrice !== Number(variants.find(v => v.id === line.variantId)!.price)).map(line => ({ variantId: line.variantId, catalogPrice: Number(variants.find(v => v.id === line.variantId)!.price), salePrice: line.unitPrice }))')
a=a[:sale_start]+block+a[sale_end:]
start=a.index("  @Post('suspended')"); end=a.index("  @Get('suspended')",start); block=a[start:end]
block=swap(block,'quantity: z.coerce.number().int().positive() })).min(1)','quantity: z.coerce.number().int().positive(), unitPrice: positiveCurrency.optional(), discount: nonnegativeCurrency.default(0) })).min(1)')
a=a[:start]+block+a[end:]
replacements=[
('type CartLine = { item: Variant; quantity: number; discount: number };','type CartLine = { item: Variant; quantity: number; discount: number; unitPrice: number };'),
('(sum, line) => sum + Math.max(0, Number(line.item.price) * line.quantity - line.discount),','(sum, line) => sum + Math.max(0, line.unitPrice * line.quantity - line.discount),'),
('{ item, quantity: 1, discount: 0 }','{ item, quantity: 1, discount: 0, unitPrice: Number(item.price) }'),
('    if (!context || !cart.length) return;\n    const receiptWindow','    if (!context || !cart.length) return;\n    if (cart.some(line => !Number.isFinite(line.unitPrice) || line.unitPrice < Number(line.item.price) || Math.abs(line.unitPrice * 100 - Math.round(line.unitPrice * 100)) > 0.00001)) { setNotice(\'أدخل سعر بيع صحيحًا لا يقل عن السعر الأساسي وبحد أقصى منزلتين عشريتين. للخصم استخدم خانة الخصم.\'); return; }\n    const receiptWindow'),
('          discount: line.discount,\n        })),','          discount: line.discount,\n          unitPrice: line.unitPrice,\n        })),'),
('            unitPrice: Number(line.item.price),\n            total: Math.max(0, Number(line.item.price) * line.quantity - line.discount),','            unitPrice: Number(response.data.items?.find((item: any) => item.variantId === line.item.id)?.unitPrice ?? line.unitPrice),\n            total: Number(response.data.items?.find((item: any) => item.variantId === line.item.id)?.total ?? Math.max(0, line.unitPrice * line.quantity - line.discount)),'),
('items: cart.map(line => ({ variantId: line.item.id, quantity: line.quantity })),','items: cart.map(line => ({ variantId: line.item.id, quantity: line.quantity, unitPrice: line.unitPrice, discount: line.discount })),'),
('const saved = data.items as { variantId: string; quantity: number }[];','const saved = data.items as { variantId: string; quantity: number; unitPrice?: number; discount?: number }[];'),
('return item ? [{ item, quantity: line.quantity, discount: 0 }] : [];','return item ? [{ item, quantity: line.quantity, discount: line.discount ?? 0, unitPrice: line.unitPrice ?? Number(item.price) }] : [];'),
('<small>{line.item.name} · {egp.format(Number(line.item.price))}</small>','<small>{line.item.name} · السعر الأساسي {egp.format(Number(line.item.price))}</small>\n                        <label className="pos-line-price">سعر البيع للقطعة\n                          <input type="number" min={Number(line.item.price)} step="0.01" value={line.unitPrice || \'\'} onChange={event => update(line.item.id, { unitPrice: Number(event.target.value) || 0 })} aria-label={`سعر البيع للقطعة ${line.item.product.name}`} />\n                        </label>')]
for old,new in replacements: w=swap(w,old,new)
if '.pos-line-price {' in c: raise SystemExit('Price styles already present')
c += '\n.pos-line-price { display:flex; align-items:center; gap:7px; color:#42614b; font-size:11px; font-weight:700; flex-wrap:wrap; }\n.pos-line-price input { width:105px; min-width:0; height:32px; padding:4px 8px; border:1px solid #c7dacb; border-radius:7px; color:#244c32; background:#f6faf6; font-size:13px; font-weight:700; }\n'
for p, content in ((api,a),(web,w),(css,c)): p.write_text(content,encoding='utf8')
print('Price override applied to',root)
