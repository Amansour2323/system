import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig(({ command }) => ({ plugins: [react()], server: { port: 5173 }, define: { __API_URL__: JSON.stringify(command === 'build' ? (process.env.VITE_API_URL || '/api') : (process.env.VITE_API_URL || 'http://localhost:3000')) } }));
