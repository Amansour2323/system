const amount = (value: unknown) => `${Number(value || 0).toLocaleString('en-EG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ج.م`;
const escapeHtml = (value: unknown) => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]!));
const paymentLabels: Record<string, string> = { CASH: 'كاش', CARD: 'فيزا', VODAFONE_CASH: 'فودافون كاش', INSTAPAY: 'إنستاباي' };
const code39: Record<string, string> = {
  '0':'nnnwwnwnn','1':'wnnwnnnnw','2':'nnwwnnnnw','3':'wnwwnnnnn','4':'nnnwwnnnw','5':'wnnwwnnnn','6':'nnwwwnnnn','7':'nnnwnnwnw','8':'wnnwnnwnn','9':'nnwwnnwnn',
  A:'wnnnnwnnw',B:'nnwnnwnnw',C:'wnwnnwnnn',D:'nnnnwwnnw',E:'wnnnwwnnn',F:'nnwnwwnnn',G:'nnnnnwwnw',H:'wnnnnwwnn',I:'nnwnnwwnn',J:'nnnnwwwnn',
  K:'wnnnnnnww',L:'nnwnnnnww',M:'wnwnnnnwn',N:'nnnnwnnww',O:'wnnnwnnwn',P:'nnwnwnnwn',Q:'nnnnnnwww',R:'wnnnnnwnw',S:'nnwnnnwnw',T:'nnnnwnwwn',
  U:'wwnnnnnnw',V:'nwwnnnnnw',W:'wwwnnnnnn',X:'nwnnwnnnw',Y:'wwnnwnnnn',Z:'nwwnwnnnn','-':'nwnnnnwnw','.':'wwnnnnwnn',' ':'nwwnnnwnn','$':'nwnwnwnnn','/':'nwnwnnnwn','+':'nwnnnwnwn','%':'nnnwnwnwn','*':'nwnnwnwnn',
};

function invoiceBarcode(value: unknown) {
  const invoice = String(value || '').toUpperCase().replace(/[^0-9A-Z. $/+%-]/g, '');
  const encoded = `*${invoice}*`;
  const bars: string[] = [];
  let cursor = 8;
  for (const character of encoded) {
    const pattern = code39[character];
    if (!pattern) continue;
    for (let index = 0; index < pattern.length; index += 1) {
      const width = pattern[index] === 'w' ? 3 : 1;
      if (index % 2 === 0) bars.push(`<rect x="${cursor}" y="0" width="${width}" height="52"/>`);
      cursor += width;
    }
    cursor += 1;
  }
  const viewWidth = cursor + 7;
  return `<svg class="barcode" role="img" aria-label="باركود الفاتورة ${escapeHtml(value)}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${viewWidth} 64" preserveAspectRatio="none"><rect width="${viewWidth}" height="64" fill="white"/><g fill="black">${bars.join('')}</g></svg>`;
}

export function openThermalReceiptWindow() {
  return window.open('', '_blank', 'width=420,height=760');
}

export function printThermalReceipt(sale: any, target?: Window | null) {
  const receipt = target === undefined ? openThermalReceiptWindow() : target;
  if (!receipt) return false;

  const invoiceNo = escapeHtml(sale.invoiceNo || '—');
  const logoUrl = new URL('/draft-logo-gold.png', window.location.origin).href;
  const date = new Date(sale.createdAt || Date.now());
  const dateLabel = `${date.toLocaleDateString('en-GB')} · ${date.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}`;
  const lines = (sale.items || []).map((line: any) => {
    const name = line.variant?.product?.name || line.productName || line.name || line.variant?.name || 'صنف';
    const variant = line.variant?.name && line.variant.name !== name ? line.variant.name : [line.variant?.color, line.variant?.size].filter(Boolean).join(' | ');
    const quantity = Number(line.quantity || 0);
    const unitPrice = Number(line.unitPrice || line.price || (quantity ? Number(line.total ?? line.lineTotal ?? 0) / quantity : 0));
    const total = Number(line.total ?? line.lineTotal ?? unitPrice * quantity);
    return `<tr><td class="item"><strong>${escapeHtml(name)}</strong>${variant ? `<small>${escapeHtml(variant)}</small>` : ''}</td><td class="quantity" dir="ltr">${quantity} × ${amount(unitPrice)}</td><td class="line-total" dir="ltr">${amount(total)}</td></tr>`;
  }).join('');
  const discount = Number(sale.discount || 0);
  const subtotal = Number(sale.subtotal ?? Number(sale.total || 0) + discount);
  const total = Number(sale.total || 0);
  const tendered = Number(sale.tendered ?? sale.paid ?? total);
  const change = Number(sale.change ?? Math.max(0, tendered - total));
  const due = Number(sale.due ?? Math.max(0, total - Number(sale.paid ?? total)));
  const payments = sale.payments?.length
    ? sale.payments.map((payment: any) => `<div class="pair"><span>${escapeHtml(paymentLabels[payment.method] || payment.method)}</span><b dir="ltr">${amount(payment.amount)}</b></div>`).join('')
    : `<div class="pair"><span>طريقة الدفع</span><b>${escapeHtml(paymentLabels[sale.paymentMethod] || sale.paymentMethod || 'كاش')}</b></div>`;

  receipt.document.open();
  receipt.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>فاتورة ${invoiceNo}</title><style>
    @page{size:80mm auto;margin:0}
    *{box-sizing:border-box}html,body{width:80mm;max-width:80mm;margin:0;padding:0;background:#fff;color:#111;overflow-x:hidden}
    body{font-family:Tahoma,Arial,sans-serif;font-size:12px;line-height:1.5;-webkit-print-color-adjust:exact;print-color-adjust:exact}
    .receipt{width:68mm;max-width:68mm;margin:0 auto;padding:6mm 2mm 6mm;transform:translateX(1.5mm) scale(.95);transform-origin:top center}.brand{text-align:center;border-bottom:1px solid #222;padding:0 0 3mm;margin-bottom:2mm;overflow:visible}
    .brand-feather{display:block;width:27mm;height:10mm;margin:0 auto 1mm;overflow:visible}.brand-name{font-family:Georgia,'Times New Roman',serif;font-size:29px;line-height:1.15;letter-spacing:3px;margin:0;font-weight:500;padding:0 1mm}.brand-fashion{font-size:10px;letter-spacing:5px;margin:1mm 0 2mm}.brand p{margin:1mm 0;font-size:11px}
    .tax{font-weight:bold}.section-title{display:flex;align-items:center;gap:7px;justify-content:center;font-size:19px;font-weight:bold;margin:3mm 0}.section-title:before,.section-title:after{content:'';height:1px;background:#222;flex:1}
    .meta{margin:0 0 3mm}.pair{display:flex;align-items:center;justify-content:space-between;gap:5px;padding:1mm 0}.pair span{flex:0 0 auto}.pair b{font-weight:500}.invoice-no{font-weight:bold}
    table{width:100%;border-collapse:collapse;table-layout:fixed;margin-top:2mm}th{border-top:1px solid #222;border-bottom:1px solid #888;padding:2mm 1mm;font-size:11px}td{padding:2.5mm 1mm;vertical-align:top;border-bottom:1px dashed #aaa}.item{width:39%;text-align:right}.item strong,.item small{display:block}.item strong{font-size:12px}.item small{font-size:10px;color:#333}.quantity{width:37%;text-align:center;font-size:11px}.line-total{width:24%;text-align:left;font-weight:bold;font-size:11px}
    .totals{border-top:1px solid #222;margin-top:1mm;padding-top:2mm}.grand{border:3px double #222;padding:2mm 2.5mm;margin:2mm -1mm;font-size:17px;font-weight:bold}.grand b{font-size:17px}
    .payments{border-top:1px solid #777;border-bottom:1px solid #222;margin-top:3mm;padding:2mm 0}.footer{text-align:center;padding-top:3mm}.footer strong{font-size:17px}.footer p{margin:1.5mm 0}.keep{white-space:nowrap}.barcode{display:block;width:58mm;height:15mm;margin:2mm auto 0}
    @media print{html,body{width:80mm!important;max-width:80mm!important;margin:0!important;padding:0!important;overflow:visible!important}.receipt{width:68mm!important;max-width:68mm!important;margin:0 auto!important;padding:6mm 2mm!important;transform:translateX(1.5mm) scale(.95)!important;transform-origin:top center!important}.brand-feather{height:10mm!important}.no-break{break-inside:avoid;page-break-inside:avoid}}
  </style></head><body><main class="receipt"><header class="brand"><svg class="brand-feather" viewBox="0 0 180 60" role="img" aria-label="ريشة شعار درافت" xmlns="http://www.w3.org/2000/svg"><path fill="#111" d="M9 48C36 19 76 2 118 7c20 2 38 11 53 22-23-2-40 2-55 12C81 29 47 36 9 48Z"/><path fill="none" stroke="#fff" stroke-width="2.2" d="M20 44 55 27m-17 19 31-22m-7 20 29-20m-3 19 26-17m-1 16 24-14m-35 7-13-17m31 8-10-16m27 13-5-12"/><path fill="none" stroke="#111" stroke-width="2" d="M11 49c44-17 86-22 145-20"/></svg><h1 class="brand-name">DRAFT</h1><div class="brand-fashion">F A S H I O N</div><p dir="ltr"><b>01050400751</b></p><p>الإسماعيلية - السلطان حسين</p><p>12 شارع كليوباترا - بجوار ماكدونالدز</p><p class="tax">الرقم الضريبي: <span dir="ltr">721-035-809</span></p></header>
    <div class="section-title">فاتورة بيع</div><section class="meta"><div class="pair"><span>رقم الفاتورة:</span><b class="invoice-no" dir="ltr">${invoiceNo}</b></div><div class="pair"><span>التاريخ:</span><b dir="ltr">${escapeHtml(dateLabel)}</b></div><div class="pair"><span>الكاشير:</span><b>${escapeHtml(sale.cashier?.name || sale.cashierName || '—')}</b></div><div class="pair"><span>العميل:</span><b>${escapeHtml(sale.customer?.name || 'بيع مباشر')}</b></div></section>
    <table><thead><tr><th class="item">المنتج</th><th class="quantity">الكمية × سعر الوحدة</th><th class="line-total">الإجمالي</th></tr></thead><tbody>${lines}</tbody></table>
    <section class="totals"><div class="pair"><span>الإجمالي</span><b dir="ltr">${amount(subtotal)}</b></div>${discount ? `<div class="pair"><span>الخصم</span><b dir="ltr">− ${amount(discount)}</b></div>` : ''}<div class="pair grand"><span>المطلوب سداده</span><b dir="ltr">${amount(total)}</b></div></section>
    <section class="payments">${payments}<div class="pair"><span>المدفوع</span><b dir="ltr">${amount(tendered)}</b></div>${change > 0 ? `<div class="pair"><span>الباقي</span><b dir="ltr">${amount(change)}</b></div>` : ''}${due > 0 ? `<div class="pair"><span>متبقي على العميل</span><b dir="ltr">${amount(due)}</b></div>` : ''}</section>
    <footer class="footer"><strong>شكراً لاختيارك درافت</strong><p>يرجى الاحتفاظ بالفاتورة للاستبدال والاسترجاع</p>${invoiceBarcode(sale.invoiceNo)}<p class="keep" dir="ltr">${invoiceNo}</p></footer></main><script>window.addEventListener('load',()=>setTimeout(()=>{window.focus();window.print()},350));window.addEventListener('afterprint',()=>setTimeout(()=>window.close(),300));</script></body></html>`);
  const brandStyle = receipt.document.createElement('style');
  brandStyle.textContent = '.brand-logo{display:block;width:58mm;height:27mm;object-fit:contain;object-position:center;margin:0 auto 2mm}';
  receipt.document.head.appendChild(brandStyle);
  const brandHeader = receipt.document.querySelector('.brand');
  if (brandHeader) brandHeader.innerHTML = `<img class="brand-logo" src="${logoUrl}" alt="DRAFT Fashion"><p dir="ltr"><b>01050400751</b></p><p>الإسماعيلية - السلطان حسين</p><p>12 شارع كليوباترا - بجوار ماكدونالدز</p><p class="tax">الرقم الضريبي: <span dir="ltr">721-035-809</span></p>`;
  receipt.document.close();
  return true;
}
