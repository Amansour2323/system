import React, { useMemo, useState } from 'react';
import { api } from './api-client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowLeftRight, Search } from 'lucide-react';
import './operations.css';

declare const __API_URL__: string;


const get = <T,>(path: string) => api.get<T>(path).then(response => response.data);
const egp = new Intl.NumberFormat('ar-EG', { style: 'currency', currency: 'EGP' });
const normalize = (value: unknown) => String(value ?? '').trim().toLocaleLowerCase('ar');
type ExchangeMode = 'FULL' | 'PARTIAL';

export function ExchangePage() {
  const client = useQueryClient();
  const { data: sales = [] } = useQuery({ queryKey: ['sales'], queryFn: () => get<any[]>('/pos/sales') });
  const { data: variants = [] } = useQuery({ queryKey: ['pos-products'], queryFn: () => get<any[]>('/pos/products') });
  const [saleId, setSaleId] = useState('');
  const [saleItemId, setSaleItemId] = useState('');
  const [returnQty, setReturnQty] = useState('1');
  const [variantId, setVariantId] = useState('');
  const [newQty, setNewQty] = useState('1');
  const [mode, setMode] = useState<ExchangeMode>('PARTIAL');
  const [invoiceSearch, setInvoiceSearch] = useState('');
  const [productSearch, setProductSearch] = useState('');
  const [method, setMethod] = useState('CASH');
  const [reason, setReason] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);

  const completedSales = useMemo(() => sales.filter((row: any) => row.status === 'COMPLETED'), [sales]);
  const filteredSales = useMemo(() => {
    const query = normalize(invoiceSearch);
    return query ? completedSales.filter((row: any) => normalize(row.invoiceNo).includes(query)) : completedSales;
  }, [completedSales, invoiceSearch]);
  const filteredVariants = useMemo(() => {
    const query = normalize(productSearch);
    if (!query) return variants;
    return variants.filter((row: any) => [row.product?.name, row.product?.sku, row.name, row.barcode]
      .some(value => normalize(value).includes(query)));
  }, [variants, productSearch]);

  const sale = sales.find((value: any) => value.id === saleId);
  const returnableItems = useMemo(() => (sale?.items ?? []).map((item: any) => {
    const alreadyReturned = (item.returnItems ?? []).reduce((sum: number, row: any) => sum + Number(row.quantity || 0), 0);
    return { ...item, availableQty: Math.max(0, Number(item.quantity || 0) - alreadyReturned) };
  }).filter((item: any) => item.availableQty > 0), [sale]);
  const oldLine = returnableItems.find((value: any) => value.id === saleItemId);
  const replacement = variants.find((value: any) => value.id === variantId);
  const returnItems = useMemo(() => {
    if (mode === 'FULL') return returnableItems.map((item: any) => ({ saleItemId: item.id, quantity: item.availableQty }));
    if (!oldLine) return [];
    return [{ saleItemId: oldLine.id, quantity: Math.min(Math.max(1, Number(returnQty) || 1), oldLine.availableQty) }];
  }, [mode, oldLine, returnQty, returnableItems]);
  const returnedTotal = useMemo(() => returnItems.reduce((sum: number, item: { saleItemId: string; quantity: number }) => {
    const line = returnableItems.find((value: any) => value.id === item.saleItemId);
    return sum + Number(line?.unitPrice || 0) * item.quantity;
  }, 0), [returnItems, returnableItems]);
  const replacementTotal = replacement ? Number(replacement.price || 0) * Math.max(1, Number(newQty) || 1) : 0;
  const difference = replacement ? replacementTotal - returnedTotal : 0;
  const ready = Boolean(sale && returnItems.length && replacement && reason.trim().length >= 3);

  const chooseSale = (nextSaleId: string) => {
    setSaleId(nextSaleId);
    const selected = sales.find((value: any) => value.id === nextSaleId);
    const firstAvailable = (selected?.items ?? []).find((item: any) => {
      const returned = (item.returnItems ?? []).reduce((sum: number, row: any) => sum + Number(row.quantity || 0), 0);
      return Number(item.quantity || 0) > returned;
    });
    setSaleItemId(firstAvailable?.id ?? '');
    setReturnQty('1');
    setNotice('');
  };

  const send = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!ready || !sale || !replacement) {
      setNotice('أكمل اختيار الفاتورة والصنف المرتجع والبديل والسبب أولاً.');
      return;
    }
    setBusy(true);
    setNotice('');
    try {
      const payments = difference > 0 ? [{ method, amount: difference }] : [];
      const { data } = await api.post('/pos/exchanges', {
        saleId: sale.id,
        reason: reason.trim(),
        returnItems,
        newItems: [{ variantId: replacement.id, quantity: Math.max(1, Number(newQty) || 1) }],
        payments,
        refundMethod: method,
        idempotencyKey: crypto.randomUUID(),
      });
      setNotice(data.difference > 0
        ? `تم الاستبدال؛ تم تحصيل ${egp.format(data.difference)} من العميل.`
        : data.refund > 0 ? `تم الاستبدال؛ تم رد ${egp.format(data.refund)} للعميل.` : 'تم الاستبدال دون فرق.');
      setSaleId(''); setSaleItemId(''); setVariantId(''); setInvoiceSearch(''); setProductSearch(''); setReason('');
      client.invalidateQueries({ queryKey: ['sales'] });
      client.invalidateQueries({ queryKey: ['pos-products'] });
      client.invalidateQueries({ queryKey: ['inventory-summary'] });
    } catch (error: any) {
      setNotice(error.response?.data?.message || 'تعذر إتمام الاستبدال.');
    } finally {
      setBusy(false);
    }
  };

  return <main className="content">
    <header className="topbar">
      <div><p className="eyebrow">DRAFT · نقطة البيع</p><h1>استبدال ذري</h1><p className="muted">استبدال كلي أو جزئي مع حساب فرق التحصيل أو الاسترداد قبل التأكيد.</p></div>
      <ArrowLeftRight />
    </header>
    {notice && <p className="toast">{notice}</p>}
    <section className="panel">
      <form className="form-grid exchange-form" onSubmit={send}>
        <label className="full">البحث برقم الفاتورة
          <div className="search exchange-search"><Search size={18}/><input value={invoiceSearch} onChange={event => setInvoiceSearch(event.target.value)} placeholder="اكتب رقم الفاتورة" /></div>
        </label>
        <label className="full">الفاتورة الأصلية
          <select value={saleId} onChange={event => chooseSale(event.target.value)} required>
            <option value="">اختر فاتورة مكتملة</option>
            {filteredSales.map((row: any) => <option key={row.id} value={row.id}>{row.invoiceNo} — {egp.format(Number(row.total))}</option>)}
          </select>
        </label>
        {invoiceSearch && !filteredSales.length && <p className="full form-note">لا توجد فاتورة مكتملة بهذا الرقم.</p>}
        {sale && <>
          <fieldset className="full exchange-mode">
            <legend>نوع الاستبدال</legend>
            <label className={mode === 'PARTIAL' ? 'active' : ''}><input type="radio" name="exchange-mode" checked={mode === 'PARTIAL'} onChange={() => setMode('PARTIAL')} />جزئي — صنف وكمية محددة</label>
            <label className={mode === 'FULL' ? 'active' : ''}><input type="radio" name="exchange-mode" checked={mode === 'FULL'} onChange={() => setMode('FULL')} />كلي — كل الكميات المتبقية بالفاتورة</label>
          </fieldset>
          {mode === 'PARTIAL' && <>
            <label>الصنف المرتجع
              <select value={saleItemId} onChange={event => { setSaleItemId(event.target.value); setReturnQty('1'); }} required>
                <option value="">اختر الصنف</option>
                {returnableItems.map((item: any) => <option key={item.id} value={item.id}>{item.variant.product.name} — {item.variant.name} · متاح {item.availableQty}</option>)}
              </select>
            </label>
            <label>كمية الإرجاع<input type="number" min="1" max={oldLine?.availableQty || 1} value={returnQty} onChange={event => setReturnQty(event.target.value)} required /></label>
          </>}
          {mode === 'FULL' && <div className="full exchange-return-list">
            <b>الأصناف التي سيتم إرجاعها بالكامل</b>
            {returnableItems.map((item: any) => <span key={item.id}>{item.variant.product.name} — {item.variant.name}<strong>{item.availableQty} × {egp.format(Number(item.unitPrice))}</strong></span>)}
          </div>}
          <label className="full">البحث عن المنتج البديل
            <div className="search exchange-search"><Search size={18}/><input value={productSearch} onChange={event => setProductSearch(event.target.value)} placeholder="اسم المنتج أو SKU أو الباركود" /></div>
          </label>
          <label>الصنف البديل
            <select value={variantId} onChange={event => setVariantId(event.target.value)} required>
              <option value="">اختر الصنف البديل</option>
              {filteredVariants.map((row: any) => <option key={row.id} value={row.id}>{row.product.name} — {row.name} · {row.barcode || row.product.sku || 'بدون كود'} · {egp.format(Number(row.price))}</option>)}
            </select>
          </label>
          <label>كمية البديل<input type="number" min="1" value={newQty} onChange={event => setNewQty(event.target.value)} required /></label>
          {productSearch && !filteredVariants.length && <p className="full form-note">لا يوجد منتج مطابق للاسم أو الكود.</p>}
          <label>طريقة التحصيل/الاسترداد
            <select value={method} onChange={event => setMethod(event.target.value)}><option value="CASH">نقدي</option><option value="CARD">بطاقة</option><option value="VODAFONE_CASH">فودافون كاش</option><option value="INSTAPAY">إنستاباي</option></select>
          </label>
          <label>السبب<input value={reason} onChange={event => setReason(event.target.value)} minLength={3} required /></label>
          <div className="full exchange-summary">
            <div><span>قيمة المرتجع</span><b>{egp.format(returnedTotal)}</b></div>
            <div><span>قيمة المنتج البديل</span><b>{egp.format(replacementTotal)}</b></div>
            <div className={difference > 0 ? 'collect' : difference < 0 ? 'refund' : ''}>
              <span>{difference > 0 ? 'المبلغ المطلوب من العميل' : difference < 0 ? 'المبلغ المسترد للعميل' : 'فرق الاستبدال'}</span>
              <strong>{egp.format(Math.abs(difference))}</strong>
              <small>{replacement ? (difference > 0 ? 'يُحصّل من العميل' : difference < 0 ? 'يُرد للعميل' : 'لا يوجد فرق') : 'اختر المنتج البديل لحساب الفرق'}</small>
            </div>
          </div>
          <div className="form-actions"><button className="primary" disabled={!ready || busy}><ArrowLeftRight size={17}/>{busy ? 'جارٍ تنفيذ الاستبدال…' : 'تأكيد الاستبدال الذري'}</button></div>
        </>}
      </form>
    </section>
  </main>;
}
