import { Check, ChevronDown } from 'lucide-react';
import { useEffect, useId, useRef, useState } from 'react';

export type SelectOption = { value: string; label: string; disabled?: boolean };

type SelectFieldProps = {
  value: string;
  onChange: (value: string) => void;
  options: SelectOption[];
  placeholder: string;
  ariaLabel: string;
  disabled?: boolean;
};

/** Accessible, RTL-friendly select menu for places where a native popup is too inconsistent. */
export function SelectField({ value, onChange, options, placeholder, ariaLabel, disabled = false }: SelectFieldProps) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const listboxId = useId();
  const selected = options.find(option => option.value === value);

  useEffect(() => {
    const closeOnOutsideClick = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', closeOnOutsideClick);
    return () => document.removeEventListener('mousedown', closeOnOutsideClick);
  }, []);

  const choose = (nextValue: string) => {
    onChange(nextValue);
    setOpen(false);
    triggerRef.current?.focus();
  };

  const moveSelection = (direction: 1 | -1) => {
    const enabled = options.filter(option => !option.disabled);
    if (!enabled.length) return;
    const currentIndex = enabled.findIndex(option => option.value === value);
    const nextIndex = currentIndex < 0 ? (direction > 0 ? 0 : enabled.length - 1) : (currentIndex + direction + enabled.length) % enabled.length;
    choose(enabled[nextIndex].value);
  };

  return <div className="select-field" ref={rootRef}>
    <button
      ref={triggerRef}
      type="button"
      className="select-trigger"
      aria-label={ariaLabel}
      aria-haspopup="listbox"
      aria-expanded={open}
      aria-controls={listboxId}
      disabled={disabled}
      onClick={() => setOpen(current => !current)}
      onKeyDown={event => {
        if (event.key === 'Escape') { setOpen(false); return; }
        if (event.key === 'ArrowDown') { event.preventDefault(); moveSelection(1); return; }
        if (event.key === 'ArrowUp') { event.preventDefault(); moveSelection(-1); return; }
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); setOpen(current => !current); }
      }}
    >
      <span className={selected ? '' : 'select-placeholder'}>{selected?.label || placeholder}</span>
      <ChevronDown size={18} aria-hidden="true" className={open ? 'select-chevron open' : 'select-chevron'} />
    </button>
    {open && <div id={listboxId} className="select-menu" role="listbox" aria-label={ariaLabel}>
      {options.map(option => <button
        type="button"
        key={option.value}
        className={option.value === value ? 'select-option selected' : 'select-option'}
        role="option"
        aria-selected={option.value === value}
        disabled={option.disabled}
        onClick={() => choose(option.value)}
      >
        <span>{option.label}</span>{option.value === value && <Check size={16} aria-hidden="true" />}
      </button>)}
    </div>}
  </div>;
}
