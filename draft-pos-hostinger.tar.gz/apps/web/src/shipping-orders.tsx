import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Banknote, Check, CheckCircle2, Clock3, PackageCheck, RotateCcw, Search, Truck, X } from 'lucide-react';
import { api } from './api-client';

const get = <T,>(path: string) => api.get<T>(path).then(response => response.data);
const egp = new Intl.NumberFormat('ar-EG', { style: 'currency', currency: 'EGP', maximumFractionDigits: 2 });
const methods = [{ value: 'CASH', label: 'نقدي' }, { value: 'CARD', label: 'بطاقة' }, { value: 'VODAFONE_CASH', label: 'Vodafone Cash' }, { value: 'INSTAPAY', label: 'InstaPay' }];
const statusLabels: Record<string, string> = { PENDING: 'جديد', PREPARING: 'قيد التجهيز', SHIPPED: 'خرج للتوصيل', DELIVERED: 'تم التسليم', PARTIALLY_DELIVERED: 'استلام جزئي', RETURNED: 'مرتجع بالكامل' };
const nextStatus: Record<string, { value: string; label: string }> = { PENDING: { value: 'PREPARING', label: 'بدء التجهيز' }, PREPARING: { value: 'SHIPPED', label: 'تأكيد خروج الشحنة' } };
type Variant = { id: string; name: string; barcode?: string | null; sku?: string | null; price: number | string; product: { name: string; sku?: string | null }; balances: { warehouseId: string; quantity: number }[] };
type ResolutionRow = { quantity: string; search: string; variantId: string; replacementQuantity: string };

export function ShippingOrdersPage() {
  const client = useQueryClient();
  const { data: orders = [], isLoading, error } = useQuery({ queryKey: ['shipping-orders'], queryFn: () => get<any[]>('/pos/shipping-orders') });
  const { data: variants = [] } = useQuery({ queryKey: ['shipping-order-variants'], queryFn: () => get<Variant[]>('/pos/shipping-orders/variants') });
  const [query, setQuery] = useState('');
  const [message, setMessage] = useState('');
  const [paymentByOrder, setPaymentByOrder] = useState<Record<string, { amount: string; method: string; reference: string }>>({});
  const [resolutionId, setResolutionId] = useState('');
  const [noDelivery, setNoDelivery] = useState(false);
  const [resolutionRows, setResolutionRows] = useState<Record<string, ResolutionRow>>({});
  const [resolutionReason, setResolutionReason] = useState('نتيجة التوصيل');
  const [resolutionRefundMethod, setResolutionRefundMethod] = useState('CASH');
  const [resolutionPayment, setResolutionPayment] = useState({ amount: '', method: 'CASH', reference: '' });
  const refresh = () => { client.invalidateQueries({ queryKey: ['shipping-orders'] }); client.invalidateQueries({ queryKey: ['sales'] }); client.invalidateQueries({ queryKey: ['reports'] }); client.invalidateQueries({ queryKey: ['drawer'] }); };
  const advance = useMutation({ mutationFn: ({ id, status }: { id: string; status: string }) => api.post(`/pos/shipping-orders/${id}/status`, { status }), onSuccess: () => { setMessage('تم تحديث حالة الشحنة.'); refresh(); }, onError: (err: any) => setMessage(err.response?.data?.message || 'تعذر تحديث حالة الشحنة.') });
  const collect = useMutation({ mutationFn: ({ id, data }: { id: string; data: { method: string; amount: number; reference?: string } }) => api.post(`/pos/shipping-orders/${id}/payments`, data), onSuccess: () => { setMessage('تم تسجيل التحصيل وتحديث المتبقي.'); refresh(); }, onError: (err: any) => setMessage(err.response?.data?.message || 'تعذر تسجيل التحصيل.') });
  const closeout = useMutation({ mutationFn: ({ id, data }: { id: string; data: unknown }) => api.post(`/pos/shipping-orders/${id}/closeout`, data), onSuccess: response => { const result = response.data; setMessage(result.shippingStatus === 'RETURNED' ? 'تم تسجيل رجوع الشحنة بالكامل وإعادة الكميات للمخزون.' : result.shippingStatus === 'PARTIALLY_DELIVERED' ? 'تم تسجيل الاستلام الجزئي والمرتجعات/الاستبدالات.' : 'تم تأكيد التسليم وتحديث التحصيل والمخزون.'); setResolutionId(''); setNoDelivery(false); setResolutionRows({}); setResolutionPayment({ amount: '', method: 'CASH', reference: '' }); refresh(); }, onError: (err: any) => setMessage(err.response?.data?.message || 'تعذر حفظ نتيجة التسليم.') });
  const filtered = orders.filter((order: any) => `${order.invoiceNo} ${order.shippingName} ${order.shippingPhone} ${order.shippingAddress}`.toLocaleLowerCase('ar').includes(query.trim().toLocaleLowerCase('ar')));
  const totalDue = orders.reduce((sum: number, order: any) => sum + Number(order.due ?? Math.max(0, Number(order.total) - Number(order.paid))), 0);
  const totalOpen = orders.filter((order: any) => !['DELIVERED', 'PARTIALLY_DELIVERED', 'RETURNED'].includes(order.shippingStatus)).length;
  const setPayment = (id: string, key: string, value: string) => setPaymentByOrder(previous => ({ ...previous, [id]: { ...(previous[id] || { amount: '', method: 'CASH', reference: '' }), [key]: value } }));
  const openResolution = (orderId: string) => { setResolutionId(orderId); setNoDelivery(false); setResolutionRows({}); setResolutionReason('نتيجة التوصيل'); setResolutionPayment({ amount: '', method: 'CASH', reference: '' }); };
  const setResolutionRow = (lineId: string, key: keyof ResolutionRow, value: string) => setResolutionRows(previous => ({ ...previous, [lineId]: { ...(previous[lineId] || { quantity: '0', search: '', variantId: '', replacementQuantity: '' }), [key]: value } }));

  return <main className="content shipping-page" dir="rtl">
    <header className="topbar"><div><p className="eyebrow">DRAFT · المبيعات</p><h1>أوردرات الشحن</h1><p className="muted">تابع تجهيز الأوردرات، نتيجة التسليم، المرتجعات، والاستبدالات والتحصيل.</p></div></header>
    <section className="shipping-summary">
      <article><span><Truck size={18}/></span><div><small>إجمالي الأوردرات</small><b>{orders.length}</b></div></article>
      <article><span><Clock3 size={18}/></span><div><small>قيد المتابعة</small><b>{totalOpen}</b></div></article>
      <article><span><Banknote size={18}/></span><div><small>مبالغ متبقية للتحصيل</small><b>{egp.format(totalDue)}</b></div></article>
    </section>
    <section className="panel shipping-list-panel">
      <div className="shipping-toolbar"><label className="search"><Search size={17}/><input value={query} onChange={event => setQuery(event.target.value)} placeholder="ابحث برقم الأوردر أو اسم المستلم أو الهاتف"/></label><span>{filtered.length} أوردر</span></div>
      {message && <p className="toast" role="status">{message}</p>}
      {isLoading ? <div className="empty compact">جارٍ تحميل أوردرات الشحن…</div> : error ? <div className="empty compact">تعذر تحميل أوردرات الشحن. حدّث الصفحة أو راجع الصلاحيات.</div> : filtered.length ? <div className="shipping-order-list">{filtered.map((order: any) => {
        const due = Number(order.due ?? Math.max(0, Number(order.total) - Number(order.paid)));
        const netTotal = Number(order.netTotal ?? order.total);
        const netPaid = Number(order.netPaid ?? order.paid);
        const paymentState = due <= 0 ? 'مدفوع بالكامل' : netPaid > 0 ? `مدفوع جزئيًا · ${egp.format(due)} متبقي` : 'الدفع عند الاستلام';
        const payment = paymentByOrder[order.id] || { amount: '', method: 'CASH', reference: '' };
        const next = nextStatus[order.shippingStatus];
        const statusClass = String(order.shippingStatus).toLowerCase().replace('_', '-');
        const orderReturns = order.returns || [];
        return <article className="shipping-order-card" key={order.id}>
          <div className="shipping-card-heading"><div><span className="shipping-kicker">رقم الأوردر</span><h2>{order.invoiceNo}</h2><small>{new Date(order.createdAt).toLocaleString('ar-EG')}</small></div><span className={`shipping-status ${statusClass}`}>{statusLabels[order.shippingStatus] || order.shippingStatus}</span></div>
          <div className="shipping-order-main"><div className="shipping-recipient"><b>{order.shippingName}</b><span dir="ltr">{order.shippingPhone}</span><small>{order.shippingAddress}</small>{order.customer && <small>حساب عميل: {order.customer.name}</small>}</div><div className="shipping-order-lines">{order.items.map((line: any) => { const returned = (line.returnItems || []).reduce((sum: number, item: any) => sum + Number(item.quantity), 0); return <div key={line.id}><span>{line.variant.product.name} · {line.variant.name}{returned > 0 && <small className="shipping-line-return"> · مرتجع {returned} من {line.quantity}</small>}</span><b>× {line.quantity - returned} مستلم</b></div>; })}{orderReturns.filter((row: any) => row.replacementSale).map((row: any) => <div className="shipping-replacement-line" key={row.id}><span>بديل {row.replacementSale.items.map((item: any) => `${item.variant.product.name} · ${item.variant.name} × ${item.quantity}`).join('، ')}</span><b>{row.replacementSale.invoiceNo}</b></div>)}</div><div className="shipping-money"><span>صافي الأوردر <b>{egp.format(netTotal)}</b></span><span>صافي المحصل <b>{egp.format(netPaid)}</b></span><strong className={due > 0 ? 'due' : 'settled'}>{paymentState}</strong>{Number(order.refundable) > 0 && <strong className="shipping-refund-due">مسترد للعميل {egp.format(Number(order.refundable))}</strong>}</div></div>
          {orderReturns.length > 0 && <div className="shipping-return-history">{orderReturns.map((row: any) => <span key={row.id}><RotateCcw size={13}/>مرتجع {egp.format(Number(row.total))}{Number(row.refundAmount) > 0 ? ` · رد ${egp.format(Number(row.refundAmount))}` : ''}{row.replacementSale ? ` · استبدال ${row.replacementSale.invoiceNo}` : ''}</span>)}</div>}
          <footer className="shipping-card-actions">
            {next && <button className="secondary small" type="button" disabled={advance.isPending} onClick={() => advance.mutate({ id: order.id, status: next.value })}><PackageCheck size={15}/>{next.label}</button>}
            {order.shippingStatus === 'SHIPPED' && <button className="primary small" type="button" onClick={() => resolutionId === order.id ? setResolutionId('') : openResolution(order.id)}><CheckCircle2 size={15}/>تسجيل نتيجة التسليم</button>}
            {['DELIVERED', 'PARTIALLY_DELIVERED'].includes(order.shippingStatus) && due > 0 && <form onSubmit={event => { event.preventDefault(); const amount = Number(payment.amount); if (amount > 0) collect.mutate({ id: order.id, data: { method: payment.method, amount, reference: payment.reference || undefined } }); }}><input aria-label="مبلغ التحصيل" type="number" min="0.01" step="0.01" max={due} value={payment.amount} onChange={event => setPayment(order.id, 'amount', event.target.value)} placeholder={`تحصيل حتى ${egp.format(due)}`} required/><select aria-label="طريقة التحصيل" value={payment.method} onChange={event => setPayment(order.id, 'method', event.target.value)}>{methods.map(method => <option key={method.value} value={method.value}>{method.label}</option>)}</select><input aria-label="مرجع التحصيل اختياري" value={payment.reference} onChange={event => setPayment(order.id, 'reference', event.target.value)} placeholder="رقم مرجعي (اختياري)"/><button className="primary small" disabled={collect.isPending}><Check size={15}/>تسجيل التحصيل</button></form>}
          </footer>
          {resolutionId === order.id && <section className="shipping-resolution" aria-label="تسجيل نتيجة التسليم">
            <div className="shipping-resolution-heading"><div><h3>نتيجة التوصيل</h3><p>اكتب كمية كل صنف التي رجعت مع المندوب؛ والباقي يُسجل مستلمًا.</p></div><button type="button" className="icon" aria-label="إغلاق" onClick={() => setResolutionId('')}><X size={18}/></button></div>
            <label className="shipping-no-delivery"><input type="checkbox" checked={noDelivery} onChange={event => setNoDelivery(event.target.checked)}/>العميل لم يستلم أي قطعة — رجوع الشحنة بالكامل</label>
            {!noDelivery && <div className="shipping-resolution-items">{order.items.map((line: any) => {
              const row = resolutionRows[line.id] || { quantity: '0', search: '', variantId: '', replacementQuantity: '' };
              const alreadyReturned = (line.returnItems || []).reduce((sum: number, item: any) => sum + Number(item.quantity), 0);
              const available = Number(line.quantity) - alreadyReturned;
              const returnedQuantity = Math.min(available, Math.max(0, Number(row.quantity) || 0));
              const choices = variants.filter((variant: Variant) => (variant.balances || []).some(balance => balance.warehouseId === order.warehouseId && Number(balance.quantity) > 0) || variant.id === line.variantId).filter((variant: Variant) => `${variant.product.name} ${variant.name} ${variant.barcode || ''} ${variant.sku || ''} ${variant.product.sku || ''}`.toLocaleLowerCase('ar').includes(row.search.trim().toLocaleLowerCase('ar'))).slice(0, 20);
              return <div className="shipping-resolution-item" key={line.id}><div className="shipping-resolution-product"><b>{line.variant.product.name} · {line.variant.name}</b><small>مرسل {line.quantity} · متاح للإرجاع {available}</small></div><label>الكمية المرتجعة<input type="number" min="0" max={available} step="1" value={row.quantity} onChange={event => setResolutionRow(line.id, 'quantity', event.target.value)} /></label>
                {returnedQuantity > 0 && <div className="shipping-exchange-picker"><label>لو استبدال بمقاس/صنف آخر، ابحث هنا<input value={row.search} onChange={event => { setResolutionRow(line.id, 'search', event.target.value); setResolutionRow(line.id, 'variantId', ''); }} placeholder="اسم الصنف أو SKU أو الباركود" /></label><select value={row.variantId} onChange={event => setResolutionRow(line.id, 'variantId', event.target.value)}><option value="">إرجاع واسترداد القيمة</option>{choices.map((variant: Variant) => <option key={variant.id} value={variant.id}>{variant.product.name} · {variant.name} · {egp.format(Number(variant.price))} · متاح {variant.balances.reduce((sum, balance) => sum + Number(balance.quantity), 0)}</option>)}</select>{row.variantId && <label>كمية البديل<input type="number" min="1" step="1" value={row.replacementQuantity || String(returnedQuantity)} onChange={event => setResolutionRow(line.id, 'replacementQuantity', event.target.value)} /></label>}</div>}
              </div>;
            })}</div>}
            <div className="shipping-resolution-fields"><label>سبب المرتجع / ملاحظة<input value={resolutionReason} onChange={event => setResolutionReason(event.target.value)} minLength={3} maxLength={180}/></label><label>طريقة رد المبلغ عند وجود استرداد<select value={resolutionRefundMethod} onChange={event => setResolutionRefundMethod(event.target.value)}>{methods.map(method => <option key={method.value} value={method.value}>{method.label}</option>)}</select></label></div>
            {(() => {
              const returnedTotal = noDelivery ? order.items.reduce((sum: number, line: any) => sum + (Number(line.quantity) - (line.returnItems || []).reduce((n: number, row: any) => n + Number(row.quantity), 0)) * Number(line.unitPrice), 0) : order.items.reduce((sum: number, line: any) => sum + Math.min(Number(line.quantity), Math.max(0, Number(resolutionRows[line.id]?.quantity) || 0)) * Number(line.unitPrice), 0);
              const replacementTotal = noDelivery ? 0 : order.items.reduce((sum: number, line: any) => { const row = resolutionRows[line.id]; const variant = variants.find((value: Variant) => value.id === row?.variantId); return sum + (variant ? Number(variant.price) * (Number(row?.replacementQuantity) || Math.min(Number(line.quantity), Math.max(0, Number(row?.quantity) || 0))) : 0); }, 0);
              const dueBeforeCollection = Number(order.due) + replacementTotal - returnedTotal;
              const maxCollection = Math.max(0, dueBeforeCollection);
              return <><div className="shipping-resolution-totals"><span>قيمة المرتجع <b>{egp.format(returnedTotal)}</b></span><span>قيمة البدائل <b>{egp.format(replacementTotal)}</b></span><strong>{dueBeforeCollection < 0 ? `سيتم رد ${egp.format(Math.abs(dueBeforeCollection))}` : `المتبقي بعد التسوية ${egp.format(dueBeforeCollection)}`}</strong></div>{maxCollection > 0 && <div className="shipping-resolution-collection"><label>المحصل عند التسليم (اختياري)<input type="number" min="0" step="0.01" max={maxCollection} value={resolutionPayment.amount} onChange={event => setResolutionPayment(previous => ({ ...previous, amount: event.target.value }))} placeholder={`حتى ${egp.format(maxCollection)}`}/></label><label>طريقة الدفع<select value={resolutionPayment.method} onChange={event => setResolutionPayment(previous => ({ ...previous, method: event.target.value }))}>{methods.map(method => <option key={method.value} value={method.value}>{method.label}</option>)}</select></label><label>مرجع الدفع<input value={resolutionPayment.reference} onChange={event => setResolutionPayment(previous => ({ ...previous, reference: event.target.value }))} placeholder="اختياري"/></label></div>}<div className="shipping-resolution-submit"><small>سيتم تحديث المخزون والمرتجع والقيود المالية في عملية واحدة.</small><button className="primary" type="button" disabled={closeout.isPending || resolutionReason.trim().length < 3 || Number(resolutionPayment.amount || 0) > maxCollection} onClick={() => {
                const returnedItems = noDelivery ? order.items.map((line: any) => ({ saleItemId: line.id, quantity: Number(line.quantity) - (line.returnItems || []).reduce((n: number, row: any) => n + Number(row.quantity), 0) })).filter((line: any) => line.quantity > 0) : order.items.map((line: any) => { const row = resolutionRows[line.id]; const quantity = Math.min(Number(line.quantity), Math.max(0, Number(row?.quantity) || 0)); return quantity > 0 ? { saleItemId: line.id, quantity, ...(row?.variantId ? { replacementVariantId: row.variantId, replacementQuantity: Number(row.replacementQuantity) || quantity } : {}) } : null; }).filter(Boolean);
                closeout.mutate({ id: order.id, data: { reason: resolutionReason, refundMethod: resolutionRefundMethod, returnedItems, payments: Number(resolutionPayment.amount) > 0 ? [{ method: resolutionPayment.method, amount: Number(resolutionPayment.amount), reference: resolutionPayment.reference || undefined }] : [] } });
              }}><CheckCircle2 size={16}/>{noDelivery ? 'تأكيد رجوع الشحنة بالكامل' : 'حفظ نتيجة التسليم'}</button></div></>;
            })()}
          </section>}
        </article>;
      })}</div> : <div className="empty compact"><Truck/><b>لا توجد أوردرات شحن</b><span>أنشئ أوردرًا من نقطة البيع باختيار «أوردر أونلاين / شحن».</span></div>}
    </section>
  </main>;
}
