import React, { useEffect, useMemo, useRef, useState } from 'react';
import { api } from './api-client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
  BadgePercent,
  Banknote,
  Barcode,
  CheckCircle2,
  CreditCard,
  Minus,
  PackageSearch,
  PauseCircle,
  PlayCircle,
  Plus,
  Printer,
  Search,
  ShoppingCart,
  Smartphone,
  Tag,
  UserPlus,
  UserRound,
  WalletCards,
} from 'lucide-react';
import './advanced-pos.css';
import { openThermalReceiptWindow, printThermalReceipt } from './thermal-receipt';

const get = <T,>(path: string) => api.get<T>(path).then(response => response.data);
const egp = new Intl.NumberFormat('ar-EG', {
  style: 'currency',
  currency: 'EGP',
  maximumFractionDigits: 2,
});

type Variant = {
  id: string;
  name: string;
  barcode: string;
  price: number | string;
  product: { id: string; name: string; sku: string; category?: { name: string } | null };
  balances: { quantity: number }[];
};

type CartLine = { item: Variant; quantity: number; discount: number };
type Customer = { id: string; name: string; phone?: string | null; points: number };

const normalizePhone = (value: unknown) => String(value ?? '').replace(/[^0-9+]/g, '');

const paymentTypes = [
  { key: 'CASH', label: 'نقدي', Icon: WalletCards },
  { key: 'CARD', label: 'بطاقة', Icon: CreditCard },
  { key: 'VODAFONE_CASH', label: 'Vodafone Cash', Icon: Smartphone },
  { key: 'INSTAPAY', label: 'InstaPay', Icon: Smartphone },
] as const;

function productClothingKind(variant: Variant) {
  const label = `${variant.product.name} ${variant.product.category?.name || ''}`.toLocaleLowerCase('ar');
  if (/sweat|hood|sweater|jumper|سويت|هودي|بلوفر|كنزة/.test(label)) return 'sweatshirt';
  if (/short|شورت/.test(label)) return 'shorts';
  if (/jean|pant|trouser|بنطلون|جينز|بنطرون/.test(label)) return 'pants';
  if (/shirt|tee|t-shirt|تيشيرت|تي شيرت|قميص|بلوزة/.test(label)) return 'shirt';
  if (/jacket|coat|جاكيت|معطف/.test(label)) return 'jacket';
  if (/shoe|sneaker|boot|حذاء|كوتشي|جزمة/.test(label)) return 'shoes';
  if (/dress|فستان/.test(label)) return 'dress';
  return 'apparel';
}

function ProductFallbackIcon({ kind }: { kind: string }) {
  const isPants = kind === 'pants' || kind === 'shorts';
  const isShoes = kind === 'shoes';
  const isDress = kind === 'dress';
  const isJacket = kind === 'jacket' || kind === 'sweatshirt';
  return (
    <svg className={`pos-fallback-drawing ${isPants ? 'pants' : kind}`} viewBox="0 0 120 110" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="3.1" strokeLinecap="round" strokeLinejoin="round">
        {isPants && <><path d="M35 17h50l7 79H66l-5-43-5 43H28l7-79Z"/><path d="M35 27h50M43 17v10m12-10v10m13-10v10m12-10v10M61 27v26"/>{kind === 'shorts' && <path d="m31 67 30-7 28 7"/>}</>}
        {!isPants && !isShoes && !isDress && <><path d="m39 20 16-6h10l16 6 24 22-14 14-12-12v48H41V44L29 56 15 42l24-22Z"/><path d="M53 15c1 12 5 18 11 18s10-6 11-18M29 56v-9m62 9v-9"/>{isJacket && <><path d="M60 34v58M48 46l12 9 12-9"/><path d="M45 88h30"/></>}</>}
        {isShoes && <><path d="M19 69c13 0 22-9 29-26l17 8c4 13 13 20 28 21l12 3v14H19V69Z"/><path d="M19 79h86M57 52l-8 12m18-8-8 11m18-4-7 8"/></>}
        {isDress && <><path d="M48 16h24l-2 17 26 54H24l26-54-2-17Z"/><path d="M48 16c2 11 6 17 12 17s10-6 12-17M39 50h42"/></>}
      </g>
    </svg>
  );
}

function ProductCatalogCard({ variant, stock, add }: { variant: Variant; stock: number; add: (variant: Variant) => void }) {
  const cardRef = useRef<HTMLButtonElement>(null);
  const [nearby, setNearby] = useState(false);
  useEffect(() => {
    const card = cardRef.current;
    if (!card || typeof IntersectionObserver === 'undefined') { setNearby(true); return; }
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setNearby(true); observer.disconnect(); }
    }, { rootMargin: '220px' });
    observer.observe(card);
    return () => observer.disconnect();
  }, []);
  const { data: attachments = [] } = useQuery({
    queryKey: ['pos-product-media', variant.product.id],
    queryFn: () => get<any[]>(`/uploads?entityType=Product&entityId=${variant.product.id}`),
    enabled: nearby && Boolean(variant.product.id),
    staleTime: 5 * 60 * 1000,
  });
  const image = attachments.find((attachment: any) => attachment.mimeType?.startsWith('image/'));
  const { data: imageUrl } = useQuery({
    queryKey: ['pos-product-image', image?.id],
    queryFn: async () => {
      const response = await api.get(`/uploads/${image.id}`, { responseType: 'blob' });
      return URL.createObjectURL(response.data);
    },
    enabled: nearby && Boolean(image?.id),
    staleTime: 5 * 60 * 1000,
  });
  const kind = productClothingKind(variant);
  return (
    <button
      ref={cardRef}
      className="product-card pos-product-card"
      onClick={() => add(variant)}
      disabled={stock <= 0}
      aria-label={`إضافة ${variant.product.name} بسعر ${egp.format(Number(variant.price))}`}
    >
      <span className="pos-product-visual">
        {stock <= 0 && <em className="pos-stock-badge out-of-stock">نفد</em>}
        {imageUrl ? <img src={imageUrl} alt="" loading="lazy" /> : <ProductFallbackIcon kind={kind} />}
      </span>
      <span className="pos-product-heading">
        <span className="pos-product-name" dir="auto">{variant.product.name}</span>
        {stock > 0 && <em className="pos-stock-badge">متاح {stock}</em>}
      </span>
      <small className="pos-product-variant" dir="auto">{variant.name} · {variant.product.category?.name || 'بدون قسم'}</small>
      <span className="pos-product-meta">
        <span className="pos-product-price">{egp.format(Number(variant.price))}</span>
        <span className="pos-product-barcode" dir="ltr"><Barcode size={13} />{variant.barcode || variant.product.sku}</span>
      </span>
    </button>
  );
}

export function AdvancedPosPage({ user }: { user?: { name?: string } } = {}) {
  const client = useQueryClient();
  const { data: variants = [], isLoading } = useQuery({
    queryKey: ['pos-products'],
    queryFn: () => get<Variant[]>('/pos/products'),
  });
  const { data: customers = [] } = useQuery({
    queryKey: ['pos-customers'],
    queryFn: () => get<Customer[]>('/customers'),
  });
  const { data: context } = useQuery({
    queryKey: ['pos-context'],
    queryFn: () => get<{ warehouseId: string; warehouseName: string }>('/pos/context'),
  });
  const { data: cashier } = useQuery({
    queryKey: ['pos-cashier'],
    queryFn: () => get<{ name: string }>('/auth/me'),
  });
  const { data: suspended = [] } = useQuery({
    queryKey: ['pos-suspended'],
    queryFn: () => get<any[]>('/pos/suspended'),
  });

  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('الكل');
  const [cart, setCart] = useState<CartLine[]>([]);
  const [customerId, setCustomerId] = useState('');
  const [customerPhoneQuery, setCustomerPhoneQuery] = useState('');
  const [customerSearchOpen, setCustomerSearchOpen] = useState(false);
  const [invoiceDiscount, setInvoiceDiscount] = useState(0);
  const [payments, setPayments] = useState<Record<string, string>>({
    CASH: '',
    CARD: '',
    VODAFONE_CASH: '',
    INSTAPAY: '',
  });
  const [notice, setNotice] = useState('');
  const [lastReceipt, setLastReceipt] = useState<any>();
  const [quickName, setQuickName] = useState('');
  const [quickPhone, setQuickPhone] = useState('');
  const [shippingOrder, setShippingOrder] = useState(false);
  const [shippingName, setShippingName] = useState('');
  const [shippingPhone, setShippingPhone] = useState('');
  const [shippingAddress, setShippingAddress] = useState('');

  const categories = useMemo(
    () => ['الكل', ...Array.from(new Set(variants.map(variant => variant.product.category?.name).filter(Boolean) as string[]))],
    [variants],
  );
  const filtered = useMemo(
    () => variants.filter(variant =>
      (category === 'الكل' || variant.product.category?.name === category) &&
      (`${variant.product.name} ${variant.product.sku} ${variant.barcode} ${variant.name}`.toLowerCase().includes(query.toLowerCase())),
    ),
    [variants, query, category],
  );
  const selectedCustomer = customers.find(customer => customer.id === customerId);
  const customerMatches = useMemo(() => {
    const phone = normalizePhone(customerPhoneQuery);
    if (!phone) return [];
    return customers.filter(customer => normalizePhone(customer.phone).includes(phone)).slice(0, 6);
  }, [customers, customerPhoneQuery]);

  const subtotal = cart.reduce(
    (sum, line) => sum + Math.max(0, Number(line.item.price) * line.quantity - line.discount),
    0,
  );
  const total = Math.max(0, subtotal - invoiceDiscount);
  const paid = Object.values(payments).reduce((sum, value) => sum + (Number(value) || 0), 0);
  const remaining = Math.max(0, total - paid);
  const change = Math.max(0, paid - total);

  const add = (item: Variant) => setCart(previous => {
    const found = previous.find(line => line.item.id === item.id);
    const stock = item.balances.reduce((sum, balance) => sum + balance.quantity, 0);
    return found
      ? previous.map(line => line.item.id === item.id
        ? { ...line, quantity: Math.min(line.quantity + 1, stock) }
        : line)
      : [...previous, { item, quantity: 1, discount: 0 }];
  });

  const update = (id: string, patch: Partial<CartLine>) => setCart(previous =>
    previous.map(line => line.item.id === id ? { ...line, ...patch } : line).filter(line => line.quantity > 0),
  );

  const refresh = () => {
    client.invalidateQueries({ queryKey: ['pos-products'] });
    client.invalidateQueries({ queryKey: ['sales'] });
    client.invalidateQueries({ queryKey: ['dash'] });
    client.invalidateQueries({ queryKey: ['pos-suspended'] });
  };

  const checkout = async () => {
    if (!context || !cart.length) return;
    const receiptWindow = shippingOrder ? null : openThermalReceiptWindow();
    try {
      const activePayments = paymentTypes
        .map(type => ({ method: type.key, amount: Number(payments[type.key]) || 0 }))
        .filter(payment => payment.amount > 0);
      const response = await api.post('/pos/sales', {
        warehouseId: context.warehouseId,
        channel: shippingOrder ? 'ONLINE' : 'POS',
        ...(shippingOrder ? { shippingName, shippingPhone, shippingAddress } : {}),
        customerId: customerId || undefined,
        discount: invoiceDiscount,
        paymentMethod: activePayments[0]?.method || 'CASH',
        payments: activePayments,
        idempotencyKey: crypto.randomUUID(),
        items: cart.map(line => ({
          variantId: line.item.id,
          quantity: line.quantity,
          discount: line.discount,
        })),
      });
      if (!shippingOrder) {
        const receiptSale = {
          ...response.data,
          cashierName: user?.name || cashier?.name,
          customer: customers.find(customer => customer.id === customerId),
          payments: activePayments,
          items: cart.map(line => ({
            quantity: line.quantity,
            unitPrice: Number(line.item.price),
            total: Math.max(0, Number(line.item.price) * line.quantity - line.discount),
            variant: { name: line.item.name, product: { name: line.item.product.name } },
          })),
        };
        setLastReceipt(receiptSale);
        const printed = printThermalReceipt(receiptSale, receiptWindow);
        setNotice(`تمت الفاتورة ${response.data.invoiceNo} بنجاح.${printed ? ' تم فتح طباعة الإيصال.' : ' اسمح بالنوافذ المنبثقة ثم اضغط «إعادة طباعة آخر فاتورة».'}`);
      } else {
        setNotice(`تم تسجيل أوردر الشحن ${response.data.invoiceNo}. المتبقي للتحصيل: ${egp.format(Number(response.data.due || 0))}`);
      }
      setCart([]);
      setCustomerId('');
      setCustomerPhoneQuery('');
      setCustomerSearchOpen(false);
      setInvoiceDiscount(0);
      setPayments({ CASH: '', CARD: '', VODAFONE_CASH: '', INSTAPAY: '' });
      setShippingName(''); setShippingPhone(''); setShippingAddress(''); setShippingOrder(false);
      refresh();
    } catch (error: any) {
      receiptWindow?.close();
      setNotice(error.response?.data?.message || 'تعذر إتمام البيع.');
    }
  };

  const suspend = async () => {
    if (!context || !cart.length) return;
    try {
      await api.post('/pos/suspended', {
        warehouseId: context.warehouseId,
        customerId: customerId || undefined,
        discount: invoiceDiscount,
        items: cart.map(line => ({ variantId: line.item.id, quantity: line.quantity })),
      });
      setCart([]);
      setNotice('تم تعليق الفاتورة ويمكن استعادتها من القائمة.');
      refresh();
    } catch (error: any) {
      setNotice(error.response?.data?.message || 'تعذر تعليق الفاتورة.');
    }
  };

  const resume = async (token: string) => {
    try {
      const { data } = await api.post('/pos/suspended/resume', { token });
      const saved = data.items as { variantId: string; quantity: number }[];
      setCart(saved.flatMap(line => {
        const item = variants.find(variant => variant.id === line.variantId);
        return item ? [{ item, quantity: line.quantity, discount: 0 }] : [];
      }));
      setCustomerId(data.customerId || '');
      const resumedCustomer = customers.find(customer => customer.id === data.customerId);
      setCustomerPhoneQuery(resumedCustomer?.phone || '');
      setCustomerSearchOpen(false);
      setInvoiceDiscount(Number(data.discount));
      setNotice('تمت استعادة الفاتورة المعلّقة.');
      refresh();
    } catch (error: any) {
      setNotice(error.response?.data?.message || 'تعذر استعادة الفاتورة.');
    }
  };

  const chooseCustomer = (customer: Customer) => {
    setCustomerId(customer.id);
    setCustomerPhoneQuery(customer.phone || '');
    setCustomerSearchOpen(false);
    setQuickPhone('');
  };

  const clearCustomer = () => {
    setCustomerId('');
    setCustomerPhoneQuery('');
    setCustomerSearchOpen(false);
  };

  const addCustomer = async (event: React.FormEvent) => {
    event.preventDefault();
    try {
      const { data } = await api.post('/customers', { name: quickName, phone: quickPhone || undefined });
      setCustomerId(data.id);
      setCustomerPhoneQuery(data.phone || quickPhone);
      setCustomerSearchOpen(false);
      setQuickName('');
      setQuickPhone('');
      client.invalidateQueries({ queryKey: ['pos-customers'] });
      setNotice('تمت إضافة العميل واختياره للفاتورة.');
    } catch (error: any) {
      setNotice(error.response?.data?.message || 'تعذر إضافة العميل.');
    }
  };

  return (
    <main className="content pos-content" dir="rtl">
      <header className="topbar pos-topbar">
        <div>
          <p className="eyebrow">DRAFT · نقطة البيع</p>
          <h1>نقطة البيع المتكاملة</h1>
          <p className="muted">امسح الباركود أو ابحث بالاسم وSKU، وأكمل الفاتورة من مكان واحد.</p>
        </div>
        <div className="top-status pos-top-status">
          <span className="status connected"><span aria-hidden="true">●</span> {context?.warehouseName || 'جارٍ الاتصال بالمخزن'}</span>
          <button className="secondary small" type="button" disabled={!lastReceipt} onClick={() => lastReceipt && printThermalReceipt(lastReceipt)}>
            <Printer size={16} /> إعادة طباعة آخر فاتورة
          </button>
        </div>
      </header>

      {notice && <p className="toast pos-toast" role="status">{notice}</p>}

      <div className="pos-layout">
        <section className="pos-products" aria-label="كتالوج المنتجات">
          <div className="toolbar pos-toolbar">
            <label className="search pos-search">
              <Barcode size={19} aria-hidden="true" />
              <input
                value={query}
                onChange={event => setQuery(event.target.value)}
                placeholder="امسح الباركود أو ابحث بالاسم / SKU"
                aria-label="بحث بالباركود أو اسم أو SKU المنتج"
                autoFocus
              />
            </label>
            <label className="pos-select-wrap">
              <span>القسم</span>
              <select aria-label="تصفية المنتجات حسب القسم" value={category} onChange={event => setCategory(event.target.value)}>
                {categories.map(value => <option key={value}>{value}</option>)}
              </select>
            </label>
            <label className="pos-select-wrap pos-held-select">
              <span>الفواتير المعلّقة</span>
              <select defaultValue="" aria-label="استعادة فاتورة معلقة" onChange={event => event.target.value && resume(event.target.value)}>
                <option value="">استعادة فاتورة معلقة</option>
                {suspended.map((row: any) => (
                  <option key={row.id} value={row.token}>
                    {row.token} · {new Date(row.createdAt).toLocaleTimeString('ar-EG')}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="pos-results-heading">
            <h2>الأصناف</h2>
            <span>{isLoading ? 'جارٍ التحميل…' : `${filtered.length} صنف`}</span>
          </div>

          {isLoading ? (
            <div className="pos-empty-results" role="status"><span className="pos-loader" />جارٍ تحميل الأصناف…</div>
          ) : filtered.length ? (
            <div className="product-grid pos-product-grid">
              {filtered.map(variant => {
                const stock = variant.balances.reduce((sum, balance) => sum + balance.quantity, 0);
                return <ProductCatalogCard key={variant.id} variant={variant} stock={stock} add={add} />;
              })}
            </div>
          ) : (
            <div className="pos-empty-results">
              <PackageSearch size={30} aria-hidden="true" />
              <strong>لا توجد أصناف مطابقة</strong>
              <span>جرّب كلمة بحث أخرى أو غيّر القسم المختار.</span>
            </div>
          )}
        </section>

        <aside className="cart pos-cart" aria-label="الفاتورة الحالية">
          <div className="cart-header pos-cart-header">
            <div>
              <p className="pos-kicker">فاتورة جديدة</p>
              <h2><ShoppingCart size={19} /> الفاتورة الحالية</h2>
            </div>
            <span>{cart.reduce((count, line) => count + line.quantity, 0)} قطعة</span>
          </div>

          <section className="shipping-order-mode" aria-label="نوع العملية">
            <button type="button" className={!shippingOrder ? 'selected' : ''} onClick={() => setShippingOrder(false)}>بيع مباشر</button>
            <button type="button" className={shippingOrder ? 'selected' : ''} onClick={() => setShippingOrder(true)}>أوردر أونلاين / شحن</button>
          </section>
          {shippingOrder && <section className="shipping-recipient-fields" aria-label="بيانات الشحن">
            <label>اسم المستلم<input value={shippingName} onChange={event => setShippingName(event.target.value)} placeholder="اسم العميل" required /></label>
            <label>رقم الهاتف<input value={shippingPhone} onChange={event => setShippingPhone(event.target.value)} placeholder="01xxxxxxxxx" inputMode="tel" required /></label>
            <label>عنوان الشحن<input value={shippingAddress} onChange={event => setShippingAddress(event.target.value)} placeholder="المحافظة، المنطقة، الشارع، تفاصيل العنوان" required /></label>
          </section>}

          <div className="pos-cart-body">
            {cart.length ? (
              <section className="pos-cart-section pos-items-section" aria-label="أصناف الفاتورة">
                <div className="pos-section-heading"><span>الأصناف المختارة</span><b>{cart.length}</b></div>
                <div className="pos-lines">
                  {cart.map(line => (
                    <article className="pos-cart-line" key={line.item.id}>
                      <div className="pos-line-info">
                        <b dir="auto">{line.item.product.name}</b>
                        <small>{line.item.name} · {egp.format(Number(line.item.price))}</small>
                        <label className="pos-line-discount">
                          <Tag size={13} />
                          <span className="visually-hidden">خصم {line.item.product.name}</span>
                          <input
                            type="number"
                            min="0"
                            value={line.discount || ''}
                            onChange={event => update(line.item.id, { discount: Number(event.target.value) || 0 })}
                            placeholder="خصم الصنف (ج.م.)"
                          />
                        </label>
                      </div>
                      <div className="qty pos-qty" aria-label="تعديل كمية الصنف">
                        <button type="button" aria-label={`تقليل كمية ${line.item.product.name}`} onClick={() => update(line.item.id, { quantity: line.quantity - 1 })}><Minus size={14} /></button>
                        <span>{line.quantity}</span>
                        <button type="button" aria-label={`زيادة كمية ${line.item.product.name}`} onClick={() => update(line.item.id, { quantity: line.quantity + 1 })}><Plus size={14} /></button>
                      </div>
                    </article>
                  ))}
                </div>
              </section>
            ) : (
              <div className="empty pos-empty-cart">
                <span className="pos-empty-icon"><ShoppingCart size={22} /></span>
                <b>السلة فارغة</b>
                <span>أضف صنفاً من الكتالوج أو استعد فاتورة معلّقة.</span>
              </div>
            )}

            <section className="pos-cart-section pos-customer-section">
              <div className="pos-section-heading"><span><UserRound size={15} /> العميل ونقاط الولاء</span></div>
              <div className="customer-picker pos-customer-picker">
                <label htmlFor="customer-phone">البحث برقم الهاتف</label>
                <div className="customer-phone-field">
                  <Search size={17} aria-hidden="true" />
                  <input
                    id="customer-phone"
                    value={customerPhoneQuery}
                    onFocus={() => setCustomerSearchOpen(true)}
                    onChange={event => {
                      setCustomerPhoneQuery(event.target.value);
                      setQuickPhone(event.target.value);
                      setCustomerId('');
                      setCustomerSearchOpen(true);
                    }}
                    placeholder="اكتب رقم تليفون العميل"
                    inputMode="tel"
                    autoComplete="off"
                  />
                  {customerId && <button type="button" onClick={clearCustomer}>تغيير</button>}
                </div>
                {customerSearchOpen && customerPhoneQuery && !customerId && (
                  <div className="customer-matches pos-customer-matches">
                    {customerMatches.length ? customerMatches.map(customer => (
                      <button type="button" key={customer.id} onClick={() => chooseCustomer(customer)}>
                        <span><b>{customer.name}</b><small>{customer.phone || 'بدون هاتف'}</small></span>
                        <strong>{customer.points} نقطة</strong>
                      </button>
                    )) : (
                      <p>لا يوجد عميل بهذا الرقم؛ يمكنك إضافته من «عميل سريع».</p>
                    )}
                  </div>
                )}
                {selectedCustomer && (
                  <div className="selected-customer pos-selected-customer">
                    <span><b>{selectedCustomer.name}</b><small>{selectedCustomer.phone || 'بدون هاتف'}</small></span>
                    <strong>{selectedCustomer.points} نقطة ولاء</strong>
                  </div>
                )}
              </div>
              <form className="inline-form pos-customer-form" onSubmit={addCustomer}>
                <input value={quickName} onChange={event => setQuickName(event.target.value)} placeholder="اسم عميل جديد" required aria-label="اسم العميل الجديد" />
                <input value={quickPhone} onChange={event => setQuickPhone(event.target.value)} placeholder="الهاتف" aria-label="هاتف العميل الجديد" />
                <button className="secondary small" aria-label="إضافة العميل"><UserPlus size={15} /></button>
              </form>
            </section>

            <section className="pos-cart-section pos-discount-section">
              <label className="pos-section-heading" htmlFor="invoice-discount"><span><BadgePercent size={15} /> خصم الفاتورة</span></label>
              <input
                id="invoice-discount"
                className="discount-input"
                type="number"
                min="0"
                value={invoiceDiscount || ''}
                onChange={event => setInvoiceDiscount(Number(event.target.value) || 0)}
                placeholder="قيمة الخصم بالجنيه"
              />
            </section>

            <section className="pos-cart-section pos-payment-section">
              <div className="pos-section-heading"><span><Banknote size={15} /> طرق الدفع</span><small>{shippingOrder ? 'اتركها فارغة للدفع عند الاستلام؛ أو سجّل دفعة جزئية/كاملة' : 'يمكن تقسيم المبلغ'}</small></div>
              <div className="payments pos-payments">
                {paymentTypes.map(({ key, label, Icon }) => (
                  <label key={key}>
                    <span><Icon size={16} />{label}</span>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={payments[key]}
                      onChange={event => setPayments(previous => ({ ...previous, [key]: event.target.value }))}
                      placeholder="0.00"
                      aria-label={`المبلغ المدفوع ${label}`}
                    />
                  </label>
                ))}
              </div>
            </section>
          </div>

          <footer className="cart-footer pos-cart-footer">
            <div className="pos-total-row">
              <div><span>الإجمالي المطلوب</span><strong>{egp.format(total)}</strong></div>
              <small>{cart.length} أصناف</small>
            </div>
            <div className="pos-payment-summary">
              <span>المدفوع <b>{egp.format(paid)}</b></span>
              <span>{change > 0 ? 'الباقي للعميل' : 'المتبقي'} <b>{egp.format(change > 0 ? change : remaining)}</b></span>
            </div>
            <div className="form-actions pos-actions">
              <button className="secondary" type="button" disabled={!cart.length} onClick={suspend}><PauseCircle size={16} /> تعليق</button>
              <button className="primary" type="button" disabled={!cart.length || (shippingOrder && (!shippingName.trim() || !shippingPhone.trim() || !shippingAddress.trim()))} onClick={checkout}><CheckCircle2 size={17} /> {shippingOrder ? 'تسجيل أوردر الشحن' : 'إتمام البيع'}</button>
            </div>
          </footer>
        </aside>
      </div>
    </main>
  );
}
