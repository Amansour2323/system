import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowDownLeft, ArrowUpLeft, BarChart3, Boxes, CalendarDays, CircleDollarSign, ReceiptText, TrendingUp } from 'lucide-react';
import { api } from './api-client';
import './monthly-dashboard.css';

const egp = new Intl.NumberFormat('ar-EG', { style: 'currency', currency: 'EGP', maximumFractionDigits: 2 });
const monthInCairo = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Cairo', year: 'numeric', month: '2-digit' }).format(new Date());

export function MonthlyDashboardPage() {
  const [month, setMonth] = useState(monthInCairo);
  const [year, monthNumber] = month.split('-').map(Number);
  const from = `${month}-01`;
  const to = new Date(Date.UTC(year, monthNumber, 0)).toISOString().slice(0, 10);
  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['monthly-dashboard', month],
    queryFn: async () => (await api.get(`/reports/summary?from=${from}&to=${to}`)).data,
  });
  const monthLabel = new Intl.DateTimeFormat('ar-EG', { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(Date.UTC(year, monthNumber - 1, 1)));
  const shiftMonth = (delta: number) => {
    const next = new Date(Date.UTC(year, monthNumber - 1 + delta, 1));
    setMonth(`${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, '0')}`);
  };
  const cards = [
    { label: 'إجمالي المبيعات', value: data?.revenue, note: `${data?.saleCount ?? 0} فاتورة خلال ${monthLabel}`, Icon: ReceiptText, tone: 'green' },
    { label: 'مصروفات الشهر', value: data?.expenses, note: `${data?.expenseCount ?? 0} عملية مصروفات`, Icon: ArrowUpLeft, tone: 'red' },
    { label: 'صافي الربح', value: data?.net, note: 'بعد المرتجعات وتكلفة المبيعات والمصروفات', Icon: TrendingUp, tone: 'gold' },
    { label: 'تكلفة البضاعة المباعة', value: data?.cogs, note: 'تكلفة الأصناف التي خرجت خلال الشهر', Icon: CircleDollarSign, tone: 'blue' },
    { label: 'تكلفة المخزون الحالي', value: data?.inventoryCost, note: 'قيمة المخزون المتاح الآن بالتكلفة', Icon: Boxes, tone: 'purple' },
  ];

  return <main className="content monthly-page">
    <header className="topbar"><div><p className="eyebrow">DRAFT · التقارير</p><h1>ملخص الشهر</h1><p className="muted">المبيعات والمصروفات والربح وتكلفة المخزون في شاشة واحدة.</p></div><div className="monthly-period"><button className="secondary" type="button" aria-label="الشهر السابق" onClick={() => shiftMonth(-1)}><ArrowDownLeft size={17}/></button><label><CalendarDays size={18}/><input aria-label="اختر الشهر" type="month" value={month} onChange={event => event.target.value && setMonth(event.target.value)} /></label><button className="secondary" type="button" aria-label="الشهر التالي" onClick={() => shiftMonth(1)}><ArrowUpLeft size={17}/></button></div></header>
    <section className="monthly-heading panel"><div><span className="monthly-kicker"><CalendarDays size={16}/> الفترة المحددة</span><h2>{monthLabel}</h2><p>تُحسب المبيعات والمصروفات حسب تاريخ اليومية المسجل لكل عملية.</p></div><div className="monthly-period-total"><small>صافي المبيعات بعد المرتجعات</small><strong>{isLoading ? '—' : egp.format(Number(data?.revenue || 0) - Number(data?.refund || 0))}</strong><span>{data?.returnCount ?? 0} مرتجع</span></div></section>
    {isError ? <section className="panel monthly-error"><b>تعذر تحميل ملخص الشهر</b><span>تأكد من اتصال النظام ثم حاول مرة أخرى.</span><button className="secondary" onClick={() => refetch()}>إعادة المحاولة</button></section> : <div className="monthly-stats">{cards.map(({ label, value, note, Icon, tone }) => <article className="monthly-stat panel" key={label}><div className={`monthly-stat-icon ${tone}`}><Icon size={21}/></div><div className="monthly-stat-copy"><p>{label}</p><strong>{isLoading ? '—' : egp.format(Number(value || 0))}</strong><small>{note}</small></div></article>)}</div>}
    <section className="panel monthly-breakdown"><div className="panel-title"><div><h2><BarChart3 size={19}/> تفاصيل {monthLabel}</h2><p>تفصيل يساعدك على مراجعة مصدر صافي الربح.</p></div></div><div className="monthly-rows">
      <div><span>إجمالي المبيعات</span><b>{isLoading ? '—' : egp.format(Number(data?.revenue || 0))}</b></div>
      <div><span>المرتجعات</span><b className="monthly-negative">− {isLoading ? '—' : egp.format(Number(data?.refund || 0))}</b></div>
      <div><span>تكلفة المبيعات بعد المرتجع</span><b className="monthly-negative">− {isLoading ? '—' : egp.format(Number(data?.cogs || 0))}</b></div>
      <div><span>المصروفات</span><b className="monthly-negative">− {isLoading ? '—' : egp.format(Number(data?.expenses || 0))}</b></div>
      <div className="monthly-net"><span>صافي الربح</span><b>{isLoading ? '—' : egp.format(Number(data?.net || 0))}</b></div>
    </div><p className="monthly-footnote">صافي الربح هنا = المبيعات بعد المرتجعات − تكلفة البضاعة المباعة بعد المرتجع − المصروفات. تكلفة المخزون في الأعلى لقطة حالية وليست قيمة تاريخية للشهر المحدد.</p></section>
  </main>;
}
