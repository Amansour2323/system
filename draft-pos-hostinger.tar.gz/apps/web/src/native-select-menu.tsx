import { Check } from 'lucide-react';
import { createPortal } from 'react-dom';
import { useEffect, useState } from 'react';

type ActiveSelect = { element: HTMLSelectElement; top: number; left: number; width: number };

const positionFor = (element: HTMLSelectElement): ActiveSelect => {
  const rect = element.getBoundingClientRect();
  return { element, top: rect.bottom + 6, left: rect.left, width: rect.width };
};

/** Converts every native select popup into the shared DRAFT listbox, without changing existing form logic. */
export function NativeSelectMenu() {
  const [active, setActive] = useState<ActiveSelect>();
  const close = () => setActive(undefined);

  useEffect(() => {
    const open = (element: HTMLSelectElement) => {
      if (element.disabled) return;
      setActive(positionFor(element));
    };
    const onMouseDown = (event: MouseEvent) => {
      const target = event.target as Element | null;
      if (target?.closest('.native-select-menu')) return;
      const select = target?.closest('select') as HTMLSelectElement | null;
      if (select) { event.preventDefault(); open(select); }
      else close();
    };
    const onKeyDown = (event: KeyboardEvent) => {
      const select = event.target instanceof HTMLSelectElement ? event.target : null;
      if (!select) { if (event.key === 'Escape') close(); return; }
      if (['Enter', ' ', 'ArrowDown', 'ArrowUp'].includes(event.key)) { event.preventDefault(); open(select); }
      if (event.key === 'Escape') close();
    };
    const reposition = () => active && setActive(positionFor(active.element));
    document.addEventListener('mousedown', onMouseDown, true);
    document.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('resize', reposition);
    window.addEventListener('scroll', reposition, true);
    return () => {
      document.removeEventListener('mousedown', onMouseDown, true);
      document.removeEventListener('keydown', onKeyDown, true);
      window.removeEventListener('resize', reposition);
      window.removeEventListener('scroll', reposition, true);
    };
  }, [active]);

  if (!active) return null;
  const options = Array.from(active.element.options);
  return createPortal(<div className="native-select-menu" role="listbox" aria-label={active.element.getAttribute('aria-label') || active.element.labels?.[0]?.textContent || 'قائمة اختيار'} style={{ top: active.top, left: active.left, width: active.width }}>
    {options.map(option => <button
      type="button"
      key={`${option.value}-${option.index}`}
      className={option.selected ? 'select-option selected' : 'select-option'}
      role="option"
      aria-selected={option.selected}
      disabled={option.disabled}
      onMouseDown={event => event.preventDefault()}
      onClick={() => {
        active.element.value = option.value;
        active.element.dispatchEvent(new Event('change', { bubbles: true }));
        active.element.focus();
        close();
      }}
    >
      <span>{option.text}</span>{option.selected && <Check size={16} aria-hidden="true" />}
    </button>)}
  </div>, document.body);
}
