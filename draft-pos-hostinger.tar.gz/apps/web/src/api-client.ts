import axios, { type InternalAxiosRequestConfig } from 'axios';

declare const __API_URL__: string;

export const api = axios.create({ baseURL: __API_URL__ });
let refreshInFlight: Promise<string> | undefined;

api.interceptors.request.use(config => {
  const token = localStorage.getItem('draft_access');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(response => response, async error => {
  const config = error.config as (InternalAxiosRequestConfig & { _draftRetried?: boolean }) | undefined;
  const url = config?.url || '';
  if (error.response?.status !== 401 || !config || config._draftRetried || url.includes('/auth/login') || url.includes('/auth/refresh')) {
    return Promise.reject(error);
  }

  const refreshToken = localStorage.getItem('draft_refresh');
  if (!refreshToken) {
    expireSession();
    return Promise.reject(error);
  }

  config._draftRetried = true;
  try {
    refreshInFlight ??= axios.post(`${__API_URL__}/auth/refresh`, { refreshToken }).then(({ data }) => {
      if (!data.accessToken || !data.refreshToken) throw new Error('Invalid token refresh response');
      localStorage.setItem('draft_access', data.accessToken);
      localStorage.setItem('draft_refresh', data.refreshToken);
      return data.accessToken as string;
    }).finally(() => { refreshInFlight = undefined; });
    const accessToken = await refreshInFlight;
    config.headers.Authorization = `Bearer ${accessToken}`;
    return api.request(config).catch(retryError => {
      if (axios.isAxiosError(retryError) && retryError.response?.status === 401) expireSession();
      throw retryError;
    });
  } catch (refreshError) {
    expireSession();
    return Promise.reject(refreshError);
  }
});

function expireSession() {
  localStorage.removeItem('draft_access');
  localStorage.removeItem('draft_refresh');
  window.dispatchEvent(new Event('draft:session-expired'));
}
