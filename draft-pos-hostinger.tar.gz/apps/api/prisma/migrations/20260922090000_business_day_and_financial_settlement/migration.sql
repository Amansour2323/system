-- التاريخ التشغيلي يربط حركة ما بعد منتصف الليل (حتى 01:00 بتوقيت القاهرة)
-- بيومية اليوم السابق، بدلاً من فصل وردية المساء إلى يومين تقويميين.
ALTER TABLE "Sale" ADD COLUMN "businessDate" DATE;
ALTER TABLE "SaleReturn" ADD COLUMN "businessDate" DATE;
ALTER TABLE "SaleReturn" ADD COLUMN "refundMethod" "PaymentMethod" NOT NULL DEFAULT 'CASH';
ALTER TABLE "SalePayment" ADD COLUMN "businessDate" DATE;
ALTER TABLE "Purchase" ADD COLUMN "businessDate" DATE;
ALTER TABLE "SupplierPayment" ADD COLUMN "businessDate" DATE;
ALTER TABLE "SupplierReturn" ADD COLUMN "businessDate" DATE;
ALTER TABLE "Expense" ADD COLUMN "businessDate" DATE;
ALTER TABLE "DrawerSession" ADD COLUMN "businessDate" DATE;
ALTER TABLE "CashMovement" ADD COLUMN "businessDate" DATE;
ALTER TABLE "JournalEntry" ADD COLUMN "businessDate" DATE;

-- البيانات التاريخية لا تترك فارغة؛ الترحيل الجديد يحسب التاريخ بتوقيت القاهرة.
UPDATE "Sale" SET "businessDate" = "createdAt"::date WHERE "businessDate" IS NULL;
UPDATE "SaleReturn" SET "businessDate" = "createdAt"::date WHERE "businessDate" IS NULL;
UPDATE "SalePayment" SET "businessDate" = "createdAt"::date WHERE "businessDate" IS NULL;
UPDATE "Purchase" SET "businessDate" = "createdAt"::date WHERE "businessDate" IS NULL;
UPDATE "SupplierPayment" SET "businessDate" = "createdAt"::date WHERE "businessDate" IS NULL;
UPDATE "SupplierReturn" SET "businessDate" = "createdAt"::date WHERE "businessDate" IS NULL;
UPDATE "Expense" SET "businessDate" = "occurredAt"::date WHERE "businessDate" IS NULL;
UPDATE "DrawerSession" SET "businessDate" = "openedAt"::date WHERE "businessDate" IS NULL;
UPDATE "CashMovement" SET "businessDate" = "createdAt"::date WHERE "businessDate" IS NULL;
UPDATE "JournalEntry" SET "businessDate" = "occurredAt"::date WHERE "businessDate" IS NULL;

ALTER TABLE "Sale" ALTER COLUMN "businessDate" SET NOT NULL;
ALTER TABLE "SaleReturn" ALTER COLUMN "businessDate" SET NOT NULL;
ALTER TABLE "SalePayment" ALTER COLUMN "businessDate" SET NOT NULL;
ALTER TABLE "Purchase" ALTER COLUMN "businessDate" SET NOT NULL;
ALTER TABLE "SupplierPayment" ALTER COLUMN "businessDate" SET NOT NULL;
ALTER TABLE "SupplierReturn" ALTER COLUMN "businessDate" SET NOT NULL;
ALTER TABLE "Expense" ALTER COLUMN "businessDate" SET NOT NULL;
ALTER TABLE "DrawerSession" ALTER COLUMN "businessDate" SET NOT NULL;
ALTER TABLE "CashMovement" ALTER COLUMN "businessDate" SET NOT NULL;
ALTER TABLE "JournalEntry" ALTER COLUMN "businessDate" SET NOT NULL;

CREATE INDEX "Sale_businessDate_status_idx" ON "Sale"("businessDate", "status");
CREATE INDEX "Purchase_businessDate_createdAt_idx" ON "Purchase"("businessDate", "createdAt");
