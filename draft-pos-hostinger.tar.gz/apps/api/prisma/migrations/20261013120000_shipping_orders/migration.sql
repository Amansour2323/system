CREATE TYPE "SaleChannel" AS ENUM ('POS', 'ONLINE');
CREATE TYPE "ShippingStatus" AS ENUM ('PENDING', 'PREPARING', 'SHIPPED', 'DELIVERED');

ALTER TABLE "Sale"
  ADD COLUMN "channel" "SaleChannel" NOT NULL DEFAULT 'POS',
  ADD COLUMN "shippingStatus" "ShippingStatus",
  ADD COLUMN "shippingName" TEXT,
  ADD COLUMN "shippingPhone" TEXT,
  ADD COLUMN "shippingAddress" TEXT;

INSERT INTO "Account" ("id", "code", "name", "type")
VALUES (gen_random_uuid()::text, '1100', 'ذمم أوردرات الشحن', 'ASSET')
ON CONFLICT ("code") DO NOTHING;
