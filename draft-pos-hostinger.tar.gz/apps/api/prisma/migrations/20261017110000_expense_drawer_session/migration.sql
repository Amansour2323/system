ALTER TABLE "Expense" ADD COLUMN "drawerSessionId" TEXT;

CREATE INDEX "Expense_drawerSessionId_idx" ON "Expense"("drawerSessionId");
CREATE INDEX "Expense_businessDate_createdById_idx" ON "Expense"("businessDate", "createdById");

ALTER TABLE "Expense"
ADD CONSTRAINT "Expense_drawerSessionId_fkey"
FOREIGN KEY ("drawerSessionId") REFERENCES "DrawerSession"("id")
ON DELETE SET NULL ON UPDATE CASCADE;

-- Backfill only when there is a single matching shift for the cashier and business day.
UPDATE "Expense" AS expense
SET "drawerSessionId" = (
  SELECT session.id
  FROM "DrawerSession" AS session
  WHERE session."userId" = expense."createdById"
    AND session."businessDate" = expense."businessDate"
)
WHERE expense."drawerSessionId" IS NULL
  AND (
    SELECT COUNT(*)
    FROM "DrawerSession" AS session
    WHERE session."userId" = expense."createdById"
      AND session."businessDate" = expense."businessDate"
  ) = 1;
