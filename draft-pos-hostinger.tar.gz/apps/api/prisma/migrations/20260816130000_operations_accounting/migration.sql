CREATE TYPE "TransferStatus" AS ENUM ('DRAFT','REQUESTED','APPROVED','IN_TRANSIT','RECEIVED','CANCELLED');
CREATE TYPE "InventoryCountStatus" AS ENUM ('DRAFT','SUBMITTED','APPROVED','CANCELLED');
CREATE TYPE "PurchaseOrderStatus" AS ENUM ('DRAFT','APPROVED','PARTIALLY_RECEIVED','RECEIVED','CANCELLED');
CREATE TYPE "JournalStatus" AS ENUM ('POSTED','VOID');
CREATE TYPE "FiscalPeriodStatus" AS ENUM ('OPEN','CLOSED');

CREATE TABLE "SalePayment" ("id" TEXT PRIMARY KEY,"saleId" TEXT NOT NULL REFERENCES "Sale"("id") ON DELETE CASCADE,"method" "PaymentMethod" NOT NULL,"amount" DECIMAL(12,2) NOT NULL,"reference" TEXT,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX "SalePayment_saleId_idx" ON "SalePayment"("saleId");
CREATE TABLE "SuspendedSale" ("id" TEXT PRIMARY KEY,"token" TEXT NOT NULL UNIQUE,"warehouseId" TEXT NOT NULL,"customerId" TEXT,"items" JSONB NOT NULL,"discount" DECIMAL(12,2) NOT NULL DEFAULT 0,"note" TEXT,"createdById" TEXT NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"expiresAt" TIMESTAMP(3));

CREATE TABLE "InventoryCount" ("id" TEXT PRIMARY KEY,"number" TEXT NOT NULL UNIQUE,"warehouseId" TEXT NOT NULL REFERENCES "Warehouse"("id"),"status" "InventoryCountStatus" NOT NULL DEFAULT 'DRAFT',"notes" TEXT,"createdById" TEXT NOT NULL,"approvedById" TEXT,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"approvedAt" TIMESTAMP(3));
CREATE INDEX "InventoryCount_warehouseId_status_idx" ON "InventoryCount"("warehouseId","status");
CREATE TABLE "InventoryCountItem" ("id" TEXT PRIMARY KEY,"inventoryCountId" TEXT NOT NULL REFERENCES "InventoryCount"("id") ON DELETE CASCADE,"variantId" TEXT NOT NULL REFERENCES "ProductVariant"("id"),"expectedQuantity" INTEGER NOT NULL,"countedQuantity" INTEGER,UNIQUE("inventoryCountId","variantId"));

CREATE TABLE "StockTransfer" ("id" TEXT PRIMARY KEY,"number" TEXT NOT NULL UNIQUE,"fromWarehouseId" TEXT NOT NULL REFERENCES "Warehouse"("id"),"toWarehouseId" TEXT NOT NULL REFERENCES "Warehouse"("id"),"status" "TransferStatus" NOT NULL DEFAULT 'DRAFT',"notes" TEXT,"requestedById" TEXT NOT NULL,"approvedById" TEXT,"receivedById" TEXT,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"approvedAt" TIMESTAMP(3),"shippedAt" TIMESTAMP(3),"receivedAt" TIMESTAMP(3));
CREATE INDEX "StockTransfer_fromWarehouseId_status_idx" ON "StockTransfer"("fromWarehouseId","status");
CREATE INDEX "StockTransfer_toWarehouseId_status_idx" ON "StockTransfer"("toWarehouseId","status");
CREATE TABLE "StockTransferItem" ("id" TEXT PRIMARY KEY,"stockTransferId" TEXT NOT NULL REFERENCES "StockTransfer"("id") ON DELETE CASCADE,"variantId" TEXT NOT NULL REFERENCES "ProductVariant"("id"),"requestedQuantity" INTEGER NOT NULL,"sentQuantity" INTEGER,"receivedQuantity" INTEGER,UNIQUE("stockTransferId","variantId"));

CREATE TABLE "PurchaseOrder" ("id" TEXT PRIMARY KEY,"number" TEXT NOT NULL UNIQUE,"supplierId" TEXT NOT NULL REFERENCES "Supplier"("id"),"warehouseId" TEXT NOT NULL,"status" "PurchaseOrderStatus" NOT NULL DEFAULT 'DRAFT',"expectedAt" TIMESTAMP(3),"notes" TEXT,"createdById" TEXT NOT NULL,"approvedById" TEXT,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX "PurchaseOrder_supplierId_status_idx" ON "PurchaseOrder"("supplierId","status");
CREATE TABLE "PurchaseOrderItem" ("id" TEXT PRIMARY KEY,"purchaseOrderId" TEXT NOT NULL REFERENCES "PurchaseOrder"("id") ON DELETE CASCADE,"variantId" TEXT NOT NULL REFERENCES "ProductVariant"("id"),"orderedQuantity" INTEGER NOT NULL,"receivedQuantity" INTEGER NOT NULL DEFAULT 0,"unitCost" DECIMAL(12,2) NOT NULL,UNIQUE("purchaseOrderId","variantId"));

CREATE TABLE "SupplierPayment" ("id" TEXT PRIMARY KEY,"number" TEXT NOT NULL UNIQUE,"supplierId" TEXT NOT NULL REFERENCES "Supplier"("id"),"purchaseId" TEXT REFERENCES "Purchase"("id"),"amount" DECIMAL(12,2) NOT NULL,"method" "PaymentMethod" NOT NULL,"reference" TEXT,"createdById" TEXT NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX "SupplierPayment_supplierId_createdAt_idx" ON "SupplierPayment"("supplierId","createdAt");
CREATE TABLE "SupplierReturn" ("id" TEXT PRIMARY KEY,"number" TEXT NOT NULL UNIQUE,"supplierId" TEXT NOT NULL REFERENCES "Supplier"("id"),"purchaseId" TEXT,"warehouseId" TEXT NOT NULL,"reason" TEXT NOT NULL,"createdById" TEXT NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX "SupplierReturn_supplierId_createdAt_idx" ON "SupplierReturn"("supplierId","createdAt");
CREATE TABLE "SupplierReturnItem" ("id" TEXT PRIMARY KEY,"supplierReturnId" TEXT NOT NULL REFERENCES "SupplierReturn"("id") ON DELETE CASCADE,"variantId" TEXT NOT NULL REFERENCES "ProductVariant"("id"),"quantity" INTEGER NOT NULL,"unitCost" DECIMAL(12,2) NOT NULL);

CREATE TABLE "Account" ("id" TEXT PRIMARY KEY,"code" TEXT NOT NULL UNIQUE,"name" TEXT NOT NULL,"type" TEXT NOT NULL,"active" BOOLEAN NOT NULL DEFAULT true,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE "JournalEntry" ("id" TEXT PRIMARY KEY,"number" TEXT NOT NULL UNIQUE,"status" "JournalStatus" NOT NULL DEFAULT 'POSTED',"occurredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"description" TEXT NOT NULL,"referenceType" TEXT,"referenceId" TEXT,"createdById" TEXT NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX "JournalEntry_occurredAt_idx" ON "JournalEntry"("occurredAt");
CREATE TABLE "JournalLine" ("id" TEXT PRIMARY KEY,"journalEntryId" TEXT NOT NULL REFERENCES "JournalEntry"("id") ON DELETE CASCADE,"accountId" TEXT NOT NULL REFERENCES "Account"("id"),"debit" DECIMAL(12,2) NOT NULL DEFAULT 0,"credit" DECIMAL(12,2) NOT NULL DEFAULT 0,"description" TEXT);
CREATE INDEX "JournalLine_accountId_idx" ON "JournalLine"("accountId");
CREATE TABLE "FiscalPeriod" ("id" TEXT PRIMARY KEY,"name" TEXT NOT NULL UNIQUE,"startsAt" TIMESTAMP(3) NOT NULL,"endsAt" TIMESTAMP(3) NOT NULL,"status" "FiscalPeriodStatus" NOT NULL DEFAULT 'OPEN',"closedById" TEXT,"closedAt" TIMESTAMP(3));

CREATE TABLE "Role" ("id" TEXT PRIMARY KEY,"code" TEXT NOT NULL UNIQUE,"name" TEXT NOT NULL,"system" BOOLEAN NOT NULL DEFAULT false);
CREATE TABLE "Permission" ("id" TEXT PRIMARY KEY,"code" TEXT NOT NULL UNIQUE,"name" TEXT NOT NULL);
CREATE TABLE "RolePermission" ("roleId" TEXT NOT NULL REFERENCES "Role"("id") ON DELETE CASCADE,"permissionId" TEXT NOT NULL REFERENCES "Permission"("id") ON DELETE CASCADE,PRIMARY KEY("roleId","permissionId"));
CREATE TABLE "UserRole" ("userId" TEXT NOT NULL REFERENCES "User"("id") ON DELETE CASCADE,"roleId" TEXT NOT NULL REFERENCES "Role"("id") ON DELETE CASCADE,PRIMARY KEY("userId","roleId"));
CREATE TABLE "Attachment" ("id" TEXT PRIMARY KEY,"entityType" TEXT NOT NULL,"entityId" TEXT NOT NULL,"fileName" TEXT NOT NULL,"originalName" TEXT NOT NULL,"mimeType" TEXT NOT NULL,"size" INTEGER NOT NULL,"createdById" TEXT NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX "Attachment_entityType_entityId_idx" ON "Attachment"("entityType","entityId");
