CREATE TYPE "ProductOwnership" AS ENUM ('OWNED', 'CONSIGNMENT');
CREATE TYPE "ConsignmentSettlementMode" AS ENUM ('OWNER_FIXED_PRICE', 'STORE_PERCENT', 'STORE_FIXED');

ALTER TABLE "Product"
  ADD COLUMN "ownership" "ProductOwnership" NOT NULL DEFAULT 'OWNED',
  ADD COLUMN "settlementMode" "ConsignmentSettlementMode",
  ADD COLUMN "ownerUnitPrice" DECIMAL(12,2),
  ADD COLUMN "storeCommissionPercent" DECIMAL(5,2),
  ADD COLUMN "storeCommissionPerUnit" DECIMAL(12,2);

ALTER TABLE "SaleItem"
  ADD COLUMN "ownerSupplierId" TEXT,
  ADD COLUMN "ownerPayout" DECIMAL(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN "storeCommission" DECIMAL(12,2) NOT NULL DEFAULT 0;
ALTER TABLE "SaleItem" ADD CONSTRAINT "SaleItem_ownerSupplierId_fkey"
  FOREIGN KEY ("ownerSupplierId") REFERENCES "Supplier"("id") ON DELETE SET NULL ON UPDATE CASCADE;
CREATE INDEX "SaleItem_ownerSupplierId_idx" ON "SaleItem"("ownerSupplierId");

CREATE TABLE "ConsignmentSettlement" (
  "id" TEXT NOT NULL,
  "number" TEXT NOT NULL,
  "supplierId" TEXT NOT NULL,
  "amount" DECIMAL(12,2) NOT NULL,
  "method" "PaymentMethod" NOT NULL,
  "reference" TEXT,
  "createdById" TEXT NOT NULL,
  "businessDate" DATE NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ConsignmentSettlement_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "ConsignmentSettlement_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES "Supplier"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE UNIQUE INDEX "ConsignmentSettlement_number_key" ON "ConsignmentSettlement"("number");
CREATE INDEX "ConsignmentSettlement_supplierId_createdAt_idx" ON "ConsignmentSettlement"("supplierId", "createdAt");

INSERT INTO "Account" ("id", "code", "name", "type", "active", "createdAt")
VALUES ('consignment-payable-account', '2200', 'مستحقات أصحاب بضاعة الأمانة', 'LIABILITY', true, CURRENT_TIMESTAMP)
ON CONFLICT ("code") DO NOTHING;
