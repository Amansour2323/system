ALTER TYPE "ShippingStatus" ADD VALUE 'PARTIALLY_DELIVERED';
ALTER TYPE "ShippingStatus" ADD VALUE 'RETURNED';

ALTER TABLE "SaleReturn"
  ADD COLUMN "replacementSaleId" TEXT;

ALTER TABLE "SaleReturn"
  ADD CONSTRAINT "SaleReturn_replacementSaleId_fkey"
  FOREIGN KEY ("replacementSaleId") REFERENCES "Sale"("id")
  ON DELETE SET NULL ON UPDATE CASCADE;

CREATE INDEX "SaleReturn_replacementSaleId_idx" ON "SaleReturn"("replacementSaleId");
