CREATE TYPE "CashMovementType" AS ENUM ('DRAWER_TO_SAFE', 'SAFE_DEPOSIT', 'SAFE_WITHDRAWAL');
CREATE TYPE "CashMovementStatus" AS ENUM ('PENDING', 'APPROVED', 'REJECTED');

ALTER TABLE "Sale" ADD COLUMN "drawerSessionId" TEXT;
ALTER TABLE "DrawerSession" ADD COLUMN "expectedAmount" DECIMAL(12,2);
ALTER TABLE "DrawerSession" ADD COLUMN "cashSalesTotal" DECIMAL(12,2) NOT NULL DEFAULT 0;
ALTER TABLE "DrawerSession" ADD COLUMN "cashSalesCount" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "Sale" ADD CONSTRAINT "Sale_drawerSessionId_fkey" FOREIGN KEY ("drawerSessionId") REFERENCES "DrawerSession"("id") ON DELETE SET NULL ON UPDATE CASCADE;
CREATE INDEX "Sale_drawerSessionId_idx" ON "Sale"("drawerSessionId");

CREATE TABLE "CashMovement" (
  "id" TEXT NOT NULL,
  "number" TEXT NOT NULL,
  "type" "CashMovementType" NOT NULL,
  "status" "CashMovementStatus" NOT NULL DEFAULT 'PENDING',
  "amount" DECIMAL(12,2) NOT NULL,
  "reason" TEXT NOT NULL,
  "drawerSessionId" TEXT,
  "requestedById" TEXT NOT NULL,
  "approvedById" TEXT,
  "approvedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "CashMovement_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "CashMovement_number_key" UNIQUE ("number"),
  CONSTRAINT "CashMovement_drawerSessionId_fkey" FOREIGN KEY ("drawerSessionId") REFERENCES "DrawerSession"("id") ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE INDEX "CashMovement_status_createdAt_idx" ON "CashMovement"("status", "createdAt");
CREATE INDEX "CashMovement_drawerSessionId_idx" ON "CashMovement"("drawerSessionId");
