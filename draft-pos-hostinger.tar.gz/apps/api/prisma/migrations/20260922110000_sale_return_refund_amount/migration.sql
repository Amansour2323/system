ALTER TABLE "SaleReturn" ADD COLUMN "refundAmount" DECIMAL(12,2) NOT NULL DEFAULT 0;
UPDATE "SaleReturn" SET "refundAmount" = "total" WHERE "drawerSessionId" IS NOT NULL;
