ALTER TABLE "CashMovement" ADD COLUMN "paymentMethod" "PaymentMethod" NOT NULL DEFAULT 'CASH';
CREATE INDEX "CashMovement_paymentMethod_status_idx" ON "CashMovement"("paymentMethod", "status");
