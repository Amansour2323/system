-- المرتجعات تؤثر في رصيد درج الوردية ووسيلة الدفع التي تم منها الاسترداد.
ALTER TABLE "SaleReturn" ADD COLUMN "drawerSessionId" TEXT;
ALTER TABLE "SaleReturn" ADD CONSTRAINT "SaleReturn_drawerSessionId_fkey" FOREIGN KEY ("drawerSessionId") REFERENCES "DrawerSession"("id") ON DELETE SET NULL ON UPDATE CASCADE;
CREATE INDEX "SaleReturn_drawerSessionId_idx" ON "SaleReturn"("drawerSessionId");
