-- تهيئة الحسابات قبل ترحيل القيود التاريخية؛ seed سيكمل تسميتها بعد الهجرة.
INSERT INTO "Account" ("id", "code", "name", "type")
SELECT gen_random_uuid()::text, code, name, kind
FROM (VALUES
  ('1000','الخزنة النقدية','ASSET'), ('1001','نقدية الدرج','ASSET'),
  ('1011','تسويات البطاقات البنكية','ASSET'), ('1012','محفظة Vodafone Cash','ASSET'), ('1013','محفظة InstaPay','ASSET'),
  ('1111','تحصيل بطاقات لدى الدرج','ASSET'), ('1112','تحصيل Vodafone Cash لدى الدرج','ASSET'), ('1113','تحصيل InstaPay لدى الدرج','ASSET'),
  ('2101','مقاصة تمويل وسحب الخزنة','LIABILITY'), ('4100','زيادة الجرد النقدي','REVENUE'), ('6100','عجز الجرد النقدي','EXPENSE')
) AS accounts(code, name, kind)
ON CONFLICT ("code") DO NOTHING;

-- القيود القديمة للبيع والمرتجع والإلغاء كانت تُحمل على الخزنة مباشرة.
UPDATE "JournalLine" AS line SET "accountId" = drawer.id
FROM "JournalEntry" AS entry, "Account" AS safe, "Account" AS drawer
WHERE line."journalEntryId" = entry.id
  AND line."accountId" = safe.id
  AND entry."referenceType" IN ('Sale', 'SaleReturn', 'SaleCancel')
  AND drawer."code" = CASE safe."code"
    WHEN '1000' THEN '1001' WHEN '1011' THEN '1111'
    WHEN '1012' THEN '1112' WHEN '1013' THEN '1113'
    ELSE '' END;

WITH created AS (
  INSERT INTO "JournalEntry" ("id", "number", "occurredAt", "businessDate", "description", "referenceType", "referenceId", "createdById")
  SELECT gen_random_uuid()::text, 'BACKFILL-OPEN-' || session.id, session."openedAt", session."businessDate",
         'تسوية عهدة افتتاح درج سابقة', 'DrawerSessionOpen', session.id, session."userId"
  FROM "DrawerSession" AS session
  WHERE session."openingAmount" > 0
    AND NOT EXISTS (SELECT 1 FROM "JournalEntry" AS entry WHERE entry."referenceType" IN ('DrawerSessionOpen', 'DrawerSession') AND entry."referenceId" = session.id AND entry.description LIKE '%عهدة افتتاح%')
  RETURNING "id", "referenceId"
)
INSERT INTO "JournalLine" ("id", "journalEntryId", "accountId", "debit", "credit")
SELECT gen_random_uuid()::text, created.id, account.id, lines.debit, lines.credit
FROM created
JOIN "DrawerSession" AS session ON session.id = created."referenceId"
CROSS JOIN LATERAL (VALUES
  ('1001', session."openingAmount", 0::numeric),
  ('2101', 0::numeric, session."openingAmount")
) AS lines(code, debit, credit)
JOIN "Account" AS account ON account.code = lines.code;

WITH created AS (
  INSERT INTO "JournalEntry" ("id", "number", "occurredAt", "businessDate", "description", "referenceType", "referenceId", "createdById")
  SELECT gen_random_uuid()::text, 'BACKFILL-CLOSE-' || session.id, COALESCE(session."closedAt", session."openedAt"), session."businessDate",
         'تسوية فرق إقفال درج سابق', 'DrawerSessionClose', session.id, session."userId"
  FROM "DrawerSession" AS session
  WHERE session.status = 'CLOSED'
    AND session."closingAmount" IS NOT NULL
    AND ABS(session."closingAmount" - COALESCE(session."expectedAmount", session."openingAmount" + session."cashSalesTotal")) > 0.005
    AND NOT EXISTS (SELECT 1 FROM "JournalEntry" AS entry WHERE entry."referenceType" IN ('DrawerSessionClose', 'DrawerSession') AND entry."referenceId" = session.id AND (entry.description LIKE '%عجز درج%' OR entry.description LIKE '%زيادة درج%' OR entry.description LIKE '%فرق إقفال%'))
  RETURNING "id", "referenceId"
)
INSERT INTO "JournalLine" ("id", "journalEntryId", "accountId", "debit", "credit")
SELECT gen_random_uuid()::text, created.id, account.id, lines.debit, lines.credit
FROM created
JOIN "DrawerSession" AS session ON session.id = created."referenceId"
CROSS JOIN LATERAL (SELECT session."closingAmount" - COALESCE(session."expectedAmount", session."openingAmount" + session."cashSalesTotal") AS difference) AS variance
CROSS JOIN LATERAL (VALUES
  (CASE WHEN variance.difference > 0 THEN '1001' ELSE '6100' END, ABS(variance.difference), 0::numeric),
  (CASE WHEN variance.difference > 0 THEN '4100' ELSE '1001' END, 0::numeric, ABS(variance.difference))
) AS lines(code, debit, credit)
JOIN "Account" AS account ON account.code = lines.code;

WITH created AS (
  INSERT INTO "JournalEntry" ("id", "number", "occurredAt", "businessDate", "description", "referenceType", "referenceId", "createdById")
  SELECT gen_random_uuid()::text, 'BACKFILL-MOVE-' || movement.id, COALESCE(movement."approvedAt", movement."createdAt"), movement."businessDate",
         'تسوية حركة خزنة معتمدة سابقة', 'CashMovement', movement.id, movement."requestedById"
  FROM "CashMovement" AS movement
  WHERE movement.status = 'APPROVED' AND movement.amount > 0
    AND NOT EXISTS (SELECT 1 FROM "JournalEntry" AS entry WHERE entry."referenceType" = 'CashMovement' AND entry."referenceId" = movement.id)
  RETURNING "id", "referenceId"
)
INSERT INTO "JournalLine" ("id", "journalEntryId", "accountId", "debit", "credit")
SELECT gen_random_uuid()::text, created.id, account.id, lines.debit, lines.credit
FROM created
JOIN "CashMovement" AS movement ON movement.id = created."referenceId"
CROSS JOIN LATERAL (SELECT CASE movement."paymentMethod"
  WHEN 'CASH' THEN '1000' WHEN 'CARD' THEN '1011' WHEN 'VODAFONE_CASH' THEN '1012' ELSE '1013' END AS safe_code,
  CASE movement."paymentMethod"
  WHEN 'CASH' THEN '1001' WHEN 'CARD' THEN '1111' WHEN 'VODAFONE_CASH' THEN '1112' ELSE '1113' END AS drawer_code) AS codes
CROSS JOIN LATERAL (VALUES
  (CASE WHEN movement.type = 'SAFE_WITHDRAWAL' THEN '2101' ELSE codes.safe_code END, movement.amount, 0::numeric),
  (CASE WHEN movement.type = 'DRAWER_TO_SAFE' THEN codes.drawer_code WHEN movement.type = 'SAFE_DEPOSIT' THEN '2101' ELSE codes.safe_code END, 0::numeric, movement.amount)
) AS lines(code, debit, credit)
JOIN "Account" AS account ON account.code = lines.code;
