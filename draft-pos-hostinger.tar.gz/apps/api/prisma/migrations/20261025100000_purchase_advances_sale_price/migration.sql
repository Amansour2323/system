ALTER TABLE "PurchaseItem" ADD COLUMN "salePrice" DECIMAL(12,2);
ALTER TABLE "PurchaseOrderItem" ADD COLUMN "salePrice" DECIMAL(12,2);

CREATE TABLE "PurchaseAdvance" (
  "id" TEXT NOT NULL,
  "number" TEXT NOT NULL,
  "recipient" TEXT NOT NULL,
  "purpose" TEXT NOT NULL,
  "amount" DECIMAL(12,2) NOT NULL,
  "spent" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "returned" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "paymentMethod" "PaymentMethod" NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'OPEN',
  "createdById" TEXT NOT NULL,
  "businessDate" DATE NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PurchaseAdvance_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "PurchaseAdvance_number_key" ON "PurchaseAdvance"("number");
CREATE INDEX "PurchaseAdvance_status_createdAt_idx" ON "PurchaseAdvance"("status", "createdAt");

ALTER TABLE "CashMovement" ADD COLUMN "purchaseAdvanceId" TEXT;
ALTER TABLE "CashMovement" ADD CONSTRAINT "CashMovement_purchaseAdvanceId_fkey"
  FOREIGN KEY ("purchaseAdvanceId") REFERENCES "PurchaseAdvance"("id") ON DELETE SET NULL ON UPDATE CASCADE;
CREATE INDEX "CashMovement_purchaseAdvanceId_idx" ON "CashMovement"("purchaseAdvanceId");

ALTER TABLE "SupplierPayment" ADD COLUMN "purchaseAdvanceId" TEXT;
ALTER TABLE "SupplierPayment" ADD CONSTRAINT "SupplierPayment_purchaseAdvanceId_fkey"
  FOREIGN KEY ("purchaseAdvanceId") REFERENCES "PurchaseAdvance"("id") ON DELETE SET NULL ON UPDATE CASCADE;
CREATE INDEX "SupplierPayment_purchaseAdvanceId_idx" ON "SupplierPayment"("purchaseAdvanceId");

INSERT INTO "Account" ("id", "code", "name", "type")
VALUES (gen_random_uuid()::text, '1210', 'عهد مشتريات غير مسواة', 'ASSET')
ON CONFLICT ("code") DO NOTHING;
