CREATE TABLE "SupplierPaymentSchedule" (
  "id" TEXT NOT NULL,
  "supplierId" TEXT NOT NULL,
  "amount" DECIMAL(12,2) NOT NULL,
  "frequency" TEXT NOT NULL,
  "startDate" DATE NOT NULL,
  "endDate" DATE,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "note" TEXT,
  "createdById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "SupplierPaymentSchedule_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "SupplierPaymentSchedule_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES "Supplier"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX "SupplierPaymentSchedule_supplierId_active_startDate_idx" ON "SupplierPaymentSchedule"("supplierId", "active", "startDate");
