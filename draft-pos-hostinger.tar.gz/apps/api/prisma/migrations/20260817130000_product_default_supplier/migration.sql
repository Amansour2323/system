ALTER TABLE "Product" ADD COLUMN "supplierId" TEXT;
CREATE INDEX "Product_supplierId_idx" ON "Product"("supplierId");
ALTER TABLE "Product" ADD CONSTRAINT "Product_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES "Supplier"("id") ON DELETE SET NULL ON UPDATE CASCADE;
