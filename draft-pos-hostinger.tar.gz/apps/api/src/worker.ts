import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const log = (level: 'info'|'error', event: string, extra: Record<string, unknown> = {}) => process.stdout.write(`${JSON.stringify({ timestamp: new Date().toISOString(), service: 'draft-worker', level, event, ...extra })}\n`);

async function runMaintenance() {
  const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const expiredSuspendedSales = await prisma.suspendedSale.count({ where: { createdAt: { lt: cutoff } } });
  log('info', 'maintenance.completed', { expiredSuspendedSales, action: 'review_required' });
}

async function bootstrap() {
  await prisma.$connect(); await runMaintenance();
  setInterval(() => void runMaintenance().catch(error => log('error', 'maintenance.failed', { message: error instanceof Error ? error.message : String(error) })), 60 * 60 * 1000);
  log('info', 'worker.started', { intervalMinutes: 60 });
}
void bootstrap().catch(error => { log('error', 'worker.start_failed', { message: error instanceof Error ? error.message : String(error) }); process.exit(1); });
