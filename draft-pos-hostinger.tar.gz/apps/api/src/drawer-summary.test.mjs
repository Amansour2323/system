import assert from 'node:assert/strict';
import { test } from 'node:test';
import { summarizeDrawer } from './drawer-summary.ts';

test('خصم مصروف الكاش من المتوقع وصافي الربح مع احتساب تكلفة المبيعات', () => {
  const result = summarizeDrawer(0, [{
    status: 'COMPLETED', total: 950,
    payments: [{ method: 'CASH', amount: 950 }],
    items: [{ quantity: 1, costAtSale: 500 }],
  }], [], [{ amount: 100, paymentMethod: 'CASH' }]);

  assert.equal(result.expectedAmount, 850);
  assert.equal(result.salesGrossTotal, 950);
  assert.equal(result.costOfGoodsSold, 500);
  assert.equal(result.grossProfit, 450);
  assert.equal(result.expenseTotal, 100);
  assert.equal(result.netProfit, 350);
});

test('مصروف البطاقة يخفض الربح ولا يخصم من نقد الدرج', () => {
  const result = summarizeDrawer(20, [{
    status: 'COMPLETED', total: 950,
    payments: [{ method: 'CASH', amount: 950 }],
    items: [{ quantity: 1, costAtSale: 500 }],
  }], [], [{ amount: 100, paymentMethod: 'CARD' }]);

  assert.equal(result.expectedAmount, 970);
  assert.equal(result.netProfit, 350);
});

test('المرتجع يعكس إيراد وتكلفة البضاعة ويرد من وسيلة الدفع الصحيحة', () => {
  const result = summarizeDrawer(0, [{
    status: 'COMPLETED', total: 950,
    payments: [{ method: 'CASH', amount: 950 }],
    items: [{ quantity: 1, costAtSale: 500 }],
  }], [{
    total: 200, refundAmount: 200, refundMethod: 'CASH',
    items: [{ quantity: 1, saleItem: { costAtSale: 100 } }],
  }], []);

  assert.equal(result.expectedAmount, 750);
  assert.equal(result.netSalesTotal, 750);
  assert.equal(result.costOfGoodsSold, 400);
  assert.equal(result.grossProfit, 350);
});
