import { CashMovementType, PaymentMethod } from '@prisma/client';
import { money } from './financial.js';

export const paymentAccount = (method: PaymentMethod) => ({
  [PaymentMethod.CASH]: '1000',
  [PaymentMethod.CARD]: '1011',
  [PaymentMethod.VODAFONE_CASH]: '1012',
  [PaymentMethod.INSTAPAY]: '1013'
}[method]);

export const drawerPaymentAccount = (method: PaymentMethod) => ({
  [PaymentMethod.CASH]: '1001',
  [PaymentMethod.CARD]: '1111',
  [PaymentMethod.VODAFONE_CASH]: '1112',
  [PaymentMethod.INSTAPAY]: '1113'
}[method]);

export const paymentJournalLines = (
  payments: { method: PaymentMethod; amount: number }[],
  side: 'debit' | 'credit',
  accountFor: (method: PaymentMethod) => string = paymentAccount
) => payments.filter(payment => payment.amount > 0).map(payment => ({ code: accountFor(payment.method), [side]: money(payment.amount) }));

export const cashMovementJournalLines = (movement: { type: CashMovementType; paymentMethod: PaymentMethod; amount: unknown }) => {
  const amount = money(Number(movement.amount));
  const safe = paymentAccount(movement.paymentMethod);
  if (movement.type === CashMovementType.DRAWER_TO_SAFE) return [{ code: safe, debit: amount }, { code: drawerPaymentAccount(movement.paymentMethod), credit: amount }];
  if (movement.type === CashMovementType.SAFE_DEPOSIT) return [{ code: safe, debit: amount }, { code: '2101', credit: amount }];
  return [{ code: '2101', debit: amount }, { code: safe, credit: amount }];
};
