export function getBusinessDate(at = new Date(), timezone = 'Africa/Cairo', rolloverHour = 1): Date {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(at);
  const value = (type: string) => parts.find(part => part.type === type)?.value || '';
  const date = new Date(Date.UTC(Number(value('year')), Number(value('month')) - 1, Number(value('day'))));
  if (Number(value('hour')) < rolloverHour) date.setUTCDate(date.getUTCDate() - 1);
  return date;
}
