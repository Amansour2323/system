describe('قواعد العمليات المالية', () => {
  const money = value => { if (!Number.isFinite(value)) throw new Error('المبلغ غير صالح'); const scaled = Math.abs(value) * 100; return Math.sign(value) * Math.round(scaled + Number.EPSILON * Math.max(1, scaled)) / 100; };
  const balanced = lines => money(lines.reduce((sum, line) => sum + line.debit, 0)) === money(lines.reduce((sum, line) => sum + line.credit, 0));

  test('يحافظ التقريب النقدي على خانتين عشريتين', () => {
    expect(money(19.999)).toBe(20);
    expect(money(19.994)).toBe(19.99);
    expect(money(1.005)).toBe(1.01);
    expect(money(-1.005)).toBe(-1.01);
    expect(() => money(Number.POSITIVE_INFINITY)).toThrow();
  });

  test('يرفض القيد اليومي غير المتوازن', () => {
    expect(balanced([{ debit: 100, credit: 0 }, { debit: 0, credit: 100 }])).toBe(true);
    expect(balanced([{ debit: 100, credit: 0 }, { debit: 0, credit: 99.99 }])).toBe(false);
  });

  test('يحسب الباقي النقدي فقط بعد تغطية إجمالي الفاتورة', () => {
    const total = 250; const tendered = 300;
    expect(Math.max(0, money(tendered - total))).toBe(50);
    expect(Math.max(0, money(200 - total))).toBe(0);
  });
});
