export const money = (value: number) => {
  if (!Number.isFinite(value)) throw new Error('المبلغ غير صالح');
  const scaled = Math.abs(value) * 100;
  return Math.sign(value) * Math.round(scaled + Number.EPSILON * Math.max(1, scaled)) / 100;
};

export const remainingAdvance = (amount: number, spent: number, returned: number) =>
  money(Math.max(0, money(amount - spent - returned)));

export const supplierInvoiceBalance = (total: number, paid: number, returned: number) =>
  money(total - paid - returned);

export const weightedAverageCost = (oldQuantity: number, oldCost: number, receivedQuantity: number, unitCost: number) => {
  const nextQuantity = oldQuantity + receivedQuantity;
  if (nextQuantity <= 0) return money(unitCost);
  const valueInCents = Math.round(oldQuantity) * money(oldCost) + Math.round(receivedQuantity) * money(unitCost);
  return money(valueInCents / nextQuantity);
};

export const safeWalletBalance = (movements: { type: string; amount: unknown }[]) =>
  money(movements.reduce((sum, row) => sum + (row.type === 'SAFE_WITHDRAWAL' ? -Number(row.amount) : Number(row.amount)), 0));
