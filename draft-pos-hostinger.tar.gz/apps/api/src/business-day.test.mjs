import test from 'node:test';
import assert from 'node:assert/strict';
import { getBusinessDate } from './business-day.ts';

const day = at => getBusinessDate(new Date(at)).toISOString().slice(0, 10);

test('business day keeps late-night transactions with the previous day before 01:00 Cairo', () => {
  assert.equal(day('2026-09-30T21:30:00.000Z'), '2026-09-30'); // 00:30 Cairo
  assert.equal(day('2026-09-30T21:59:59.999Z'), '2026-09-30'); // 00:59:59 Cairo
});

test('business day rolls forward at 01:00 Cairo, not before', () => {
  assert.equal(day('2026-09-30T22:00:00.000Z'), '2026-10-01'); // 01:00 Cairo
  assert.equal(day('2026-09-30T09:00:00.000Z'), '2026-09-30'); // noon Cairo
});
