import assert from 'node:assert/strict';
import { test } from 'node:test';
import { money, remainingAdvance, safeWalletBalance, supplierInvoiceBalance, weightedAverageCost } from './financial.ts';

test('rounds currency symmetrically to cents, including binary half-cent values', () => {
  assert.equal(money(1.005), 1.01);
  assert.equal(money(-1.005), -1.01);
  assert.equal(money(19.994), 19.99);
  assert.throws(() => money(Number.POSITIVE_INFINITY));
});

test('computes advance remainder without negative balances or double counting', () => {
  assert.equal(remainingAdvance(1000, 650.25, 100), 249.75);
  assert.equal(remainingAdvance(1000, 800, 250), 0);
});

test('keeps paid supplier returns as a supplier credit instead of hiding the debit balance', () => {
  assert.equal(supplierInvoiceBalance(1000, 1000, 250), -250);
  assert.equal(supplierInvoiceBalance(1000, 250, 250), 500);
});

test('calculates weighted average cost across stock and incoming quantity', () => {
  assert.equal(weightedAverageCost(10, 50, 5, 80), 60);
  assert.equal(weightedAverageCost(0, 0, 3, 12.345), 12.35);
});

test('safe wallet balance nets deposits and withdrawals per wallet', () => {
  assert.equal(safeWalletBalance([
    { type: 'SAFE_DEPOSIT', amount: '1200.00' },
    { type: 'SAFE_WITHDRAWAL', amount: '200.25' },
    { type: 'DRAWER_TO_SAFE', amount: '50.00' },
  ]), 1049.75);
});
