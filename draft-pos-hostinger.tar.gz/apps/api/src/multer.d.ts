declare module 'multer' {
  export const diskStorage: (options: any) => any;
  export const memoryStorage: (options?: any) => any;
}
