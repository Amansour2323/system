import { money } from './financial.js';

type Payment = { method: string; amount: unknown };
type SaleLine = { quantity: number; costAtSale: unknown };
type Sale = { status: string; total: unknown; payments: Payment[]; items: SaleLine[] };
type ReturnedLine = { quantity: number; saleItem: { costAtSale: unknown } };
type SaleReturn = { total: unknown; refundAmount: unknown; refundMethod: string; items: ReturnedLine[] };
type Expense = { amount: unknown; paymentMethod: string };

export function summarizeDrawer(openingAmount: unknown, sales: Sale[], returns: SaleReturn[], expenses: Expense[]) {
  const completedSales = sales.filter(sale => sale.status !== 'CANCELLED');
  const paymentTotals: Record<string, number> = { CASH: 0, CARD: 0, VODAFONE_CASH: 0, INSTAPAY: 0 };
  for (const sale of completedSales) for (const payment of sale.payments) paymentTotals[payment.method] = money((paymentTotals[payment.method] || 0) + Number(payment.amount));

  for (const row of returns) paymentTotals[row.refundMethod] = money((paymentTotals[row.refundMethod] || 0) - Number(row.refundAmount));
  const expenseTotals: Record<string, number> = { CASH: 0, CARD: 0, VODAFONE_CASH: 0, INSTAPAY: 0 };
  for (const expense of expenses) expenseTotals[expense.paymentMethod] = money((expenseTotals[expense.paymentMethod] || 0) + Number(expense.amount));

  const salesGrossTotal = money(completedSales.reduce((sum, sale) => sum + Number(sale.total), 0));
  const refundTotal = money(returns.reduce((sum, row) => sum + Number(row.total), 0));
  const netSalesTotal = money(salesGrossTotal - refundTotal);
  const soldCostTotal = money(completedSales.reduce((sum, sale) => sum + sale.items.reduce((items, item) => items + item.quantity * Number(item.costAtSale), 0), 0));
  const returnedCostTotal = money(returns.reduce((sum, row) => sum + row.items.reduce((items, item) => items + item.quantity * Number(item.saleItem.costAtSale), 0), 0));
  const costOfGoodsSold = money(soldCostTotal - returnedCostTotal);
  const grossProfit = money(netSalesTotal - costOfGoodsSold);
  const expenseTotal = money(expenses.reduce((sum, expense) => sum + Number(expense.amount), 0));
  const cashSalesTotal = money(paymentTotals.CASH || 0);
  const cashExpenseTotal = money(expenseTotals.CASH || 0);

  return {
    paymentTotals,
    expenseTotals,
    cashSalesTotal,
    cashSalesCount: completedSales.length,
    refundCount: returns.length,
    refundTotal,
    salesGrossTotal,
    netSalesTotal,
    soldCostTotal,
    returnedCostTotal,
    costOfGoodsSold,
    grossProfit,
    expenseTotal,
    cashExpenseTotal,
    netProfit: money(grossProfit - expenseTotal),
    expectedAmount: money(Number(openingAmount) + cashSalesTotal - cashExpenseTotal),
  };
}
