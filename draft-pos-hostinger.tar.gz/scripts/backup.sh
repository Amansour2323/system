#!/usr/bin/env sh
set -eu

backup_dir="${BACKUP_DIR:-./backups}"
retention_days="${BACKUP_RETENTION_DAYS:-7}"
case "$backup_dir" in ''|/|.) echo "مسار النسخ الاحتياطي غير آمن" >&2; exit 1;; esac
mkdir -p "$backup_dir"
stamp="$(date -u +%Y%m%d-%H%M%S)"
target="$backup_dir/draft-$stamp.sql.gz"
docker compose exec -T postgres pg_dump -U "${POSTGRES_USER:-draft}" -d "${POSTGRES_DB:-draft}" | gzip -9 > "$target"
test -s "$target"
find "$backup_dir" -type f -name 'draft-*.sql.gz' -mtime "+$retention_days" -delete
printf 'Backup created: %s\n' "$target"
