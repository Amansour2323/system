#!/usr/bin/env sh
set -eu

file="${1:-}"
if [ -z "$file" ] || [ ! -f "$file" ]; then echo "الاستخدام: ./scripts/restore.sh <backup.sql.gz>" >&2; exit 1; fi
if [ "${ALLOW_PRODUCTION_RESTORE:-}" != "1" ]; then echo "للاستعادة، اضبط ALLOW_PRODUCTION_RESTORE=1 بعد اختبار النسخة على قاعدة منفصلة." >&2; exit 1; fi
./scripts/backup.sh
gzip -cd "$file" | docker compose exec -T postgres psql -v ON_ERROR_STOP=1 -U "${POSTGRES_USER:-draft}" -d "${POSTGRES_DB:-draft}"
printf 'Restore completed from: %s\n' "$file"
