param([Parameter(Mandatory=$true)][string]$BackupPath)
Get-Content -Raw $BackupPath | docker compose exec -T postgres psql -U draft -d draft
Write-Host "تمت الاستعادة بنجاح"
