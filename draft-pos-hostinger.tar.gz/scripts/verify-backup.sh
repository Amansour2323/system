#!/usr/bin/env sh
set -eu

file="${1:-}"
if [ -z "$file" ] || [ ! -f "$file" ]; then echo "الاستخدام: ./scripts/verify-backup.sh <backup.sql.gz>" >&2; exit 1; fi
gzip -t "$file"
if ! gzip -cd "$file" | head -n 1 | grep -qE 'PostgreSQL|SET|--'; then echo "ملف النسخة لا يبدو SQL صالحاً" >&2; exit 1; fi
printf 'Backup archive is readable: %s\n' "$file"
