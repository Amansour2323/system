param([string]$OutputPath = "./backups/draft-$(Get-Date -Format yyyyMMdd-HHmmss).sql")
docker compose exec -T postgres pg_dump -U draft -d draft | Out-File -Encoding utf8 $OutputPath
Write-Host "تم إنشاء النسخة الاحتياطية: $OutputPath"
