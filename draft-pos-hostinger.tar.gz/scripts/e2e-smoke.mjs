const base = process.env.E2E_BASE_URL || 'http://localhost:3000';
const email = process.env.E2E_OWNER_EMAIL || 'owner@draft.local';
const password = process.env.E2E_OWNER_PASSWORD || 'ChangeMe123!';
const fail = message => { throw new Error(message); };
const request = async (path, options = {}) => {
  const response = await fetch(`${base}${path}`, options); const text = await response.text(); let body; try { body = text ? JSON.parse(text) : undefined; } catch { body = text; }
  return { response, body };
};
const expect = (condition, message) => { if (!condition) fail(message); };

const health = await request('/health/ready'); expect(health.response.ok && health.body.status === 'ready', 'health readiness failed');
const login = await request('/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password }) }); expect(login.response.ok && login.body.accessToken, 'owner login failed');
const headers = { authorization: `Bearer ${login.body.accessToken}`, 'content-type': 'application/json' };
for (const path of ['/pos/context', '/pos/products', '/inventory/summary', '/inventory/counts', '/inventory/transfers', '/purchases/orders', '/purchases/ledger', '/governance/roles', '/governance/permissions']) { const result = await request(path, { headers }); expect(result.response.ok, `protected route failed: ${path}`); }
const accounts = await request('/accounts', { headers }); expect(accounts.response.ok && Array.isArray(accounts.body), 'account list failed');
for (const code of ['1000', '1001', '1011', '1111', '1112', '1113', '2101', '4100', '6100']) expect(accounts.body.some(account => account.code === code), `missing treasury account ${code}`);
const report = await request('/reports/summary', { headers }); expect(report.response.ok && Number.isFinite(Number(report.body.cogs)), 'business-day report failed');
for (const path of ['/pos/sales', '/pos/exchanges', '/inventory/counts', '/inventory/transfers', '/purchases/orders', '/governance/roles']) { const result = await request(path, { method: 'POST', headers, body: '{}' }); expect(result.response.status === 400, `validation guard failed: ${path}`); }
console.log(JSON.stringify({ status: 'passed', checked: ['auth', 'sales', 'exchange', 'inventory-count', 'transfer', 'purchase-order', 'supplier-ledger', 'governance', 'treasury-accounts', 'business-day-report'], base }));
