export const CURRENCY = 'EGP';
export const PERMISSIONS = ['pos.use','sales.view','sales.create','sales.cancel','sales.return','products.view','products.create','products.update','products.view_cost','inventory.view','inventory.adjust','reports.view','reports.export','drawer.open','drawer.close','settings.manage','users.manage','audit.view'] as const;
