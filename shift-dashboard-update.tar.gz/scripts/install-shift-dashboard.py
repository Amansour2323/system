from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
main = root / 'apps/web/src/main.tsx'
source = main.read_text(encoding='utf-8')
if 'shift-dashboard' in source:
    raise SystemExit('Dashboard appears already installed; no files changed')
start = source.find('function Dashboard()')
end = source.find('\nfunction Products(', start)
app = 'dashboard:<Dashboard/>'
anchor = "import './dialogs.css';"
if start < 0 or end < 0 or source.count(app) != 1 or source.count(anchor) != 1:
    raise SystemExit('Source does not match expected anchors; no files changed')
source = source[:start] + "function Dashboard({user,setPage}:{user:User;setPage:(page:string)=>void}){return <ShiftDashboard user={user} canDrawer={can(user,'drawer.view')} canShipping={can(user,'sales.view')} setPage={setPage}/>}" + source[end:]
source = source.replace(app, 'dashboard:<Dashboard user={user} setPage={setPage}/>', 1)
source = source.replace(anchor, anchor + "\nimport './shift-dashboard.css';\nimport { ShiftDashboard } from './shift-dashboard';", 1)
main.write_text(source, encoding='utf-8')
print('Dashboard integration installed')
