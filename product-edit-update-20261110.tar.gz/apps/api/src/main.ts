import 'reflect-metadata';
import { ArgumentsHost, BadRequestException, Body, CanActivate, Catch, Controller, ExceptionFilter, ExecutionContext, ForbiddenException, Get, HttpException, HttpStatus, Injectable, Logger, Module, NestMiddleware, NestModule, NotFoundException, Param, Patch, Post, Query, Req, Res, UnauthorizedException, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { CashMovementStatus, CashMovementType, ConsignmentSettlementMode, DrawerStatus, InventoryCountStatus, MovementType, PaymentMethod, PrismaClient, ProductOwnership, PurchaseOrderStatus, RoleCode, SaleChannel, SaleStatus, ShippingStatus, TransferStatus } from '@prisma/client';
import * as argon2 from 'argon2';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import type { Request } from 'express';
import { randomUUID } from 'node:crypto';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage, memoryStorage } from 'multer';
import { extname } from 'node:path';
import * as XLSX from 'xlsx';
import { cashMovementJournalLines, drawerPaymentAccount, paymentAccount, paymentJournalLines } from './cash-accounting.js';
import { availableSafeFromDay, money, remainingAdvance, safeWalletBalance, supplierInvoiceBalance, weightedAverageCost } from './financial.js';
import { getBusinessDate, parseBusinessDay } from './business-day.js';
import { summarizeDrawer } from './drawer-summary.js';
import { buildSupplierPerformance } from './supplier-performance.js';

const prisma = new PrismaClient();
const env = (key: string, fallback = ''): string => process.env[key] || fallback;
type TokenClaims = { sub: string; role: RoleCode; email: string };
type AuthRequest = Request & { user?: TokenClaims };
const sign = (user: { id: string; role: RoleCode; email: string }) => jwt.sign({ sub: user.id, role: user.role, email: user.email }, env('JWT_SECRET', 'local-development-secret'), { expiresIn: env('JWT_EXPIRES_IN', '15m') } as jwt.SignOptions);
const parse = <T>(schema: z.ZodType<T>, value: unknown): T => { const r = schema.safeParse(value); if (!r.success) throw new BadRequestException(r.error.flatten()); return r.data; };
const currency = z.coerce.number().finite().transform(money);
const positiveCurrency = currency.pipe(z.number().positive());
const nonnegativeCurrency = currency.pipe(z.number().nonnegative());
const businessDate = (at = new Date()) => getBusinessDate(at, env('BUSINESS_TIMEZONE', 'Africa/Cairo'), Number(env('BUSINESS_DAY_ROLLOVER_HOUR', '1')));
const selectedBusinessDate = (value: string | undefined, user: TokenClaims) => {
  if (!value) return businessDate();
  if (user.role !== RoleCode.OWNER) throw new ForbiddenException('اختيار تاريخ سابق متاح للمالك فقط');
  let day: Date;
  try { day = parseBusinessDay(value); } catch { throw new BadRequestException('تاريخ اليومية غير صحيح'); }
  if (day > businessDate()) throw new BadRequestException('لا يمكن اختيار يومية مستقبلية');
  return day;
};
async function ensureOpenBusinessDate(tx: any, day: Date) {
  const closed = await tx.fiscalPeriod.findFirst({ where: { status: 'CLOSED', startsAt: { lte: day }, endsAt: { gte: day } } });
  if (closed) throw new BadRequestException('لا يمكن ترحيل عملية داخل فترة مالية مغلقة');
}
const loginAttempts = new Map<string, { count: number; resetAt: number }>();
async function postSystemJournal(tx: any, userId: string, description: string, referenceType: string, referenceId: string, lines: { code: string; debit?: number; credit?: number }[], occurredAt = new Date(), selectedDay?: Date) {
  const codes = [...new Set(lines.map(line => line.code))]; const accounts = await tx.account.findMany({ where: { code: { in: codes }, active: true } }); if (accounts.length !== codes.length) throw new BadRequestException('حساب محاسبي تلقائي غير مهيأ أو غير نشط');
  const debit = money(lines.reduce((sum, line) => sum + (line.debit ?? 0), 0)); const credit = money(lines.reduce((sum, line) => sum + (line.credit ?? 0), 0)); if (debit !== credit) throw new BadRequestException('تعذر ترحيل قيد غير متوازن'); if (debit === 0) return;
  const day = selectedDay ?? businessDate(occurredAt); await ensureOpenBusinessDate(tx, day);
  const byCode = new Map(accounts.map((account: any) => [account.code, account.id]));
  await tx.journalEntry.create({ data: { number: `AUTO-${Date.now().toString().slice(-8)}-${Math.floor(Math.random() * 900 + 100)}`, description, referenceType, referenceId, createdById: userId, occurredAt, businessDate: day, lines: { create: lines.map(line => ({ accountId: byCode.get(line.code), debit: line.debit ?? 0, credit: line.credit ?? 0 })) } } });
}

@Injectable()
class JwtGuard implements CanActivate {
  async canActivate(context: ExecutionContext) {
    const req = context.switchToHttp().getRequest<AuthRequest>();
    const raw = req.headers.authorization?.replace(/^Bearer\s+/i, '');
    if (!raw) throw new UnauthorizedException('يلزم تسجيل الدخول');
    try { req.user = jwt.verify(raw, env('JWT_SECRET', 'local-development-secret')) as unknown as TokenClaims; return true; }
    catch { throw new UnauthorizedException('الجلسة غير صالحة أو منتهية'); }
  }
}
const permissionForRequest = (request: Request) => { const path = request.path.replace(/^\/api/, ''); const method = request.method.toUpperCase(); if (path.startsWith('/catalog/products')) return method === 'GET' ? 'products.view' : 'products.create'; if (path.startsWith('/catalog/categories')) return method === 'GET' ? 'products.view' : 'products.create'; if (path.startsWith('/purchases/suppliers') || path.startsWith('/purchases/orders') || path.startsWith('/purchases/advances') || path === '/purchases' || path.startsWith('/purchases/payments') || path.startsWith('/purchases/returns') || path === '/purchases/ledger') return 'suppliers.manage'; if (path.startsWith('/expenses')) return method === 'GET' ? 'expenses.view' : 'expenses.create'; if (path.startsWith('/inventory/counts/approve') || path.startsWith('/inventory/transfers/approve')) return 'inventory.approve'; if (path.startsWith('/inventory')) return method === 'GET' ? 'inventory.view' : 'inventory.adjust'; if (path.startsWith('/reports')) return path.includes('/export') ? 'reports.export' : 'reports.view'; if (path.startsWith('/users')) return 'users.manage'; if (path.startsWith('/governance/audit')) return 'audit.view'; if (path.startsWith('/governance') || path.startsWith('/accounts')) return 'settings.manage'; if (path.startsWith('/pos/cancel')) return 'sales.cancel'; return undefined; };
const allow = (...roles: RoleCode[]) => class RoleGuard extends JwtGuard { async canActivate(ctx: ExecutionContext) { await super.canActivate(ctx); const request = ctx.switchToHttp().getRequest<AuthRequest>(); const user = request.user!; if (roles.includes(user.role)) return true; const permission = permissionForRequest(request); if (!permission) throw new ForbiddenException('لا تملك الصلاحية المطلوبة'); const assignment = await prisma.userRole.findFirst({ where: { userId: user.sub, role: { permissions: { some: { permission: { code: permission } } } } } }); if (!assignment) throw new ForbiddenException('لا تملك الصلاحية المطلوبة'); return true; } };
const permissionCodes = async (user: TokenClaims) => user.role === RoleCode.OWNER
  ? (await prisma.permission.findMany({ select: { code: true } })).map(item => item.code)
  : (await prisma.userRole.findMany({ where: { userId: user.sub }, include: { role: { include: { permissions: { include: { permission: true } } } } } })).flatMap(item => item.role.permissions.map(value => value.permission.code));
const hasPermission = async (user: TokenClaims, permission: string) => user.role === RoleCode.OWNER || (await prisma.userRole.count({ where: { userId: user.sub, role: { permissions: { some: { permission: { code: permission } } } } } })) > 0;
const requirePermission = (...permissions: string[]) => class PermissionGuard extends JwtGuard { async canActivate(ctx: ExecutionContext) { await super.canActivate(ctx); const request = ctx.switchToHttp().getRequest<AuthRequest>(); if (request.user!.role === RoleCode.OWNER) return true; for (const permission of permissions) if (await hasPermission(request.user!, permission)) return true; throw new ForbiddenException('لا تملك الصلاحية المطلوبة'); } };
const publicUser = async (user: { id: string; name: string; email: string; role: RoleCode; active?: boolean }) => ({ id: user.id, name: user.name, email: user.email, role: user.role, active: user.active, permissions: [...new Set(await permissionCodes({ sub: user.id, role: user.role, email: user.email }))] });

@Controller('auth')
class AuthController {
  @Post('login') async login(@Body() body: unknown, @Req() req: Request) {
    const { email, password } = parse(z.object({ email: z.string().email(), password: z.string().min(8) }), body);
    const key = `${req.ip}:${email.toLowerCase()}`; const attempt = loginAttempts.get(key); if (attempt && attempt.resetAt > Date.now() && attempt.count >= 5) throw new HttpException('تم تجاوز عدد محاولات الدخول؛ أعد المحاولة بعد 15 دقيقة', HttpStatus.TOO_MANY_REQUESTS);
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || !user.active || !(await argon2.verify(user.passwordHash, password))) { loginAttempts.set(key, { count: (attempt?.resetAt ?? 0) > Date.now() ? attempt!.count + 1 : 1, resetAt: Date.now() + 15 * 60_000 }); throw new UnauthorizedException('بيانات الدخول غير صحيحة'); }
    loginAttempts.delete(key);
    const rawRefresh = randomUUID() + randomUUID();
    await prisma.refreshToken.create({ data: { userId: user.id, tokenHash: await argon2.hash(rawRefresh), expiresAt: new Date(Date.now() + Number(env('REFRESH_TOKEN_DAYS', '30')) * 864e5) } });
    return { accessToken: sign(user), refreshToken: rawRefresh, user: await publicUser(user) };
  }
  @Post('refresh') async refresh(@Body() body: unknown) {
    const { refreshToken } = parse(z.object({ refreshToken: z.string().min(20) }), body);
    const tokens = await prisma.refreshToken.findMany({ where: { expiresAt: { gt: new Date() }, user: { active: true } }, include: { user: true } });
    const token = (await Promise.all(tokens.map(async x => await argon2.verify(x.tokenHash, refreshToken) ? x : null))).find(Boolean);
    if (!token) throw new UnauthorizedException('جلسة التحديث غير صالحة');
    const nextRefreshToken = randomUUID() + randomUUID();
    const rotated = await prisma.$transaction(async tx => {
      const consumed = await tx.refreshToken.deleteMany({ where: { id: token.id } });
      if (!consumed.count) return false;
      await tx.refreshToken.create({ data: { userId: token.userId, tokenHash: await argon2.hash(nextRefreshToken), expiresAt: new Date(Date.now() + Number(env('REFRESH_TOKEN_DAYS', '30')) * 864e5) } });
      return true;
    });
    if (!rotated) throw new UnauthorizedException('جلسة التحديث غير صالحة');
    return { accessToken: sign(token.user), refreshToken: nextRefreshToken };
  }
  @UseGuards(JwtGuard) @Get('me') async me(@Req() req: AuthRequest) { const user = await prisma.user.findUnique({ where: { id: req.user!.sub }, select: { id: true, name: true, email: true, role: true, active: true } }); if (!user) throw new UnauthorizedException('المستخدم غير موجود'); return publicUser(user); }
}

@Controller('catalog') @UseGuards(JwtGuard)
class CatalogController {
  @Get('categories') @UseGuards(requirePermission('products.view')) async categories() { return prisma.category.findMany({ where: { deletedAt: null }, orderBy: { name: 'asc' } }); }
  @Post('categories') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async addCategory(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ name: z.string().min(2).max(80) }), body); const row = await prisma.category.create({ data }); await audit(req.user!.sub, 'CREATE', 'Category', row.id, data); return row;
  }
  @Get('products') @UseGuards(requirePermission('products.view')) async products(@Req() req: AuthRequest) { const rows = await prisma.product.findMany({ where: { deletedAt: null }, include: { category: true, supplier: true, variants: { include: { balances: true } } }, orderBy: { createdAt: 'desc' } }); if (await hasPermission(req.user!, 'products.view_cost')) return rows; return rows.map(product => ({ ...product, variants: product.variants.map(({ cost: _cost, ...variant }) => variant) })); }
  @Post('products') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async addProduct(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ name: z.string().min(2), sku: z.string().min(2), categoryId: z.string().uuid().optional(), supplierId: z.string().uuid().optional(), ownership: z.nativeEnum(ProductOwnership).default(ProductOwnership.OWNED), settlementMode: z.nativeEnum(ConsignmentSettlementMode).optional(), ownerUnitPrice: nonnegativeCurrency.optional(), storeCommissionPercent: z.coerce.number().min(0).max(100).optional(), storeCommissionPerUnit: nonnegativeCurrency.optional(), variants: z.array(z.object({ name: z.string().min(1), barcode: z.string().min(3), size: z.string().optional(), color: z.string().optional(), price: positiveCurrency, cost: nonnegativeCurrency, openingQty: z.coerce.number().int().nonnegative().default(0), warehouseId: z.string().uuid() })).min(1) }), body);
    if (data.ownership === ProductOwnership.CONSIGNMENT) { if (!data.supplierId || !data.settlementMode) throw new BadRequestException('اختر صاحب البضاعة وطريقة التسوية'); if (data.settlementMode === ConsignmentSettlementMode.OWNER_FIXED_PRICE && data.ownerUnitPrice === undefined) throw new BadRequestException('أدخل سعر التسوية الثابت لصاحب البضاعة'); if (data.settlementMode === ConsignmentSettlementMode.STORE_PERCENT && data.storeCommissionPercent === undefined) throw new BadRequestException('أدخل نسبة المحل'); if (data.settlementMode === ConsignmentSettlementMode.STORE_FIXED && data.storeCommissionPerUnit === undefined) throw new BadRequestException('أدخل عمولة المحل لكل قطعة'); }
    const product = await prisma.$transaction(async tx => {
      if (data.supplierId) { const supplier = await tx.supplier.findFirst({ where: { id: data.supplierId, deletedAt: null, active: true } }); if (!supplier) throw new BadRequestException('المورد المحدد غير موجود أو غير نشط'); }
      const p = await tx.product.create({ data: { name: data.name, sku: data.sku, categoryId: data.categoryId, supplierId: data.supplierId, ownership: data.ownership, settlementMode: data.settlementMode, ownerUnitPrice: data.ownerUnitPrice, storeCommissionPercent: data.storeCommissionPercent, storeCommissionPerUnit: data.storeCommissionPerUnit, variants: { create: data.variants.map(v => ({ name: v.name, barcode: v.barcode, size: v.size, color: v.color, price: v.price, cost: v.cost })) } }, include: { variants: true } });
      for (let i = 0; i < p.variants.length; i++) { const v = data.variants[i]; if (v.openingQty) { await tx.stockBalance.create({ data: { variantId: p.variants[i].id, warehouseId: v.warehouseId, quantity: v.openingQty } }); await tx.stockMovement.create({ data: { variantId: p.variants[i].id, warehouseId: v.warehouseId, quantity: v.openingQty, type: MovementType.OPENING, reference: p.sku, createdById: req.user!.sub } }); } }
      return p;
    }); await audit(req.user!.sub, 'CREATE', 'Product', product.id, { sku: data.sku }); return product;
  }
  @Post('products/:id/supplier') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async setProductSupplier(@Param('id') id: string, @Body() body: unknown, @Req() req: AuthRequest) {
    const { supplierId } = parse(z.object({ supplierId: z.string().uuid().nullable().optional() }), body); const product = await prisma.product.findUnique({ where: { id } }); if (!product || product.deletedAt) throw new NotFoundException('المنتج غير موجود'); if (supplierId) { const supplier = await prisma.supplier.findFirst({ where: { id: supplierId, deletedAt: null, active: true } }); if (!supplier) throw new BadRequestException('المورد المحدد غير موجود أو غير نشط'); }
    const updated = await prisma.product.update({ where: { id }, data: { supplierId: supplierId || null }, include: { supplier: true } }); await audit(req.user!.sub, 'SET_SUPPLIER', 'Product', id, { supplierId: supplierId || null }); return updated;
  }
  @Post('variants/:id/edit') @UseGuards(requirePermission('products.create')) async editVariant(@Param('id') id: string, @Body() body: unknown, @Req() req: AuthRequest) {
    if (!await hasPermission(req.user!, 'products.view_cost') || !await hasPermission(req.user!, 'inventory.adjust')) throw new ForbiddenException('تحتاج صلاحية عرض التكلفة وتسوية المخزون لتعديل الصنف');
    const data = parse(z.object({ name: z.string().trim().min(2).max(200), sku: z.string().trim().min(2).max(100), categoryId: z.string().uuid().nullable(), price: positiveCurrency, cost: nonnegativeCurrency, warehouseId: z.string().uuid(), expectedQuantity: z.number().int().min(0).max(2147483647), quantity: z.number().int().min(0).max(2147483647), reason: z.string().trim().min(3).max(180) }), body);
    return prisma.$transaction(async tx => {
      const variant = await tx.productVariant.findUnique({ where: { id }, include: { product: true, balances: true } });
      if (!variant || variant.product.deletedAt) throw new NotFoundException('المنتج غير موجود');
      if (data.categoryId && !await tx.category.findFirst({ where: { id: data.categoryId, deletedAt: null } })) throw new BadRequestException('القسم غير موجود');
      if (!await tx.warehouse.findUnique({ where: { id: data.warehouseId } })) throw new BadRequestException('المخزن غير موجود');
      if (variant.product.ownership === ProductOwnership.CONSIGNMENT && Number(variant.cost) !== data.cost) throw new BadRequestException('تكلفة الأمانة تتبع اتفاق التسوية');
      const balance = variant.balances.find(row => row.warehouseId === data.warehouseId);
      const current = balance?.quantity ?? 0;
      if (current !== data.expectedQuantity) throw new BadRequestException('تغير الرصيد أثناء التعديل، أغلق النافذة وأعد المحاولة');
      const conflict = await tx.product.findFirst({ where: { sku: data.sku, id: { not: variant.productId } } });
      if (conflict) throw new BadRequestException('كود المنتج مستخدم بالفعل');
      const oldTotal = variant.balances.reduce((sum, row) => sum + row.quantity, 0);
      const delta = data.quantity - current;
      const adjustment = variant.product.ownership === ProductOwnership.CONSIGNMENT ? 0 : money((oldTotal + delta) * data.cost - oldTotal * Number(variant.cost));
      const log = await tx.auditLog.create({ data: { userId: req.user!.sub, action: 'EDIT_PRODUCT_VARIANT', entity: 'ProductVariant', entityId: id, payload: { reason: data.reason, oldName: variant.product.name, newName: data.name, oldSku: variant.product.sku, newSku: data.sku, oldCost: Number(variant.cost), newCost: data.cost, oldPrice: Number(variant.price), newPrice: data.price, warehouseId: data.warehouseId, oldQuantity: current, newQuantity: data.quantity, inventoryAdjustment: adjustment } } });
      if (delta) {
        if (balance) { const changed = await tx.stockBalance.updateMany({ where: { id: balance.id, version: balance.version }, data: { quantity: data.quantity, version: { increment: 1 } } }); if (!changed.count) throw new BadRequestException('تغير الرصيد أثناء التعديل؛ أعد المحاولة'); }
        else await tx.stockBalance.create({ data: { variantId: id, warehouseId: data.warehouseId, quantity: data.quantity } });
        await tx.stockMovement.create({ data: { variantId: id, warehouseId: data.warehouseId, quantity: delta, type: MovementType.ADJUSTMENT, reference: data.reason, createdById: req.user!.sub } });
      }
      if (adjustment) {
        const account = await tx.account.findUnique({ where: { code: '6200' } });
        if (account && (!account.active || account.type !== 'EXPENSE')) throw new BadRequestException('حساب فروق تقييم المخزون غير صالح');
        if (!account) await tx.account.create({ data: { code: '6200', name: 'فروق تقييم المخزون', type: 'EXPENSE' } });
        const amount = Math.abs(adjustment);
        await postSystemJournal(tx, req.user!.sub, `تعديل منتج ${data.name}: ${data.reason}`, 'InventoryCostAdjustment', log.id, adjustment > 0 ? [{ code: '1200', debit: amount }, { code: '6200', credit: amount }] : [{ code: '6200', debit: amount }, { code: '1200', credit: amount }]);
      }
      await tx.product.update({ where: { id: variant.productId }, data: { name: data.name, sku: data.sku, categoryId: data.categoryId } });
      return tx.productVariant.update({ where: { id }, data: { price: data.price, cost: data.cost } });
    }, { isolationLevel: 'Serializable' });
  }
  @Post('variants/:id/prices') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async updateVariantPrices(@Param('id') id: string, @Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ price: positiveCurrency, cost: nonnegativeCurrency, reason: z.string().trim().min(3).max(200) }), body);
    return prisma.$transaction(async tx => {
      const variant = await tx.productVariant.findUnique({ where: { id }, include: { product: true, balances: true } });
      if (!variant || variant.product.deletedAt) throw new NotFoundException('المنتج غير موجود');
      if (variant.product.ownership === ProductOwnership.CONSIGNMENT && Number(variant.cost) !== data.cost) throw new BadRequestException('تكلفة بضاعة الأمانة تحددها شروط التسوية؛ لا يمكن تعديلها من هنا');
      const quantity = variant.balances.reduce((sum, row) => sum + row.quantity, 0);
      const oldCost = Number(variant.cost), oldPrice = Number(variant.price);
      const adjustment = money((data.cost - oldCost) * quantity);
      const log = await tx.auditLog.create({ data: { userId: req.user!.sub, action: 'UPDATE_PRICES', entity: 'ProductVariant', entityId: id, payload: { reason: data.reason, oldCost, newCost: data.cost, oldPrice, newPrice: data.price, quantity, inventoryAdjustment: adjustment } } });
      if (adjustment) {
        const account = await tx.account.findUnique({ where: { code: '6200' } });
        if (account && (!account.active || account.type !== 'EXPENSE')) throw new BadRequestException('حساب فروق تقييم المخزون غير صالح');
        if (!account) await tx.account.create({ data: { code: '6200', name: 'فروق تقييم المخزون', type: 'EXPENSE' } });
        const amount = Math.abs(adjustment);
        await postSystemJournal(tx, req.user!.sub, `تعديل تكلفة ${variant.product.name}: ${data.reason}`, 'InventoryCostAdjustment', log.id, adjustment > 0 ? [{ code: '1200', debit: amount }, { code: '6200', credit: amount }] : [{ code: '6200', debit: amount }, { code: '1200', credit: amount }]);
      }
      return tx.productVariant.update({ where: { id }, data: { price: data.price, cost: data.cost } });
    }, { isolationLevel: 'Serializable' });
  }
}

@Controller('customers') @UseGuards(JwtGuard)
class CustomerController {
  @Get() async list() { return prisma.customer.findMany({ where: { deletedAt: null }, orderBy: { createdAt: 'desc' }, take: 100 }); }
  @Post() async add(@Body() body: unknown) { const data = parse(z.object({ name: z.string().min(2), phone: z.string().min(8).max(20).optional() }), body); return prisma.customer.create({ data }); }
}

@Controller('users') @UseGuards(allow(RoleCode.OWNER))
class UsersController {
  @Get() async list() { return prisma.user.findMany({ select: { id: true, name: true, email: true, role: true, active: true, createdAt: true }, orderBy: { createdAt: 'desc' } }); }
  @Post() async create(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ name: z.string().min(2).max(100), email: z.string().email(), password: z.string().min(10).max(100), role: z.nativeEnum(RoleCode).default(RoleCode.CASHIER) }), body);
    const user = await prisma.user.create({ data: { name: data.name, email: data.email, role: data.role, passwordHash: await argon2.hash(data.password) }, select: { id: true, name: true, email: true, role: true, active: true, createdAt: true } }); const systemRole = await prisma.role.findUnique({ where: { code: data.role } }); if (systemRole) await prisma.userRole.upsert({ where: { userId_roleId: { userId: user.id, roleId: systemRole.id } }, update: {}, create: { userId: user.id, roleId: systemRole.id } });
    await audit(req.user!.sub, 'CREATE', 'User', user.id, { email: user.email, role: user.role }); return user;
  }
  @Post('revoke-sessions') async revoke(@Body() body: unknown, @Req() req: AuthRequest) { const { userId } = parse(z.object({ userId: z.string().uuid() }), body); const result = await prisma.refreshToken.deleteMany({ where: { userId } }); await audit(req.user!.sub, 'REVOKE_SESSIONS', 'User', userId, { count: result.count }); return { revoked: result.count }; }
  @Post(':id/status') async setStatus(@Param('id') id: string, @Body() body: unknown, @Req() req: AuthRequest) { const { active } = parse(z.object({ active: z.boolean() }), body); if (!active && id === req.user!.sub) throw new BadRequestException('لا يمكنك إيقاف حسابك الحالي'); const user = await prisma.user.update({ where: { id }, data: { active }, select: { id: true, name: true, email: true, role: true, active: true } }); if (!active) await prisma.refreshToken.deleteMany({ where: { userId: id } }); await audit(req.user!.sub, active ? 'ACTIVATE' : 'DEACTIVATE', 'User', id); return user; }
  @Post(':id/reset-password') async resetPassword(@Param('id') id: string, @Body() body: unknown, @Req() req: AuthRequest) { const { password } = parse(z.object({ password: z.string().min(10).max(100) }), body); await prisma.user.update({ where: { id }, data: { passwordHash: await argon2.hash(password) } }); const sessions = await prisma.refreshToken.deleteMany({ where: { userId: id } }); await audit(req.user!.sub, 'RESET_PASSWORD', 'User', id, { revokedSessions: sessions.count }); return { ok: true, revokedSessions: sessions.count }; }
}

@Controller('purchases') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT))
class PurchasesController {
  private async availableSafeFromDay(tx: any, method: PaymentMethod, day: Date) {
    const rows = await tx.cashMovement.findMany({ where: { status: CashMovementStatus.APPROVED, paymentMethod: method }, select: { type: true, amount: true, businessDate: true } });
    return availableSafeFromDay(rows, day);
  }
  private async availableSafe(tx: any, method: PaymentMethod) { const rows = await tx.cashMovement.findMany({ where: { status: CashMovementStatus.APPROVED, paymentMethod: method }, select: { type: true, amount: true } }); return safeWalletBalance(rows); }
  private async recordDirectSupplierPayment(tx: any, args: { amount: number; method: PaymentMethod; invoiceNo: string; userId: string; occurredAt: Date; businessDay?: Date }) { await tx.cashMovement.create({ data: { number: `PUR-${Date.now().toString().slice(-8)}-${Math.floor(Math.random() * 900 + 100)}`, type: CashMovementType.SAFE_WITHDRAWAL, status: CashMovementStatus.APPROVED, amount: args.amount, paymentMethod: args.method, reason: `سداد مورد — فاتورة ${args.invoiceNo}`, requestedById: args.userId, approvedById: args.userId, approvedAt: args.occurredAt, businessDate: args.businessDay ?? businessDate(args.occurredAt) } }); }
  private async updateVariantReceiptPrice(tx: any, variantId: string, receivedQuantity: number, unitCost: number, salePrice?: number | null) { const [variant, stock] = await Promise.all([tx.productVariant.findUnique({ where: { id: variantId }, select: { cost: true } }), tx.stockBalance.aggregate({ where: { variantId }, _sum: { quantity: true } })]); if (!variant) throw new NotFoundException('الصنف غير موجود'); const oldQuantity = Number(stock._sum.quantity || 0); const weightedCost = weightedAverageCost(oldQuantity, Number(variant.cost), receivedQuantity, unitCost); await tx.productVariant.update({ where: { id: variantId }, data: { cost: weightedCost, ...(salePrice === undefined || salePrice === null ? {} : { price: salePrice }) } }); }
  @Get('suppliers') async suppliers() { return prisma.supplier.findMany({ where: { deletedAt: null, active: true }, orderBy: { name: 'asc' } }); }
  @Get('suppliers/:id/statement') async supplierStatement(@Param('id') id: string) {
    const supplier = await prisma.supplier.findFirst({
      where: { id, deletedAt: null },
      include: {
        purchases: { include: { warehouse: true, items: { include: { variant: { include: { product: true } } } } } },
        payments: { include: { purchase: true, purchaseAdvance: true } },
        returns: { include: { items: { include: { variant: { include: { product: true } } } } } },
        paymentSchedules: { where: { active: true }, orderBy: { startDate: 'asc' } },
      },
    });
    if (!supplier) throw new NotFoundException('المورد غير موجود');
    const invoiced = money(supplier.purchases.reduce((sum, row) => sum + Number(row.total), 0));
    const paid = money(supplier.payments.reduce((sum, row) => sum + Number(row.amount), 0));
    const returned = money(supplier.returns.reduce((sum, row) => sum + row.items.reduce((subtotal, item) => subtotal + Number(item.quantity) * Number(item.unitCost), 0), 0));
    const returnedByPurchase = new Map<string, number>();
    for (const row of supplier.returns) if (row.purchaseId) returnedByPurchase.set(row.purchaseId, money((returnedByPurchase.get(row.purchaseId) || 0) + row.items.reduce((subtotal, item) => subtotal + Number(item.quantity) * Number(item.unitCost), 0)));
    const transactions = [
      ...supplier.purchases.map(row => ({ id: row.id, type: 'INVOICE', date: row.createdAt, businessDate: row.businessDate, number: row.invoiceNo, description: `فاتورة شراء · ${row.warehouse.name}`, amount: Number(row.total), purchaseId: row.id })),
      ...supplier.payments.map(row => ({ id: row.id, type: 'PAYMENT', date: row.createdAt, businessDate: row.businessDate, number: row.number, description: row.reference || (row.purchase ? `سداد فاتورة ${row.purchase.invoiceNo}` : row.purchaseAdvance?.number ? `سداد من عهدة ${row.purchaseAdvance.number}` : 'دفعة للمورد'), amount: Number(row.amount), method: row.method, purchaseId: row.purchaseId })),
      ...supplier.returns.map(row => ({ id: row.id, type: 'RETURN', date: row.createdAt, number: row.number, description: `مرتجع مورد${row.purchaseId ? ` · فاتورة ${supplier.purchases.find(purchase => purchase.id === row.purchaseId)?.invoiceNo || ''}` : ''} · ${row.reason}`, amount: money(row.items.reduce((sum, item) => sum + Number(item.quantity) * Number(item.unitCost), 0)), purchaseId: row.purchaseId })),
    ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    const now = new Date();
    const schedules = supplier.paymentSchedules.map(row => {
      const start = new Date(row.startDate); const next = new Date(start); let step = 0;
      const frequency = row.frequency as 'WEEKLY' | 'BIWEEKLY' | 'MONTHLY';
      if (frequency === 'MONTHLY') {
        const months = Math.max(0, (now.getUTCFullYear() - start.getUTCFullYear()) * 12 + now.getUTCMonth() - start.getUTCMonth());
        const makeMonth = (offset: number) => { const target = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + offset, 1)); target.setUTCDate(Math.min(start.getUTCDate(), new Date(Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0)).getUTCDate())); return target; };
        step = months; next.setTime(makeMonth(step).getTime()); if (next < now) { step++; next.setTime(makeMonth(step).getTime()); }
      } else {
        const days = frequency === 'BIWEEKLY' ? 15 : 7; step = Math.max(0, Math.floor((now.getTime() - start.getTime()) / (days * 86400000))); next.setTime(start.getTime() + step * days * 86400000); if (next < now) { step++; next.setTime(start.getTime() + step * days * 86400000); }
      }
      return { ...row, nextDueDate: row.endDate && next > new Date(row.endDate) ? null : next };
    });
    const purchases = supplier.purchases.map(row => { const purchaseReturned = returnedByPurchase.get(row.id) || 0; return { ...row, returned: purchaseReturned, outstanding: supplierInvoiceBalance(Number(row.total), Number(row.paid), purchaseReturned) }; });
    return { supplier: { id: supplier.id, name: supplier.name, phone: supplier.phone, email: supplier.email, notes: supplier.notes }, summary: { invoiced, returned, paid, outstanding: money(invoiced - returned - paid), invoiceCount: supplier.purchases.length, paymentCount: supplier.payments.length }, purchases, transactions, schedules };
  }
  @Post('suppliers/:id/schedules') async createSupplierSchedule(@Param('id') id: string, @Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ amount: positiveCurrency.pipe(z.number().max(1_000_000)), frequency: z.enum(['WEEKLY', 'BIWEEKLY', 'MONTHLY']), startDate: z.coerce.date(), endDate: z.coerce.date().optional(), note: z.string().max(180).optional() }), body);
    if (data.endDate && data.endDate < data.startDate) throw new BadRequestException('تاريخ نهاية الجدولة يجب أن يكون بعد تاريخ البداية');
    const supplier = await prisma.supplier.findFirst({ where: { id, deletedAt: null, active: true } }); if (!supplier) throw new NotFoundException('المورد غير موجود أو غير نشط');
    const schedule = await prisma.supplierPaymentSchedule.create({ data: { supplierId: id, amount: data.amount, frequency: data.frequency, startDate: data.startDate, endDate: data.endDate, note: data.note, createdById: req.user!.sub } });
    await audit(req.user!.sub, 'CREATE_SCHEDULE', 'SupplierPaymentSchedule', schedule.id, { supplierId: id, amount: data.amount, frequency: data.frequency }); return schedule;
  }
  @Patch('suppliers/:id/schedules/:scheduleId') async updateSupplierSchedule(@Param('id') id: string, @Param('scheduleId') scheduleId: string, @Body() body: unknown, @Req() req: AuthRequest) {
    const { active } = parse(z.object({ active: z.boolean() }), body);
    const result = await prisma.supplierPaymentSchedule.updateMany({ where: { id: scheduleId, supplierId: id, active: !active }, data: { active } });
    if (!result.count) throw new NotFoundException('الجدولة غير موجودة أو حالتها تغيرت');
    await audit(req.user!.sub, active ? 'RESUME_SCHEDULE' : 'PAUSE_SCHEDULE', 'SupplierPaymentSchedule', scheduleId, { supplierId: id }); return { id: scheduleId, active };
  }
  @Post('suppliers') async addSupplier(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ name: z.string().min(2).max(120), phone: z.string().min(7).max(20).optional(), email: z.string().email().optional(), notes: z.string().max(500).optional() }), body);
    const supplier = await prisma.supplier.create({ data }); await audit(req.user!.sub, 'CREATE', 'Supplier', supplier.id, { name: supplier.name }); return supplier;
  }
  @Get('warehouses') async warehouses() { return prisma.warehouse.findMany({ where: { branch: { isActive: true } }, include: { branch: true }, orderBy: { name: 'asc' } }); }
  @Get() async purchases() { const rows=await prisma.purchase.findMany({ include: { supplier: true, warehouse: true, payments: { include: { purchaseAdvance: true } }, items: { include: { variant: { include: { product: true } } } } }, orderBy: { createdAt: 'desc' }, take: 100 }); const returns=rows.length?await prisma.supplierReturn.findMany({where:{purchaseId:{in:rows.map(row=>row.id)}},include:{items:true}}):[]; const returnedByPurchase=new Map<string,number>(); for(const row of returns)if(row.purchaseId)returnedByPurchase.set(row.purchaseId,money((returnedByPurchase.get(row.purchaseId)||0)+row.items.reduce((sum,item)=>sum+Number(item.quantity)*Number(item.unitCost),0))); return rows.map(row=>({...row,returned:returnedByPurchase.get(row.id)||0,outstanding:supplierInvoiceBalance(Number(row.total),Number(row.paid),returnedByPurchase.get(row.id)||0)})); }
  @Get('advances') async advances() { return prisma.purchaseAdvance.findMany({ include: { payments: { include: { supplier: true, purchase: true } }, cashMovements: true }, orderBy: { createdAt: 'desc' }, take: 100 }); }
  @Post('advances') async createAdvance(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ businessDay: z.string().optional(), recipient: z.string().min(2).max(120), purpose: z.string().min(3).max(240), amount: positiveCurrency.pipe(z.number().max(1_000_000)), paymentMethod: z.nativeEnum(PaymentMethod) }), body); const occurredAt = new Date(); const day = selectedBusinessDate(data.businessDay, req.user!);
    const result = await prisma.$transaction(async tx => { await ensureOpenBusinessDate(tx, day); const available = await this.availableSafeFromDay(tx, data.paymentMethod, day); if (data.amount > available) throw new BadRequestException(`رصيد ${data.paymentMethod} في الخزنة غير كافٍ؛ المتاح ${money(available)}`); const movement = await tx.cashMovement.create({ data: { number: `ADV-${Date.now().toString().slice(-8)}-${Math.floor(Math.random()*900+100)}`, type: CashMovementType.SAFE_WITHDRAWAL, status: CashMovementStatus.APPROVED, amount: data.amount, paymentMethod: data.paymentMethod, reason: `عهدة مشتريات — ${data.recipient} — ${data.purpose}`, requestedById: req.user!.sub, approvedById: req.user!.sub, approvedAt: occurredAt, businessDate: day } }); const advance = await tx.purchaseAdvance.create({ data: { number: movement.number, recipient: data.recipient, purpose: data.purpose, amount: data.amount, paymentMethod: data.paymentMethod, createdById: req.user!.sub, businessDate: day, cashMovements: { connect: { id: movement.id } } }, include: { cashMovements: true } }); await tx.cashMovement.update({ where: { id: movement.id }, data: { purchaseAdvanceId: advance.id } }); await postSystemJournal(tx, req.user!.sub, `صرف عهدة مشتريات ${advance.number}`, 'PurchaseAdvance', advance.id, [{ code: '1210', debit: data.amount }, { code: paymentAccount(data.paymentMethod), credit: data.amount }], occurredAt, day); return advance; }, { isolationLevel: 'Serializable' }); await audit(req.user!.sub, 'CREATE', 'PurchaseAdvance', result.id, { number: result.number, recipient: data.recipient, amount: data.amount, paymentMethod: data.paymentMethod }); return result;
  }
  @Post('advances/:id/return') async returnAdvance(@Param('id') id: string, @Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ amount: positiveCurrency.pipe(z.number().max(1_000_000)), reason: z.string().min(3).max(200).default('إرجاع باقي عهدة المشتريات') }), body); const occurredAt = new Date();
    const result = await prisma.$transaction(async tx => { const advance = await tx.purchaseAdvance.findUnique({ where: { id } }); if (!advance || advance.status !== 'OPEN') throw new NotFoundException('عهدة المشتريات غير مفتوحة'); const remaining = remainingAdvance(Number(advance.amount), Number(advance.spent), Number(advance.returned)); if (data.amount > remaining) throw new BadRequestException(`المبلغ أكبر من باقي العهدة ${remaining}`); const returned = money(Number(advance.returned) + data.amount); const status = money(Number(advance.spent) + returned) >= Number(advance.amount) ? 'SETTLED' : 'OPEN'; const movement = await tx.cashMovement.create({ data: { number: `RET-${Date.now().toString().slice(-8)}-${Math.floor(Math.random()*900+100)}`, type: CashMovementType.SAFE_DEPOSIT, status: CashMovementStatus.APPROVED, amount: data.amount, paymentMethod: advance.paymentMethod, reason: `${data.reason} — ${advance.number}`, purchaseAdvanceId: advance.id, requestedById: req.user!.sub, approvedById: req.user!.sub, approvedAt: occurredAt, businessDate: businessDate(occurredAt) } }); const updated = await tx.purchaseAdvance.update({ where: { id }, data: { returned, status } }); await postSystemJournal(tx, req.user!.sub, `إرجاع باقي عهدة ${advance.number}`, 'PurchaseAdvanceReturn', movement.id, [{ code: paymentAccount(advance.paymentMethod), debit: data.amount }, { code: '1210', credit: data.amount }], occurredAt); return { advance: updated, movement, remaining: remainingAdvance(Number(advance.amount), Number(advance.spent), returned) }; }, { isolationLevel: 'Serializable' }); await audit(req.user!.sub, 'RETURN_REMAINDER', 'PurchaseAdvance', id, { amount: data.amount, remaining: result.remaining, movementId: result.movement.id }); return result;
  }
  @Post() async receive(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ businessDay: z.string().optional(), supplierId: z.string().uuid(), warehouseId: z.string().uuid(), invoiceNo: z.string().min(2).max(80), paymentTerms: z.enum(['CASH','CREDIT']).default('CREDIT'), paid: nonnegativeCurrency.default(0), paymentMethod: z.nativeEnum(PaymentMethod).default(PaymentMethod.CASH), advanceId: z.string().uuid().optional(), items: z.array(z.object({ variantId: z.string().uuid(), quantity: z.coerce.number().int().positive(), unitCost: nonnegativeCurrency, salePrice: nonnegativeCurrency.optional() })).min(1) }), body);
    if (new Set(data.items.map(item => item.variantId)).size !== data.items.length) throw new BadRequestException('لا يمكن تكرار نفس الصنف في فاتورة الشراء');
    const day = selectedBusinessDate(data.businessDay, req.user!);
    const purchase = await prisma.$transaction(async tx => {
      await ensureOpenBusinessDate(tx, day);
      const variants = await tx.productVariant.findMany({ where: { id: { in: data.items.map(item => item.variantId) } } });
      if (variants.length !== data.items.length) throw new NotFoundException('أحد أصناف فاتورة الشراء غير موجود');
      const items = data.items.map(item => ({ ...item, total: money(item.quantity * item.unitCost) })); const total = money(items.reduce((sum, item) => sum + item.total, 0));
      const paid = data.paid ?? 0; if (paid > total) throw new BadRequestException('المبلغ المدفوع لا يمكن أن يتجاوز إجمالي الفاتورة'); if (data.paymentTerms === 'CASH' && paid < total) throw new BadRequestException('فاتورة الكاش يجب سداد إجماليها بالكامل');
      const method=data.paymentMethod??PaymentMethod.CASH; const advance = data.advanceId ? await tx.purchaseAdvance.findUnique({ where: { id: data.advanceId } }) : null; if (paid && data.advanceId && (!advance || advance.status !== 'OPEN' || advance.paymentMethod !== method || remainingAdvance(Number(advance.amount),Number(advance.spent),Number(advance.returned)) < paid)) throw new BadRequestException('عهدة المشتريات غير صالحة أو رصيدها لا يكفي'); if (paid && advance && advance.businessDate > day) throw new BadRequestException('تاريخ الفاتورة يسبق تاريخ صرف العهدة'); if (paid && !data.advanceId && await this.availableSafeFromDay(tx, method, day) < paid) throw new BadRequestException('رصيد الخزنة لا يكفي لهذه الدفعة');
      const record = await tx.purchase.create({ data: { supplierId: data.supplierId, warehouseId: data.warehouseId, invoiceNo: data.invoiceNo, paymentTerms: data.paymentTerms, total, paid, createdById: req.user!.sub, businessDate: day, items: { create: items } }, include: { items: true } });
      if (paid) { const payment = await tx.supplierPayment.create({ data: { number: `SP-${Date.now().toString().slice(-8)}-${Math.floor(Math.random() * 900 + 100)}`, supplierId: data.supplierId, purchaseId: record.id, purchaseAdvanceId: data.advanceId, amount: paid, method, reference: `فاتورة ${data.invoiceNo}`, createdById: req.user!.sub, businessDate: day } }); if (advance) { const spent = money(Number(advance.spent)+paid); await tx.purchaseAdvance.update({ where: { id: advance.id }, data: { spent, status: money(spent+Number(advance.returned))>=Number(advance.amount)?'SETTLED':'OPEN' } }); await postSystemJournal(tx, req.user!.sub, `تسوية من عهدة مشتريات ${advance.number}`, 'SupplierPayment', payment.id, [{ code: '2000', debit: paid }, { code: '1210', credit: paid }], new Date(), day); } else { const occurredAt = new Date(); await this.recordDirectSupplierPayment(tx, { amount: paid, method, invoiceNo: data.invoiceNo, userId: req.user!.sub, occurredAt, businessDay: day }); await postSystemJournal(tx, req.user!.sub, `دفعة شراء ${data.invoiceNo}`, 'SupplierPayment', payment.id, [{ code: '2000', debit: paid }, { code: paymentAccount(method), credit: paid }], occurredAt, day); } }
      for (const item of items) {
        await this.updateVariantReceiptPrice(tx, item.variantId, item.quantity, item.unitCost, item.salePrice);
        await tx.stockBalance.upsert({ where: { variantId_warehouseId: { variantId: item.variantId, warehouseId: data.warehouseId } }, update: { quantity: { increment: item.quantity }, version: { increment: 1 } }, create: { variantId: item.variantId, warehouseId: data.warehouseId, quantity: item.quantity } });
        await tx.stockMovement.create({ data: { variantId: item.variantId, warehouseId: data.warehouseId, quantity: item.quantity, type: MovementType.PURCHASE, reference: data.invoiceNo, createdById: req.user!.sub } });
      }
      await postSystemJournal(tx, req.user!.sub, `شراء ${data.invoiceNo}`, 'Purchase', record.id, [{ code: '1200', debit: total }, { code: '2000', credit: total }], new Date(), day);
      return record;
    }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, 'RECEIVE', 'Purchase', purchase.id, { invoiceNo: data.invoiceNo, paid: data.paid ?? 0 }); return purchase;
  }
  @Post('payments') async pay(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ purchaseId: z.string().uuid(), amount: positiveCurrency.pipe(z.number().max(1_000_000)), method: z.nativeEnum(PaymentMethod).default(PaymentMethod.CASH), advanceId: z.string().uuid().optional(), reference: z.string().min(3).max(180), businessDay: z.string().optional() }), body);
    const day = selectedBusinessDate(data.businessDay, req.user!);
    const purchase = await prisma.$transaction(async tx => {
      const method=data.method??PaymentMethod.CASH;
      const row = await tx.purchase.findUnique({ where: { id: data.purchaseId } });
      if (!row || row.status !== 'RECEIVED') throw new NotFoundException('فاتورة الشراء غير متاحة للدفع');
      await ensureOpenBusinessDate(tx, day);
      if (row.businessDate > day) throw new BadRequestException('تاريخ الدفعة يسبق تاريخ فاتورة الشراء');
      const returnRows=await tx.supplierReturn.findMany({where:{purchaseId:row.id},include:{items:true}}); const returnedTotal=money(returnRows.reduce((sum,returnRow)=>sum+returnRow.items.reduce((items,item)=>items+Number(item.quantity)*Number(item.unitCost),0),0)); if (Number(row.paid) + data.amount + returnedTotal > Number(row.total)) throw new BadRequestException('الدفعة تتجاوز الرصيد المتبقي للمورد بعد المرتجعات');
      const advance = data.advanceId ? await tx.purchaseAdvance.findUnique({ where: { id: data.advanceId } }) : null; if (data.advanceId && (!advance || advance.status !== 'OPEN' || advance.paymentMethod !== method || remainingAdvance(Number(advance.amount),Number(advance.spent),Number(advance.returned)) < data.amount)) throw new BadRequestException('عهدة المشتريات غير صالحة أو رصيدها لا يكفي'); if (advance && advance.businessDate > day) throw new BadRequestException('تاريخ الدفعة يسبق تاريخ صرف العهدة'); if (!data.advanceId && await this.availableSafeFromDay(tx, method, day) < data.amount) throw new BadRequestException('رصيد الخزنة لا يكفي لهذه الدفعة في هذا التاريخ أو بعده');
      const updated = await tx.purchase.update({ where: { id: row.id }, data: { paid: { increment: data.amount } }, include: { supplier: true } });
      const occurredAt = new Date(); const payment = await tx.supplierPayment.create({ data: { number: `SP-${Date.now().toString().slice(-8)}-${Math.floor(Math.random() * 900 + 100)}`, supplierId: row.supplierId, purchaseId: row.id, purchaseAdvanceId: data.advanceId, amount: data.amount, method, reference: data.reference, createdById: req.user!.sub, businessDate: day } }); if (advance) { const spent = money(Number(advance.spent)+data.amount); await tx.purchaseAdvance.update({ where: { id: advance.id }, data: { spent, status: money(spent+Number(advance.returned))>=Number(advance.amount)?'SETTLED':'OPEN' } }); await postSystemJournal(tx, req.user!.sub, `سداد فاتورة ${updated.invoiceNo} من عهدة ${advance.number}`, 'SupplierPayment', payment.id, [{ code: '2000', debit: data.amount }, { code: '1210', credit: data.amount }], occurredAt, day); } else { await this.recordDirectSupplierPayment(tx, { amount: data.amount, method, invoiceNo: row.invoiceNo, userId: req.user!.sub, occurredAt, businessDay: day }); await postSystemJournal(tx, req.user!.sub, `دفعة مورد ${updated.invoiceNo}`, 'SupplierPayment', payment.id, [{ code: '2000', debit: data.amount }, { code: paymentAccount(payment.method), credit: data.amount }], occurredAt, day); } return updated;
    }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, 'PAY', 'Purchase', purchase.id, { amount: data.amount, reference: data.reference, businessDay: day.toISOString().slice(0,10) }); return purchase;
  }
  @Get('orders') async orders() { return prisma.purchaseOrder.findMany({ include: { supplier: true, items: { include: { variant: { include: { product: true } } } } }, orderBy: { createdAt: 'desc' }, take: 100 }); }
  @Post('orders') async createOrder(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ supplierId: z.string().uuid(), warehouseId: z.string().uuid(), expectedAt: z.coerce.date().optional(), notes: z.string().max(300).optional(), items: z.array(z.object({ variantId: z.string().uuid(), quantity: z.coerce.number().int().positive(), unitCost: nonnegativeCurrency, salePrice: nonnegativeCurrency.optional() })).min(1) }), body);
    if (new Set(data.items.map(item => item.variantId)).size !== data.items.length) throw new BadRequestException('لا تكرر الصنف في أمر الشراء');
    const order = await prisma.purchaseOrder.create({ data: { number: `PO-${Date.now().toString().slice(-8)}`, supplierId: data.supplierId, warehouseId: data.warehouseId, expectedAt: data.expectedAt, notes: data.notes, createdById: req.user!.sub, items: { create: data.items.map(item => ({ variantId: item.variantId, orderedQuantity: item.quantity, unitCost: item.unitCost, salePrice: item.salePrice })) } }, include: { items: true } }); await audit(req.user!.sub, 'CREATE', 'PurchaseOrder', order.id); return order;
  }
  @Post('orders/approve') async approveOrder(@Body() body: unknown, @Req() req: AuthRequest) { const { orderId } = parse(z.object({ orderId: z.string().uuid() }), body); const row = await prisma.purchaseOrder.findUnique({ where: { id: orderId } }); if (!row || row.status !== PurchaseOrderStatus.DRAFT) throw new BadRequestException('أمر الشراء غير متاح للاعتماد'); const order = await prisma.purchaseOrder.update({ where: { id: orderId }, data: { status: PurchaseOrderStatus.APPROVED, approvedById: req.user!.sub } }); await audit(req.user!.sub, 'APPROVE', 'PurchaseOrder', orderId); return order; }
  @Post('orders/receipts') async receiveOrder(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ businessDay: z.string().optional(), orderId: z.string().uuid(), invoiceNo: z.string().min(2).max(80), paymentTerms: z.enum(['CASH','CREDIT']).default('CREDIT'), paid: nonnegativeCurrency.default(0), paymentMethod: z.nativeEnum(PaymentMethod).default(PaymentMethod.CASH), advanceId: z.string().uuid().optional(), items: z.array(z.object({ variantId: z.string().uuid(), acceptedQuantity: z.coerce.number().int().nonnegative(), damagedQuantity: z.coerce.number().int().nonnegative().default(0) })).min(1) }), body);
    const paid = data.paid ?? 0; const day = selectedBusinessDate(data.businessDay, req.user!);
    const result = await prisma.$transaction(async tx => {
      await ensureOpenBusinessDate(tx, day); const order = await tx.purchaseOrder.findUnique({ where: { id: data.orderId }, include: { items: true } }); if (!order || (order.status !== PurchaseOrderStatus.APPROVED && order.status !== PurchaseOrderStatus.PARTIALLY_RECEIVED)) throw new BadRequestException('أمر الشراء غير متاح للاستلام');
      const receiptItems = data.items.map(item => ({ ...item, damagedQuantity: item.damagedQuantity ?? 0 })).filter(item => item.acceptedQuantity > 0 || item.damagedQuantity > 0).map(item => { const ordered = order.items.find(line => line.variantId === item.variantId); if (!ordered) throw new BadRequestException('الصنف لا ينتمي إلى أمر الشراء'); if (ordered.receivedQuantity + item.acceptedQuantity + item.damagedQuantity > ordered.orderedQuantity) throw new BadRequestException('كمية الاستلام والتالف تتجاوز الكمية المطلوبة'); return { ...item, orderItem: ordered, total: money(item.acceptedQuantity * Number(ordered.unitCost)) }; });
      if (!receiptItems.length) throw new BadRequestException('أدخل كمية مستلمة أو تالفة واحدة على الأقل'); const total = money(receiptItems.reduce((sum, item) => sum + item.total, 0)); if (paid > total) throw new BadRequestException('المدفوع أكبر من قيمة الكمية المقبولة'); if (data.paymentTerms === 'CASH' && paid < total) throw new BadRequestException('فاتورة الكاش يجب سداد قيمة الكمية المقبولة بالكامل'); const method=data.paymentMethod??PaymentMethod.CASH; const advance = data.advanceId ? await tx.purchaseAdvance.findUnique({ where: { id: data.advanceId } }) : null; if (paid && data.advanceId && (!advance || advance.status !== 'OPEN' || advance.paymentMethod !== method || remainingAdvance(Number(advance.amount),Number(advance.spent),Number(advance.returned)) < paid)) throw new BadRequestException('عهدة المشتريات غير صالحة أو رصيدها لا يكفي'); if (paid && advance && advance.businessDate > day) throw new BadRequestException('تاريخ الاستلام يسبق تاريخ صرف العهدة'); if (paid && !data.advanceId && await this.availableSafeFromDay(tx, method, day) < paid) throw new BadRequestException('رصيد الخزنة لا يكفي لهذه الدفعة');
      const purchase = await tx.purchase.create({ data: { supplierId: order.supplierId, warehouseId: order.warehouseId, invoiceNo: data.invoiceNo, paymentTerms: data.paymentTerms, total, paid, createdById: req.user!.sub, businessDate: day, items: { create: receiptItems.filter(item => item.acceptedQuantity > 0).map(item => ({ variantId: item.variantId, quantity: item.acceptedQuantity, unitCost: item.orderItem.unitCost, salePrice: item.orderItem.salePrice, total: item.total })) } }, include: { items: true } });
      if (paid) { const payment = await tx.supplierPayment.create({ data: { number: `SP-${Date.now().toString().slice(-8)}-${Math.floor(Math.random() * 900 + 100)}`, supplierId: order.supplierId, purchaseId: purchase.id, purchaseAdvanceId: data.advanceId, amount: paid, method, reference: `استلام ${data.invoiceNo}`, createdById: req.user!.sub, businessDate: day } }); if (advance) { const spent = money(Number(advance.spent)+paid); await tx.purchaseAdvance.update({ where: { id: advance.id }, data: { spent, status: money(spent+Number(advance.returned))>=Number(advance.amount)?'SETTLED':'OPEN' } }); await postSystemJournal(tx, req.user!.sub, `دفعة استلام من عهدة ${advance.number}`, 'SupplierPayment', payment.id, [{ code: '2000', debit: paid }, { code: '1210', credit: paid }], new Date(), day); } else { const occurredAt = new Date(); await this.recordDirectSupplierPayment(tx, { amount: paid, method, invoiceNo: data.invoiceNo, userId: req.user!.sub, occurredAt, businessDay: day }); await postSystemJournal(tx, req.user!.sub, `دفعة استلام ${data.invoiceNo}`, 'SupplierPayment', payment.id, [{ code: '2000', debit: paid }, { code: paymentAccount(method), credit: paid }], occurredAt, day); } }
      for (const item of receiptItems) { await tx.purchaseOrderItem.update({ where: { purchaseOrderId_variantId: { purchaseOrderId: order.id, variantId: item.variantId } }, data: { receivedQuantity: { increment: item.acceptedQuantity + item.damagedQuantity } } }); if (item.acceptedQuantity) { await this.updateVariantReceiptPrice(tx, item.variantId, item.acceptedQuantity, Number(item.orderItem.unitCost), item.orderItem.salePrice===null?undefined:Number(item.orderItem.salePrice)); await tx.stockBalance.upsert({ where: { variantId_warehouseId: { variantId: item.variantId, warehouseId: order.warehouseId } }, update: { quantity: { increment: item.acceptedQuantity }, version: { increment: 1 } }, create: { variantId: item.variantId, warehouseId: order.warehouseId, quantity: item.acceptedQuantity } }); await tx.stockMovement.create({ data: { variantId: item.variantId, warehouseId: order.warehouseId, quantity: item.acceptedQuantity, type: MovementType.PURCHASE, reference: `PO:${order.number}/${data.invoiceNo}`, createdById: req.user!.sub } }); } }
      const refreshedItems = await tx.purchaseOrderItem.findMany({ where: { purchaseOrderId: order.id } }); const complete = refreshedItems.every(item => item.receivedQuantity >= item.orderedQuantity); await tx.purchaseOrder.update({ where: { id: order.id }, data: { status: complete ? PurchaseOrderStatus.RECEIVED : PurchaseOrderStatus.PARTIALLY_RECEIVED } });
      await postSystemJournal(tx, req.user!.sub, `استلام أمر ${order.number}`, 'Purchase', purchase.id, [{ code: '1200', debit: total }, { code: '2000', credit: total }], new Date(), day); return { purchase, orderNumber: order.number, damagedQuantity: receiptItems.reduce((sum, item) => sum + item.damagedQuantity, 0) };
    }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, 'RECEIVE_PARTIAL', 'PurchaseOrder', data.orderId, { invoiceNo: data.invoiceNo, damagedQuantity: result.damagedQuantity }); return result;
  }
  @Get('ledger') async ledger() {
    const suppliers = await prisma.supplier.findMany({ where: { deletedAt: null }, include: { purchases: true, payments: true, returns: { include: { items: true } } }, orderBy: { name: 'asc' } });
    return suppliers.map(supplier => {
      const invoiced = money(supplier.purchases.reduce((sum, purchase) => sum + Number(purchase.total), 0));
      const paid = money(supplier.payments.reduce((sum, payment) => sum + Number(payment.amount), 0));
      const returned = money(supplier.returns.reduce((sum, row) => sum + row.items.reduce((items, item) => items + item.quantity * Number(item.unitCost), 0), 0));
      return { id: supplier.id, name: supplier.name, invoiced, returned, paid, outstanding: money(invoiced - returned - paid) };
    });
  }
  @Post('returns') async supplierReturn(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ supplierId: z.string().uuid(), purchaseId: z.string().uuid().optional(), warehouseId: z.string().uuid(), reason: z.string().min(3).max(180), items: z.array(z.object({ variantId: z.string().uuid(), quantity: z.coerce.number().int().positive(), unitCost: nonnegativeCurrency })).min(1) }), body);
    if(new Set(data.items.map(item=>item.variantId)).size!==data.items.length)throw new BadRequestException('لا تكرر نفس الصنف في المرتجع');
    const returned = await prisma.$transaction(async tx => {
      const purchase = data.purchaseId ? await tx.purchase.findUnique({ where: { id: data.purchaseId }, include: { items: true } }) : null;
      if (data.purchaseId && (!purchase || purchase.supplierId !== data.supplierId || purchase.warehouseId !== data.warehouseId)) throw new BadRequestException('الفاتورة أو المورد أو المخزن لا يطابق المرتجع');
      const previous = data.purchaseId ? await tx.supplierReturn.findMany({ where: { purchaseId: data.purchaseId }, include: { items: true } }) : [];
      const items = data.items.map(item => { if (!purchase) return item; const purchaseLine = purchase.items.find(line => line.variantId === item.variantId); if (!purchaseLine) throw new BadRequestException('الصنف غير موجود في فاتورة الشراء'); const already = previous.reduce((sum, row) => sum + row.items.filter(returnedItem => returnedItem.variantId === item.variantId).reduce((quantity, returnedItem) => quantity + returnedItem.quantity, 0), 0); if (already + item.quantity > purchaseLine.quantity) throw new BadRequestException('كمية المرتجع تتجاوز الكمية المشتراة بعد المرتجعات السابقة'); return { ...item, unitCost: Number(purchaseLine.unitCost) }; });
      for (const item of items) { const changed = await tx.stockBalance.updateMany({ where: { variantId: item.variantId, warehouseId: data.warehouseId, quantity: { gte: item.quantity } }, data: { quantity: { decrement: item.quantity }, version: { increment: 1 } } }); if (!changed.count) throw new BadRequestException('رصيد المخزن غير كافٍ لمرتجع المورد'); }
      const row = await tx.supplierReturn.create({ data: { number: `SR-${Date.now().toString().slice(-8)}`, supplierId: data.supplierId, purchaseId: data.purchaseId, warehouseId: data.warehouseId, reason: data.reason, createdById: req.user!.sub, businessDate: businessDate(), items: { create: items } }, include: { items: true } });
      for (const item of items) await tx.stockMovement.create({ data: { variantId: item.variantId, warehouseId: data.warehouseId, quantity: -item.quantity, type: MovementType.ADJUSTMENT, reference: row.number, createdById: req.user!.sub } }); const total = money(items.reduce((sum, item) => sum + item.quantity * item.unitCost, 0)); await postSystemJournal(tx, req.user!.sub, `مرتجع مورد ${row.number}`, 'SupplierReturn', row.id, [{ code: '2000', debit: total }, { code: '1200', credit: total }]); return row; }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, 'RETURN', 'SupplierReturn', returned.id, { reason: data.reason }); return returned;
  }
  @Get('suppliers/:id/consignment') async consignmentStatement(@Param('id') id: string) {
    const supplier = await prisma.supplier.findFirst({ where: { id, deletedAt: null }, include: { consignmentSaleItems: { where: { ownerSupplierId: id }, include: { sale: true, variant: { include: { product: true } }, returnItems: { include: { saleReturn: true } } } }, consignmentSettlements: { orderBy: { createdAt: 'desc' } } } });
    if (!supplier) throw new NotFoundException('صاحب البضاعة غير موجود');
    const items = supplier.consignmentSaleItems.map((item: any) => {
      const returnedQty = item.returnItems.reduce((sum: number, row: any) => sum + row.quantity, 0);
      const returnedPayout = money(item.returnItems.reduce((sum: number, row: any) => sum + Number(row.ownerPayout), 0));
      return { id: item.id, invoiceNo: item.sale.invoiceNo, date: item.sale.createdAt, product: item.variant.product.name, variant: item.variant.name, quantity: item.quantity, returnedQuantity: returnedQty, ownerPayout: Number(item.ownerPayout), returnedPayout, outstanding: money(Number(item.ownerPayout) - returnedPayout), storeCommission: Number(item.storeCommission) };
    });
    const earned = money(items.reduce((sum: number, row: any) => sum + row.outstanding, 0));
    const paid = money(supplier.consignmentSettlements.reduce((sum: number, row: any) => sum + Number(row.amount), 0));
    return { supplier: { id: supplier.id, name: supplier.name }, summary: { earned, paid, outstanding: money(earned - paid), soldItems: items }, transactions: [
      ...items.map((row: any) => ({ id: row.id, type: 'SALE', date: row.date, number: row.invoiceNo, description: `${row.product} · ${row.variant} · ${row.quantity - row.returnedQuantity} قطعة`, amount: row.ownerPayout - row.returnedPayout })),
      ...supplier.consignmentSettlements.map((row: any) => ({ id: row.id, type: 'SETTLEMENT', date: row.createdAt, number: row.number, description: row.reference || 'دفعة تسوية لصاحب البضاعة', amount: Number(row.amount), method: row.method })),
      ...items.filter((row: any) => row.returnedPayout > 0).map((row: any) => ({ id: `${row.id}-return`, type: 'RETURN', date: row.date, number: row.invoiceNo, description: `خصم مرتجع · ${row.product}`, amount: -row.returnedPayout })),
    ].sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime()) };
  }
  @Post('suppliers/:id/consignment/payments') async payConsignment(@Param('id') id: string, @Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ amount: positiveCurrency, method: z.nativeEnum(PaymentMethod), reference: z.string().max(180).optional() }), body);
    const occurredAt = new Date();
    const payment = await prisma.$transaction(async tx => {
      const supplier = await tx.supplier.findFirst({ where: { id, deletedAt: null, active: true } }); if (!supplier) throw new NotFoundException('صاحب البضاعة غير موجود أو غير نشط');
      const saleItems = await tx.saleItem.findMany({ where: { ownerSupplierId: id }, include: { returnItems: true } });
      const earned = money(saleItems.reduce((sum, item) => { const returned = item.returnItems.reduce((qty, row) => qty + Number(row.ownerPayout), 0); return sum + Number(item.ownerPayout) - returned; }, 0));
      const settled = await tx.consignmentSettlement.aggregate({ where: { supplierId: id }, _sum: { amount: true } }); const outstanding = money(earned - Number(settled._sum.amount || 0));
      if (data.amount > outstanding) throw new BadRequestException(`المبلغ أكبر من مستحق صاحب البضاعة (${Math.max(0, outstanding)})`);
      const available = await this.availableSafe(tx, data.method); if (data.amount > available) throw new BadRequestException(`رصيد ${data.method} في الخزنة غير كافٍ؛ المتاح ${money(available)}`);
      const record = await tx.consignmentSettlement.create({ data: { number: `CS-${Date.now().toString().slice(-8)}-${Math.floor(Math.random()*900+100)}`, supplierId: id, amount: data.amount, method: data.method, reference: data.reference, createdById: req.user!.sub, businessDate: businessDate(occurredAt) } });
      await tx.cashMovement.create({ data: { number: `CSP-${record.number}`, type: CashMovementType.SAFE_WITHDRAWAL, status: CashMovementStatus.APPROVED, amount: data.amount, paymentMethod: data.method, reason: `تسوية بضاعة أمانة — ${supplier.name} — ${record.number}`, requestedById: req.user!.sub, approvedById: req.user!.sub, approvedAt: occurredAt, businessDate: businessDate(occurredAt) } });
      await postSystemJournal(tx, req.user!.sub, `تسوية بضاعة أمانة ${supplier.name}`, 'ConsignmentSettlement', record.id, [{ code: '2200', debit: data.amount }, { code: paymentAccount(data.method), credit: data.amount }], occurredAt);
      return record;
    }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, 'SETTLE_CONSIGNMENT', 'ConsignmentSettlement', payment.id, { supplierId: id, amount: data.amount, method: data.method }); return payment;
  }
}

@Controller('expenses') @UseGuards(JwtGuard)
class ExpensesController {
  @Get() @UseGuards(requirePermission('expenses.view')) async list(@Query('drawerSessionId') drawerSessionId?: string, @Req() req?: AuthRequest) {
    const manager = req!.user!.role === RoleCode.OWNER || req!.user!.role === RoleCode.ACCOUNTANT;
    if (!drawerSessionId) return prisma.expense.findMany({ where: manager ? {} : { createdById: req!.user!.sub }, orderBy: { occurredAt: 'desc' }, take: 200 });
    const session = await prisma.drawerSession.findUnique({ where: { id: drawerSessionId } });
    if (!session) throw new NotFoundException('الوردية غير موجودة');
    if (!manager && session.userId !== req!.user!.sub) throw new ForbiddenException('لا تملك صلاحية عرض هذه الوردية');
    return prisma.expense.findMany({ where: { OR: [{ drawerSessionId }, { drawerSessionId: null, createdById: session.userId, occurredAt: { gte: session.openedAt, lte: session.closedAt ?? new Date() } }] }, orderBy: { occurredAt: 'desc' }, take: 200 });
  }
  @Post() @UseGuards(requirePermission('expenses.create')) async create(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ category: z.string().min(2).max(80), description: z.string().min(3).max(300), amount: positiveCurrency, paymentMethod: z.enum(['CASH','CARD','VODAFONE_CASH','INSTAPAY']), occurredAt: z.coerce.date().optional() }), body);
    const occurredAt = data.occurredAt ?? new Date(); const day = businessDate(occurredAt); const activeSession = await prisma.drawerSession.findFirst({ where: { userId: req.user!.sub, status: DrawerStatus.OPEN }, orderBy: { openedAt: 'desc' } }); const drawerSessionId = activeSession && occurredAt >= activeSession.openedAt && occurredAt <= new Date() ? activeSession.id : undefined; const expense = await prisma.$transaction(async tx => { const row = await tx.expense.create({ data: { ...data, occurredAt, businessDate: day, drawerSessionId, createdById: req.user!.sub } }); await postSystemJournal(tx, req.user!.sub, `مصروف ${data.category}`, 'Expense', row.id, [{ code: '6000', debit: data.amount }, { code: paymentAccount(data.paymentMethod ?? PaymentMethod.CASH), credit: data.amount }], occurredAt); return row; }); await audit(req.user!.sub, 'CREATE', 'Expense', expense.id, { amount: data.amount, category: data.category, drawerSessionId }); return expense;
  }
}

type ProductImportData = { name: string; sku: string; variantName: string; barcode: string; barcodeGenerated?: boolean; price: number; cost: number; openingQty: number; warehouseId: string; categoryId?: string; supplierId?: string; size?: string; color?: string };
type ExpenseImportData = { category: string; description: string; amount: number; paymentMethod: PaymentMethod; occurredAt: Date };
const importText = (row: Record<string, unknown>, aliases: string[]) => { const entry = Object.entries(row).find(([key]) => aliases.includes(String(key).trim().toLowerCase())); return String(entry?.[1] ?? '').trim(); };
const importNumber = (value: string) => { const latin = value.replace(/[٠-٩]/g, digit => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit))).replace(/٬/g, '').replace(/،/g, '.').replace(/,/g, '.'); const number = Number(latin); return Number.isFinite(number) ? number : NaN; };
const ean13CheckDigit = (body: string) => String((10 - [...body].reduce((sum, digit, index) => sum + Number(digit) * (index % 2 ? 3 : 1), 0) % 10) % 10);
const generatedBarcode = (seed: string, occupied: Set<string>) => { let hash = 0; for (const character of seed) hash = ((hash << 5) - hash + character.charCodeAt(0)) | 0; const start = Math.abs(hash) % 1_000_000_000; for (let attempt = 0; attempt < 1000; attempt++) { const body = `200${String((start + attempt) % 1_000_000_000).padStart(9, '0')}`; const barcode = `${body}${ean13CheckDigit(body)}`; if (!occupied.has(barcode)) return barcode; } throw new BadRequestException('تعذر توليد باركود فريد'); };
const importPayment = (value: string): PaymentMethod | undefined => ({ CASH: PaymentMethod.CASH, 'نقد': PaymentMethod.CASH, 'نقدي': PaymentMethod.CASH, 'نقدية': PaymentMethod.CASH, CARD: PaymentMethod.CARD, 'فيزا': PaymentMethod.CARD, 'بطاقة': PaymentMethod.CARD, VODAFONE_CASH: PaymentMethod.VODAFONE_CASH, 'فودافون كاش': PaymentMethod.VODAFONE_CASH, INSTAPAY: PaymentMethod.INSTAPAY, 'انستا باي': PaymentMethod.INSTAPAY, 'إنستا باي': PaymentMethod.INSTAPAY }[value.trim().toUpperCase()] || ({ 'فودافون كاش': PaymentMethod.VODAFONE_CASH, 'انستا باي': PaymentMethod.INSTAPAY, 'إنستا باي': PaymentMethod.INSTAPAY } as Record<string, PaymentMethod>)[value.trim()]);

@Controller('imports') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT))
class ImportsController {
  private workbookRows(file: any) {
    if (!file?.buffer?.length) throw new BadRequestException('اختر ملف Excel صالحاً أولاً');
    let workbook: XLSX.WorkBook;
    try { workbook = XLSX.read(file.buffer, { type: 'buffer', cellDates: true }); } catch { throw new BadRequestException('تعذر قراءة ملف Excel'); }
    const sheetName = workbook.SheetNames[0]; if (!sheetName) throw new BadRequestException('الملف لا يحتوي على ورقة بيانات');
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(workbook.Sheets[sheetName], { defval: '', raw: false, dateNF: 'yyyy-mm-dd' });
    if (!rows.length) throw new BadRequestException('ملف Excel لا يحتوي على صفوف بيانات');
    if (rows.length > 1000) throw new BadRequestException('الحد الأقصى للاستيراد هو 1000 صف في المرة الواحدة');
    return rows;
  }
  private sendTemplate(res: any, name: string, data: object[]) {
    const sheet = XLSX.utils.json_to_sheet(data); sheet['!cols'] = Object.keys((data[0] || {}) as object).map(() => ({ wch: 22 }));
    const book = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(book, sheet, 'استيراد');
    const content = XLSX.write(book, { type: 'buffer', bookType: 'xlsx' }); res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); res.setHeader('Content-Disposition', `attachment; filename="${name}"`); return res.send(content);
  }
  @Get('products/template') templateProducts(@Res() res: any) { return this.sendTemplate(res, 'draft-products-template.xlsx', [{ 'اسم المنتج': 'تي شيرت قطن', SKU: 'TSHIRT-001', 'اسم المتغير': 'مقاس M', الباركود: '628100000001', 'سعر البيع': 250, التكلفة: 145, 'الكمية الافتتاحية': 10, المخزن: '', القسم: '', المورد: '', المقاس: 'M', اللون: 'أبيض' }]); }
  @Get('expenses/template') templateExpenses(@Res() res: any) { return this.sendTemplate(res, 'draft-expenses-template.xlsx', [{ الفئة: 'إيجار', الوصف: 'إيجار شهر أغسطس', المبلغ: 5000, 'طريقة الدفع': 'نقدية', التاريخ: '2026-08-17' }]); }
  @Post('products/preview') @UseInterceptors(FileInterceptor('file', { storage: memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } })) async previewProducts(@UploadedFile() file: any, @Req() req: AuthRequest) {
    const rows = this.workbookRows(file); const [categories, suppliers, warehouses, existingProducts, existingVariants] = await Promise.all([prisma.category.findMany({ where: { deletedAt: null, active: true } }), prisma.supplier.findMany({ where: { deletedAt: null, active: true } }), prisma.warehouse.findMany({ where: { branch: { isActive: true } } }), prisma.product.findMany({ where: { deletedAt: null }, select: { sku: true } }), prisma.productVariant.findMany({ select: { barcode: true } })]); const categoryByName = new Map(categories.map(category => [category.name.trim().toLowerCase(), category])); const supplierByName = new Map(suppliers.map(supplier => [supplier.name.trim().toLowerCase(), supplier])); const warehouseByName = new Map(warehouses.map(warehouse => [warehouse.name.trim().toLowerCase(), warehouse])); const defaultWarehouse = warehouses[0]; if (!defaultWarehouse) throw new BadRequestException('لا يوجد مخزن نشط لاستقبال الكميات الافتتاحية'); const knownSkus = new Set(existingProducts.map(product => product.sku.trim().toLowerCase())); const knownBarcodes = new Set(existingVariants.map(variant => variant.barcode.trim().toLowerCase())); const sheetBarcodes = new Set<string>(); const sheetSkus = new Map<string, { name: string; categoryId?: string; supplierId?: string }>();
    const prepared = rows.map((row, index) => { const name = importText(row, ['اسم المنتج', 'name', 'product name']); const sku = importText(row, ['sku', 'كود المنتج']); const suppliedBarcode = importText(row, ['الباركود', 'barcode']); const barcode = suppliedBarcode || generatedBarcode(`${sku}|${name}|${index + 2}`, new Set([...knownBarcodes, ...sheetBarcodes])); const barcodeGenerated = !suppliedBarcode; const variantName = importText(row, ['اسم المتغير', 'variant', 'variant name']) || `المتغير الافتراضي — ${barcode}`; const rawPrice = importNumber(importText(row, ['سعر البيع', 'price', 'sale price'])); const rawCost = importNumber(importText(row, ['التكلفة', 'cost'])); const price = Number.isFinite(rawPrice) ? money(rawPrice) : NaN; const cost = Number.isFinite(rawCost) ? money(rawCost) : NaN; const openingRaw = importText(row, ['الكمية الافتتاحية', 'opening qty', 'opening quantity', 'quantity']); const openingQty = openingRaw ? importNumber(openingRaw) : 0; const categoryName = importText(row, ['القسم', 'الفئة', 'category']); const supplierName = importText(row, ['المورد', 'اسم المورد', 'supplier']); const warehouseName = importText(row, ['المخزن', 'warehouse']); const size = importText(row, ['المقاس', 'size']); const color = importText(row, ['اللون', 'color']); const errors: string[] = []; if (name.length < 2) errors.push('اسم المنتج مطلوب (حرفان على الأقل)'); if (sku.length < 2) errors.push('SKU مطلوب'); if (!(price > 0)) errors.push('سعر البيع يجب أن يكون أكبر من صفر'); if (!(cost >= 0)) errors.push('التكلفة غير صالحة'); if (!Number.isInteger(openingQty) || openingQty < 0) errors.push('الكمية الافتتاحية يجب أن تكون عدداً صحيحاً موجباً أو صفراً'); const category = categoryName ? categoryByName.get(categoryName.toLowerCase()) : undefined; if (categoryName && !category) errors.push(`القسم غير موجود: ${categoryName}`); const supplier = supplierName ? supplierByName.get(supplierName.toLowerCase()) : undefined; if (supplierName && !supplier) errors.push(`المورد غير موجود: ${supplierName}`); const warehouse = warehouseName ? warehouseByName.get(warehouseName.toLowerCase()) : defaultWarehouse; if (warehouseName && !warehouse) errors.push(`المخزن غير موجود: ${warehouseName}`); const skuKey = sku.toLowerCase(); const barcodeKey = barcode.toLowerCase(); if (knownSkus.has(skuKey)) errors.push('SKU مستخدم بالفعل'); if (knownBarcodes.has(barcodeKey) || sheetBarcodes.has(barcodeKey)) errors.push('الباركود مستخدم بالفعل أو مكرر في الملف'); sheetBarcodes.add(barcodeKey); const priorSku = sheetSkus.get(skuKey); if (priorSku && (priorSku.name !== name || priorSku.categoryId !== category?.id || priorSku.supplierId !== supplier?.id)) errors.push('صفوف SKU الواحد يجب أن تحمل نفس اسم المنتج والقسم والمورد'); else if (sku) sheetSkus.set(skuKey, { name, categoryId: category?.id, supplierId: supplier?.id }); const data: ProductImportData = { name, sku, variantName, barcode, barcodeGenerated, price, cost, openingQty, warehouseId: warehouse?.id || defaultWarehouse.id, categoryId: category?.id, supplierId: supplier?.id, size: size || undefined, color: color || undefined }; return { rowNumber: index + 2, data, status: errors.length ? 'REJECTED' : 'VALID', reason: errors.join(' · ') }; });
    const batch = await prisma.importBatch.create({ data: { kind: 'PRODUCTS', originalName: file.originalname || 'products.xlsx', totalRows: prepared.length, rejectedRows: prepared.filter(row => row.status === 'REJECTED').length, createdById: req.user!.sub, rows: { create: prepared.map(row => ({ rowNumber: row.rowNumber, data: row.data as any, status: row.status, reason: row.reason || null })) } }, include: { rows: { orderBy: { rowNumber: 'asc' } } } }); await audit(req.user!.sub, 'PREVIEW', 'ImportBatch', batch.id, { kind: batch.kind, totalRows: batch.totalRows }); return batch;
  }
  @Post('expenses/preview') @UseInterceptors(FileInterceptor('file', { storage: memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } })) async previewExpenses(@UploadedFile() file: any, @Req() req: AuthRequest) {
    const rows = this.workbookRows(file); const prepared = rows.map((row, index) => { const category = importText(row, ['الفئة', 'القسم', 'category']); const description = importText(row, ['الوصف', 'description']); const rawAmount = importNumber(importText(row, ['المبلغ', 'amount'])); const amount = Number.isFinite(rawAmount) ? money(rawAmount) : NaN; const methodText = importText(row, ['طريقة الدفع', 'payment method', 'payment']); const paymentMethod = importPayment(methodText); const dateText = importText(row, ['التاريخ', 'date']); const occurredAt = dateText ? new Date(dateText) : new Date(); const errors: string[] = []; if (category.length < 2) errors.push('الفئة مطلوبة'); if (description.length < 3) errors.push('الوصف مطلوب (3 أحرف على الأقل)'); if (!(amount > 0)) errors.push('المبلغ يجب أن يكون أكبر من صفر'); if (!paymentMethod) errors.push('طريقة الدفع غير مدعومة'); if (dateText && Number.isNaN(occurredAt.valueOf())) errors.push('التاريخ غير صالح؛ استخدم YYYY-MM-DD'); const data: ExpenseImportData = { category, description, amount, paymentMethod: paymentMethod || PaymentMethod.CASH, occurredAt }; return { rowNumber: index + 2, data, status: errors.length ? 'REJECTED' : 'VALID', reason: errors.join(' · ') }; }); const batch = await prisma.importBatch.create({ data: { kind: 'EXPENSES', originalName: file.originalname || 'expenses.xlsx', totalRows: prepared.length, rejectedRows: prepared.filter(row => row.status === 'REJECTED').length, createdById: req.user!.sub, rows: { create: prepared.map(row => ({ rowNumber: row.rowNumber, data: row.data as any, status: row.status, reason: row.reason || null })) } }, include: { rows: { orderBy: { rowNumber: 'asc' } } } }); await audit(req.user!.sub, 'PREVIEW', 'ImportBatch', batch.id, { kind: batch.kind, totalRows: batch.totalRows }); return batch;
  }
  @Get() async batches() { return prisma.importBatch.findMany({ select: { id: true, kind: true, originalName: true, status: true, totalRows: true, importedRows: true, rejectedRows: true, createdAt: true, completedAt: true }, orderBy: { createdAt: 'desc' }, take: 30 }); }
  @Get(':id') async batch(@Param('id') id: string) { const batch = await prisma.importBatch.findUnique({ where: { id }, include: { rows: { orderBy: { rowNumber: 'asc' } } } }); if (!batch) throw new NotFoundException('عملية الاستيراد غير موجودة'); return batch; }
  @Post(':id/retry-missing-barcodes') async retryMissingBarcodes(@Param('id') id: string, @Req() req: AuthRequest) {
    const batch = await prisma.importBatch.findUnique({ where: { id }, include: { rows: { where: { status: 'REJECTED' }, orderBy: { rowNumber: 'asc' } } } }); if (!batch) throw new NotFoundException('عملية الاستيراد غير موجودة'); if (batch.kind !== 'PRODUCTS') throw new BadRequestException('هذه العملية متاحة لاستيراد المنتجات فقط');
    const existingVariants = await prisma.productVariant.findMany({ select: { barcode: true } }); const occupied = new Set(existingVariants.map(variant => variant.barcode.toLowerCase())); const generated: { rowNumber: number; sku: string; barcode: string }[] = [];
    for (const row of batch.rows) { const original = row.data as unknown as ProductImportData; if (!row.reason?.includes('الباركود مطلوب') || original.sku.trim().length < 2 || original.name.trim().length < 2) continue; const duplicateSku = await prisma.product.findFirst({ where: { sku: original.sku, deletedAt: null }, select: { id: true } }); if (duplicateSku) continue; const barcode = generatedBarcode(`${original.sku}|${original.name}|${row.rowNumber}`, occupied); occupied.add(barcode); const data: ProductImportData = { ...original, barcode, barcodeGenerated: true, variantName: original.variantName || `المتغير الافتراضي — ${barcode}` };
      try { const product = await prisma.$transaction(async tx => { const p = await tx.product.create({ data: { name: data.name, sku: data.sku, categoryId: data.categoryId, supplierId: data.supplierId, variants: { create: { name: data.variantName, barcode: data.barcode, size: data.size, color: data.color, price: data.price, cost: data.cost } } }, include: { variants: true } }); if (data.openingQty) { await tx.stockBalance.create({ data: { variantId: p.variants[0].id, warehouseId: data.warehouseId, quantity: data.openingQty } }); await tx.stockMovement.create({ data: { variantId: p.variants[0].id, warehouseId: data.warehouseId, quantity: data.openingQty, type: MovementType.OPENING, reference: p.sku, createdById: req.user!.sub } }); } return p; }); await prisma.importBatchRow.update({ where: { id: row.id }, data: { data: data as any, status: 'IMPORTED', entityId: product.id, reason: null } }); generated.push({ rowNumber: row.rowNumber, sku: data.sku, barcode }); } catch { await prisma.importBatchRow.update({ where: { id: row.id }, data: { reason: 'تعذر حفظ المنتج بعد توليد الباركود؛ راجع البيانات' } }); }
    }
    const [importedRows, rejectedRows] = await Promise.all([prisma.importBatchRow.count({ where: { batchId: id, status: 'IMPORTED' } }), prisma.importBatchRow.count({ where: { batchId: id, status: 'REJECTED' } })]); await prisma.importBatch.update({ where: { id }, data: { importedRows, rejectedRows, completedAt: new Date() } }); await audit(req.user!.sub, 'RETRY_GENERATED_BARCODES', 'ImportBatch', id, { generated }); return { ...(await this.batch(id)), generated };
  }
  @Post(':id/commit') async commit(@Param('id') id: string, @Req() req: AuthRequest) {
    const batch = await prisma.importBatch.findUnique({ where: { id }, include: { rows: { where: { status: 'VALID' }, orderBy: { rowNumber: 'asc' } } } }); if (!batch) throw new NotFoundException('عملية الاستيراد غير موجودة'); if (batch.status === 'COMPLETED') return this.batch(id);
    if (batch.kind === 'PRODUCTS') { const groups = new Map<string, typeof batch.rows>(); for (const row of batch.rows) { const data = row.data as unknown as ProductImportData; const key = data.sku.toLowerCase(); groups.set(key, [...(groups.get(key) || []), row]); } for (const rows of groups.values()) { const first = rows[0].data as unknown as ProductImportData; try { const product = await prisma.$transaction(async tx => { const p = await tx.product.create({ data: { name: first.name, sku: first.sku, categoryId: first.categoryId, supplierId: first.supplierId, variants: { create: rows.map(row => { const data = row.data as unknown as ProductImportData; return { name: data.variantName, barcode: data.barcode, size: data.size, color: data.color, price: data.price, cost: data.cost }; }) } }, include: { variants: true } }); for (let index = 0; index < rows.length; index++) { const data = rows[index].data as unknown as ProductImportData; if (data.openingQty) { await tx.stockBalance.create({ data: { variantId: p.variants[index].id, warehouseId: data.warehouseId, quantity: data.openingQty } }); await tx.stockMovement.create({ data: { variantId: p.variants[index].id, warehouseId: data.warehouseId, quantity: data.openingQty, type: MovementType.OPENING, reference: p.sku, createdById: req.user!.sub } }); } } return p; }); await prisma.importBatchRow.updateMany({ where: { id: { in: rows.map(row => row.id) } }, data: { status: 'IMPORTED', entityId: product.id, reason: null } }); } catch (error: any) { const reason = error?.code === 'P2002' ? 'تعارض: SKU أو باركود مستخدم بالفعل أثناء الحفظ' : 'تعذر حفظ المنتج؛ راجع البيانات'; await prisma.importBatchRow.updateMany({ where: { id: { in: rows.map(row => row.id) } }, data: { status: 'REJECTED', reason } }); } }
    } else if (batch.kind === 'EXPENSES') { for (const row of batch.rows) { const data = row.data as unknown as ExpenseImportData; try { const occurredAt = new Date(data.occurredAt); const expense = await prisma.$transaction(async tx => { const created = await tx.expense.create({ data: { ...data, occurredAt, businessDate: businessDate(occurredAt), createdById: req.user!.sub } }); await postSystemJournal(tx, req.user!.sub, `مصروف ${data.category}`, 'Expense', created.id, [{ code: '6000', debit: data.amount }, { code: paymentAccount(data.paymentMethod), credit: data.amount }], occurredAt); return created; }); await prisma.importBatchRow.update({ where: { id: row.id }, data: { status: 'IMPORTED', entityId: expense.id, reason: null } }); } catch { await prisma.importBatchRow.update({ where: { id: row.id }, data: { status: 'REJECTED', reason: 'تعذر حفظ المصروف؛ راجع البيانات' } }); } }
    } else throw new BadRequestException('نوع الاستيراد غير مدعوم');
    const [importedRows, rejectedRows] = await Promise.all([prisma.importBatchRow.count({ where: { batchId: id, status: 'IMPORTED' } }), prisma.importBatchRow.count({ where: { batchId: id, status: 'REJECTED' } })]); await prisma.importBatch.update({ where: { id }, data: { status: 'COMPLETED', importedRows, rejectedRows, completedAt: new Date() } }); await audit(req.user!.sub, 'COMMIT', 'ImportBatch', id, { importedRows, rejectedRows }); return this.batch(id);
  }
}

@Controller('reports') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT))
class ReportsController {
  @Get('supplier-performance') @UseGuards(requirePermission('suppliers.manage')) async supplierPerformance() {
    const [suppliers, lines, purchases] = await Promise.all([
      prisma.supplier.findMany({ where: { deletedAt: null, active: true }, select: { id: true, name: true, paymentFlexibility: true, creditTermDays: true, paymentNotes: true } }),
      prisma.saleItem.findMany({ where: { sale: { status: { not: SaleStatus.CANCELLED } } }, select: { quantity: true, total: true, costAtSale: true, ownerSupplierId: true, ownerPayout: true, variant: { select: { product: { select: { supplierId: true } } } }, returnItems: { select: { quantity: true, total: true, ownerPayout: true } } } }),
      prisma.purchase.findMany({ select: { supplierId: true, paymentTerms: true } })
    ]);
    return buildSupplierPerformance(suppliers, lines, purchases);
  }
  @Patch('supplier-performance/:id') @UseGuards(requirePermission('suppliers.manage')) async updateSupplierPerformance(@Param('id') id: string, @Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ paymentFlexibility: z.number().int().min(1).max(5).nullable(), creditTermDays: z.number().int().min(0).max(3650).nullable(), paymentNotes: z.string().trim().max(500).nullable() }).strict(), body);
    const supplier = await prisma.supplier.findFirst({ where: { id, deletedAt: null, active: true }, select: { id: true } });
    if (!supplier) throw new NotFoundException('المورد غير موجود');
    const result = await prisma.supplier.update({ where: { id }, data, select: { id: true, paymentFlexibility: true, creditTermDays: true, paymentNotes: true } });
    await audit(req.user!.sub, 'UPDATE_PAYMENT_TERMS', 'Supplier', id, data);
    return result;
  }
  @Get('summary') async summary(@Query('from') from?: string, @Query('to') to?: string) {
    const parseDay = (value: string) => { if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new BadRequestException('تاريخ اليومية غير صالح؛ استخدم YYYY-MM-DD'); return new Date(`${value}T00:00:00.000Z`); }; const start = from ? parseDay(from) : businessDate(); const end = to ? parseDay(to) : start; if (end < start) throw new BadRequestException('نطاق اليومية غير صالح'); const range = { gte: start, lte: end };
    const [sales, saleItems, returnItems, returns, purchases, expenses, lowStock, inventoryVariants] = await Promise.all([
      prisma.sale.aggregate({ where: { status: { not: SaleStatus.CANCELLED }, businessDate: range }, _sum: { total: true }, _count: true }),
      prisma.saleItem.findMany({ where: { sale: { status: { not: SaleStatus.CANCELLED }, businessDate: range } }, select: { quantity: true, costAtSale: true } }),
      prisma.saleReturnItem.findMany({ where: { saleReturn: { businessDate: range } }, select: { quantity: true, saleItem: { select: { costAtSale: true } } } }),
      prisma.saleReturn.aggregate({ where: { businessDate: range }, _sum: { total: true }, _count: true }),
      prisma.purchase.aggregate({ where: { businessDate: range }, _sum: { total: true, paid: true }, _count: true }),
      prisma.expense.aggregate({ where: { businessDate: range }, _sum: { amount: true }, _count: true }),
      prisma.stockBalance.findMany({ where: { quantity: { lte: 3 } }, include: { variant: { include: { product: true } }, warehouse: true }, take: 20, orderBy: { quantity: 'asc' } }),
      prisma.productVariant.findMany({ where: { product: { deletedAt: null, active: true } }, select: { cost: true, balances: { select: { quantity: true } } } })
    ]);
    const revenue = Number(sales._sum.total ?? 0); const refund = Number(returns._sum.total ?? 0); const outgoing = Number(expenses._sum.amount ?? 0); const returnedCogs = money(returnItems.reduce((sum, item) => sum + item.quantity * Number(item.saleItem.costAtSale), 0)); const cogs = money(saleItems.reduce((sum, item) => sum + item.quantity * Number(item.costAtSale), 0) - returnedCogs); const netSales = money(revenue - refund); const grossProfit = money(netSales - cogs);
    const inventoryCost = money(inventoryVariants.reduce((sum, variant) => sum + Number(variant.cost) * variant.balances.reduce((quantity, balance) => quantity + balance.quantity, 0), 0));
    return { from: start, to: end, revenue, refund, expenses: outgoing, net: money(grossProfit - outgoing), cogs, returnedCogs, grossProfit, profitMargin: netSales ? money(grossProfit / netSales * 100) : 0, saleCount: sales._count, returnCount: returns._count, purchaseTotal: Number(purchases._sum.total ?? 0), purchasePaid: Number(purchases._sum.paid ?? 0), purchaseCount: purchases._count, expenseCount: expenses._count, inventoryCost, lowStock };
  }
  @Get('stagnation') async stagnation(@Query('page') pageRaw?: string, @Query('categoryId') categoryId?: string) { const page = Math.max(1, Number(pageRaw) || 1); const take = 10; const where = { product: { deletedAt: null, ...(categoryId ? { categoryId } : {}) } }; const [total, rows] = await Promise.all([prisma.productVariant.count({ where }), prisma.productVariant.findMany({ where, include: { product: { include: { category: true } }, balances: true, saleItems: { include: { sale: { select: { createdAt: true } } }, orderBy: { sale: { createdAt: 'desc' } }, take: 1 } }, skip: (page - 1) * take, take })]); const now = Date.now(); const data = rows.map(row => { const last = row.saleItems[0]?.sale.createdAt; return { id: row.id, product: row.product.name, variant: row.name, category: row.product.category?.name || 'بدون قسم', quantity: row.balances.reduce((sum, balance) => sum + balance.quantity, 0), lastSaleAt: last || null, daysWithoutSale: last ? Math.floor((now - last.valueOf()) / 864e5) : null }; }).sort((a, b) => (b.daysWithoutSale ?? 99999) - (a.daysWithoutSale ?? 99999)); return { data, meta: { page, limit: take, total, totalPages: Math.ceil(total / take) } }; }
  @Get('export') async export(@Query('from') from?: string, @Query('to') to?: string, @Res() res?: any) { const parseDay = (value: string) => { if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new BadRequestException('تاريخ اليومية غير صالح؛ استخدم YYYY-MM-DD'); return new Date(`${value}T00:00:00.000Z`); }; const start = from ? parseDay(from) : undefined; const end = to ? parseDay(to) : undefined; if (start && end && end < start) throw new BadRequestException('نطاق اليومية غير صالح'); const rows = await prisma.sale.findMany({ where: { status: { not: SaleStatus.CANCELLED }, ...(start || end ? { businessDate: { ...(start ? { gte: start } : {}), ...(end ? { lte: end } : {}) } } : {}) }, include: { customer: true }, orderBy: { createdAt: 'desc' }, take: 5000 }); const esc = (value: unknown) => `"${String(value ?? '').replaceAll('"', '""')}"`; const csv = ['رقم الفاتورة,تاريخ اليومية,وقت العملية,العميل,الإجمالي,طريقة الدفع', ...rows.map(row => [row.invoiceNo, row.businessDate.toISOString().slice(0, 10), row.createdAt.toISOString(), row.customer?.name || 'بيع مباشر', Number(row.total), row.paymentMethod].map(esc).join(','))].join('\n'); res!.setHeader('Content-Type', 'text/csv; charset=utf-8'); res!.setHeader('Content-Disposition', 'attachment; filename="draft-sales.csv"'); return res!.send(`\uFEFF${csv}`); }
  @Get('export/xlsx') async exportXlsx(@Query('from') from?: string, @Query('to') to?: string, @Res() res?: any) {
    const parseDay = (value: string) => { if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new BadRequestException('تاريخ اليومية غير صالح؛ استخدم YYYY-MM-DD'); return new Date(`${value}T00:00:00.000Z`); }; const start = from ? parseDay(from) : undefined; const end = to ? parseDay(to) : undefined; if (start && end && end < start) throw new BadRequestException('نطاق اليومية غير صالح');
    const rows = await prisma.sale.findMany({ where: { status: { not: SaleStatus.CANCELLED }, ...(start || end ? { businessDate: { ...(start ? { gte: start } : {}), ...(end ? { lte: end } : {}) } } : {}) }, include: { customer: true, cashier: true, payments: true }, orderBy: { createdAt: 'desc' }, take: 5000 });
    const sheetRows = rows.map(row => ({ 'رقم الفاتورة': row.invoiceNo, 'تاريخ اليومية': row.businessDate.toISOString().slice(0, 10), 'وقت العملية': row.createdAt.toISOString(), العميل: row.customer?.name || 'بيع مباشر', الكاشير: row.cashier.name, 'الإجمالي': Number(row.total), المدفوع: Number(row.paid), 'طريقة الدفع الأساسية': row.paymentMethod, 'تفاصيل الدفعات': row.payments.map(payment => `${payment.method}: ${Number(payment.amount)}`).join(' | '), 'عدد الأصناف': undefined }));
    const fallback = [{ 'رقم الفاتورة': 'لا توجد مبيعات في الفترة المحددة' }]; const records: Record<string, unknown>[] = sheetRows.length ? sheetRows : fallback; const headers = Object.keys(records[0]); const sheet = XLSX.utils.json_to_sheet(records);
    sheet['!cols'] = [20, 24, 22, 18, 14, 14, 22, 34, 16, 14].map(wch => ({ wch })); const book = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(book, sheet, 'المبيعات');
    const content = XLSX.write(book, { type: 'buffer', bookType: 'xlsx' }); res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); res.setHeader('Content-Disposition', 'attachment; filename="draft-sales.xlsx"'); return res.send(content);
  }
}

@Controller('pos') @UseGuards(JwtGuard)
class PosController {
  @Get('context') @UseGuards(requirePermission('pos.use')) async context() { const warehouse = await prisma.warehouse.findFirst({ where: { branch: { isActive: true } }, orderBy: { name: 'asc' } }); if (!warehouse) throw new NotFoundException('لا يوجد مخزن نشط'); return { warehouseId: warehouse.id, warehouseName: warehouse.name }; }
  @Get('products') @UseGuards(requirePermission('pos.use')) async searchable() { return prisma.productVariant.findMany({ where: { product: { deletedAt: null, active: true } }, include: { product: { include: { category: true } }, balances: true }, take: 300 }); }
  @Post('sales') @UseGuards(requirePermission('sales.create')) async createSale(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ warehouseId: z.string().uuid(), customerId: z.string().uuid().optional(), channel: z.nativeEnum(SaleChannel).default(SaleChannel.POS), shippingName: z.string().min(2).max(100).optional(), shippingPhone: z.string().min(5).max(30).optional(), shippingAddress: z.string().min(5).max(300).optional(), paymentMethod: z.enum(['CASH','CARD','VODAFONE_CASH','INSTAPAY']).default('CASH'), payments: z.array(z.object({ method: z.enum(['CASH','CARD','VODAFONE_CASH','INSTAPAY']), amount: positiveCurrency, reference: z.string().max(100).optional() })).default([]), discount: nonnegativeCurrency.default(0), idempotencyKey: z.string().min(12), items: z.array(z.object({ variantId: z.string().uuid(), quantity: z.coerce.number().int().positive(), unitPrice: positiveCurrency.optional(), discount: nonnegativeCurrency.default(0) })).min(1) }), body);
    if (data.channel === SaleChannel.ONLINE && (!data.shippingName || !data.shippingPhone || !data.shippingAddress)) throw new BadRequestException('اسم المستلم ورقم الهاتف والعنوان مطلوبون لأوردر الشحن');
    const requestedPayments = data.payments ?? [];
    const existing = await prisma.sale.findUnique({ where: { idempotencyKey: data.idempotencyKey }, include: { items: true } }); if (existing) return existing;
    const drawerSession = data.channel === SaleChannel.POS ? await prisma.drawerSession.findFirst({ where: { userId: req.user!.sub, status: DrawerStatus.OPEN }, orderBy: { openedAt: 'desc' } }) : null;
    if (data.channel === SaleChannel.POS && !drawerSession) throw new BadRequestException('افتح وردية الدرج قبل إتمام البيع');
    return prisma.$transaction(async tx => {
      const variants = await tx.productVariant.findMany({ where: { id: { in: data.items.map(x => x.variantId) } }, include: { product: true } }); if (variants.length !== data.items.length) throw new NotFoundException('أحد المقاسات غير موجود');
      let subtotal = 0;
      for (const line of data.items) { const balance = await tx.stockBalance.findUnique({ where: { variantId_warehouseId: { variantId: line.variantId, warehouseId: data.warehouseId } } }); if (!balance || balance.quantity < line.quantity) throw new BadRequestException('المخزون غير كافٍ لأحد المنتجات'); }
      const prepared = data.items.map(line => { const v = variants.find(x => x.id === line.variantId)!; const unitPrice = line.unitPrice ?? Number(v.price); if (unitPrice < Number(v.price)) throw new BadRequestException('سعر البيع أقل من السعر الأساسي؛ استخدم خصم الصنف عند الحاجة'); const lineTotal = money(Math.max(0, unitPrice * line.quantity - (line.discount ?? 0))); subtotal += lineTotal; return { ...line, unitPrice, costAtSale: v.product.ownership === ProductOwnership.OWNED ? Number(v.cost) : 0, product: v.product, lineTotal, total: lineTotal, ownerPayout: 0, storeCommission: 0 }; });
      const discount = data.discount ?? 0;
      if (discount > subtotal) throw new BadRequestException('خصم الفاتورة لا يمكن أن يتجاوز قيمة المنتجات');
      const total = money(Math.max(0, subtotal - discount));
      let allocatedDiscount = 0;
      for (let index = 0; index < prepared.length; index++) {
        const line = prepared[index]; const share = index === prepared.length - 1 ? money(discount - allocatedDiscount) : (subtotal ? money(discount * line.lineTotal / subtotal) : 0); allocatedDiscount = money(allocatedDiscount + share); line.total = money(line.lineTotal - share);
        const product = line.product;
        if (product.ownership !== ProductOwnership.CONSIGNMENT) continue;
        if (!product.supplierId || !product.settlementMode) throw new BadRequestException(`اتفاق تسوية المنتج ${product.name} غير مكتمل`);
        if (product.settlementMode === ConsignmentSettlementMode.OWNER_FIXED_PRICE) line.ownerPayout = money(Number(product.ownerUnitPrice) * line.quantity);
        else if (product.settlementMode === ConsignmentSettlementMode.STORE_PERCENT) line.storeCommission = money(line.total * Number(product.storeCommissionPercent) / 100);
        else line.storeCommission = money(Number(product.storeCommissionPerUnit) * line.quantity);
        if (product.settlementMode !== ConsignmentSettlementMode.OWNER_FIXED_PRICE) line.ownerPayout = money(line.total - line.storeCommission);
        else line.storeCommission = money(line.total - line.ownerPayout);
        if (line.ownerPayout < 0 || line.storeCommission < 0) throw new BadRequestException(`قيمة التسوية لمنتج ${product.name} أكبر من صافي سعر البيع`);
      }
      const tenderedPayments: { method: PaymentMethod; amount: number; reference?: string }[] = requestedPayments.length ? requestedPayments.map(payment => ({ ...payment, method: payment.method as PaymentMethod })) : data.channel === SaleChannel.ONLINE ? [] : [{ method: (data.paymentMethod ?? PaymentMethod.CASH) as PaymentMethod, amount: total }]; const tendered = money(tenderedPayments.reduce((sum, payment) => sum + payment.amount, 0)); const nonCash = money(tenderedPayments.filter(payment => payment.method !== PaymentMethod.CASH).reduce((sum, payment) => sum + payment.amount, 0)); const cashTendered = money(tenderedPayments.filter(payment => payment.method === PaymentMethod.CASH).reduce((sum, payment) => sum + payment.amount, 0)); const cashDue = money(total - nonCash);
      if (data.channel === SaleChannel.ONLINE) { if (tendered > total) throw new BadRequestException('الدفعات المسجلة لا يمكن أن تتجاوز إجمالي أوردر الشحن'); }
      else { if (nonCash > total || cashDue < 0 || cashTendered < cashDue || tendered < total) throw new BadRequestException('مجموع الدفعات غير صالح لإجمالي الفاتورة'); if (tenderedPayments.every(payment => payment.method !== PaymentMethod.CASH) && tendered !== total) throw new BadRequestException('الدفعات غير النقدية يجب أن تساوي إجمالي الفاتورة'); }
      const payments = data.channel === SaleChannel.ONLINE ? tenderedPayments : [...tenderedPayments.filter(payment => payment.method !== PaymentMethod.CASH), ...(cashDue > 0 ? [{ method: PaymentMethod.CASH, amount: cashDue, reference: tenderedPayments.find(payment => payment.method === PaymentMethod.CASH)?.reference }] : [])]; const paidAmount = data.channel === SaleChannel.ONLINE ? tendered : total; const accountForPayment = data.channel === SaleChannel.ONLINE ? paymentAccount : drawerPaymentAccount; const occurredAt = new Date();
      const sale = await tx.sale.create({ data: { invoiceNo: `D-${Date.now().toString().slice(-8)}-${Math.floor(Math.random()*900+100)}`, channel: data.channel, shippingStatus: data.channel === SaleChannel.ONLINE ? ShippingStatus.PENDING : undefined, shippingName: data.shippingName, shippingPhone: data.shippingPhone, shippingAddress: data.shippingAddress, warehouseId: data.warehouseId, customerId: data.customerId, cashierId: req.user!.sub, drawerSessionId: drawerSession?.id, paymentMethod: payments[0]?.method ?? PaymentMethod.CASH, subtotal, discount, total, paid: paidAmount, idempotencyKey: data.idempotencyKey, businessDate: businessDate(occurredAt), items: { create: prepared.map(({ discount: _lineDiscount, product, lineTotal: _lineTotal, ...item }) => ({ ...item, ownerSupplierId: product.ownership === ProductOwnership.CONSIGNMENT ? product.supplierId : null })) }, payments: { create: payments.map(payment => ({ method: payment.method, amount: payment.amount, reference: payment.reference, businessDate: businessDate(occurredAt) })) } } });
      for (const line of prepared) { const changed = await tx.stockBalance.updateMany({ where: { variantId: line.variantId, warehouseId: data.warehouseId, quantity: { gte: line.quantity } }, data: { quantity: { decrement: line.quantity }, version: { increment: 1 } } }); if (!changed.count) throw new BadRequestException('تعارض في المخزون، أعد المحاولة'); await tx.stockMovement.create({ data: { variantId: line.variantId, warehouseId: data.warehouseId, quantity: -line.quantity, type: MovementType.SALE, reference: sale.invoiceNo, createdById: req.user!.sub } }); }
      if (data.customerId) await tx.customer.update({ where: { id: data.customerId }, data: { points: { increment: Math.floor(total / 100) } } });
      const due = money(total - paidAmount); const cogs = money(prepared.reduce((sum, line) => sum + line.quantity * line.costAtSale, 0)); const ownerPayable = money(prepared.reduce((sum, line) => sum + line.ownerPayout, 0)); const storeRevenue = money(total - ownerPayable); await postSystemJournal(tx, req.user!.sub, `بيع ${sale.invoiceNo}`, 'Sale', sale.id, [...paymentJournalLines(payments, 'debit', accountForPayment), ...(due > 0 ? [{ code: '1100', debit: due }] : []), ...(storeRevenue > 0 ? [{ code: '4000', credit: storeRevenue }] : []), ...(ownerPayable > 0 ? [{ code: '2200', credit: ownerPayable }] : [])], occurredAt); if (cogs) await postSystemJournal(tx, req.user!.sub, `تكلفة ${sale.invoiceNo}`, 'Sale', sale.id, [{ code: '5000', debit: cogs }, { code: '1200', credit: cogs }], occurredAt);
      await tx.auditLog.create({ data: { userId: req.user!.sub, action: 'CREATE', entity: 'Sale', entityId: sale.id, payload: { invoiceNo: sale.invoiceNo, channel: data.channel, total, paid: paidAmount, due, change: money(Math.max(0, tendered - total)), priceOverrides: prepared.filter(line => line.unitPrice !== Number(variants.find(v => v.id === line.variantId)!.price)).map(line => ({ variantId: line.variantId, catalogPrice: Number(variants.find(v => v.id === line.variantId)!.price), salePrice: line.unitPrice })) } } }); return { ...sale, tendered, due, change: money(Math.max(0, tendered - total)) };
    }, { isolationLevel: 'Serializable' });
  }
  @Post('suspended') @UseGuards(requirePermission('sales.create')) async suspend(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ warehouseId: z.string().uuid(), customerId: z.string().uuid().optional(), discount: nonnegativeCurrency.default(0), note: z.string().max(250).optional(), items: z.array(z.object({ variantId: z.string().uuid(), quantity: z.coerce.number().int().positive(), unitPrice: positiveCurrency.optional(), discount: nonnegativeCurrency.default(0) })).min(1) }), body);
    const row = await prisma.suspendedSale.create({ data: { token: `HOLD-${randomUUID().slice(0, 8).toUpperCase()}`, warehouseId: data.warehouseId, customerId: data.customerId, discount: data.discount, note: data.note, items: data.items, createdById: req.user!.sub } }); await audit(req.user!.sub, 'SUSPEND', 'Sale', row.id); return row;
  }
  @Get('suspended') @UseGuards(requirePermission('sales.create')) async suspended(@Req() req: AuthRequest) { return prisma.suspendedSale.findMany({ where: { createdById: req.user!.sub }, orderBy: { createdAt: 'desc' }, take: 30 }); }
  @Post('suspended/resume') @UseGuards(requirePermission('sales.create')) async resume(@Body() body: unknown, @Req() req: AuthRequest) { const { token } = parse(z.object({ token: z.string().min(6) }), body); const row = await prisma.suspendedSale.findUnique({ where: { token } }); if (!row || row.createdById !== req.user!.sub) throw new NotFoundException('الفاتورة المعلّقة غير موجودة'); await prisma.suspendedSale.delete({ where: { id: row.id } }); await audit(req.user!.sub, 'RESUME', 'Sale', row.id); return row; }
  @Post('returns') @UseGuards(requirePermission('sales.return')) async createReturn(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ saleId: z.string().uuid(), reason: z.string().min(3).max(180), refundMethod: z.nativeEnum(PaymentMethod).default(PaymentMethod.CASH), items: z.array(z.object({ saleItemId: z.string().uuid(), quantity: z.coerce.number().int().positive() })).min(1) }), body);
    if (new Set(data.items.map(item => item.saleItemId)).size !== data.items.length) throw new BadRequestException('لا يمكن تكرار نفس صنف الفاتورة في المرتجع');
    const refundDrawerSession = await prisma.drawerSession.findFirst({ where: { userId: req.user!.sub, status: DrawerStatus.OPEN }, orderBy: { openedAt: 'desc' } });
    if (!refundDrawerSession) throw new BadRequestException('افتح وردية الدرج قبل تنفيذ المرتجع لتتم مطابقة الاسترداد');
    const returned = await prisma.$transaction(async tx => {
      const sale = await tx.sale.findUnique({ where: { id: data.saleId }, include: { items: { include: { variant: true, returnItems: true } }, returns: true } });
      if (!sale || sale.status !== SaleStatus.COMPLETED) throw new BadRequestException('الفاتورة غير متاحة للإرجاع');
      const returnItems = data.items.map(item => {
        const saleItem = sale.items.find(line => line.id === item.saleItemId);
        if (!saleItem) throw new BadRequestException('أحد أصناف المرتجع لا ينتمي إلى الفاتورة');
        const alreadyReturned = saleItem.returnItems.reduce((sum, row) => sum + row.quantity, 0);
        if (item.quantity + alreadyReturned > saleItem.quantity) throw new BadRequestException('كمية المرتجع أكبر من الكمية المباعة');
        const nextReturned = alreadyReturned + item.quantity;
        const priorTotal = money(saleItem.returnItems.reduce((sum, row) => sum + Number(row.total), 0));
        const total = nextReturned === saleItem.quantity ? money(Number(saleItem.total) - priorTotal) : money(Number(saleItem.total) * item.quantity / saleItem.quantity);
        const priorPayout = alreadyReturned === saleItem.quantity ? Number(saleItem.ownerPayout) : money(Number(saleItem.ownerPayout) * alreadyReturned / saleItem.quantity);
        const nextPayout = nextReturned === saleItem.quantity ? money(Number(saleItem.ownerPayout) - priorPayout) : money(Number(saleItem.ownerPayout) * item.quantity / saleItem.quantity);
        const priorCommission = alreadyReturned === saleItem.quantity ? Number(saleItem.storeCommission) : money(Number(saleItem.storeCommission) * alreadyReturned / saleItem.quantity);
        const nextCommission = nextReturned === saleItem.quantity ? money(Number(saleItem.storeCommission) - priorCommission) : money(Number(saleItem.storeCommission) * item.quantity / saleItem.quantity);
        return { saleItem, quantity: item.quantity, total, ownerPayout: nextPayout, storeCommission: nextCommission };
      });
      const total = money(returnItems.reduce((sum, item) => sum + item.total, 0));
      const occurredAt = new Date(); const refundMethod = data.refundMethod ?? PaymentMethod.CASH; const record = await tx.saleReturn.create({ data: { saleId: sale.id, drawerSessionId: refundDrawerSession.id, total, reason: data.reason, refundMethod, refundAmount: total, businessDate: businessDate(occurredAt), createdById: req.user!.sub, items: { create: returnItems.map(item => ({ saleItemId: item.saleItem.id, variantId: item.saleItem.variantId, quantity: item.quantity, total: item.total, ownerPayout: item.ownerPayout, storeCommission: item.storeCommission })) } }, include: { items: true } });
      for (const item of returnItems) {
        await tx.stockBalance.upsert({ where: { variantId_warehouseId: { variantId: item.saleItem.variantId, warehouseId: sale.warehouseId } }, update: { quantity: { increment: item.quantity }, version: { increment: 1 } }, create: { variantId: item.saleItem.variantId, warehouseId: sale.warehouseId, quantity: item.quantity } });
        await tx.stockMovement.create({ data: { variantId: item.saleItem.variantId, warehouseId: sale.warehouseId, quantity: item.quantity, type: MovementType.RETURN, reference: sale.invoiceNo, createdById: req.user!.sub } });
      }
      const returnedItems = sale.items.reduce((sum, line) => sum + line.returnItems.reduce((inner, row) => inner + row.quantity, 0), 0) + returnItems.reduce((sum, item) => sum + item.quantity, 0);
      const soldItems = sale.items.reduce((sum, line) => sum + line.quantity, 0);
      if (returnedItems === soldItems) await tx.sale.update({ where: { id: sale.id }, data: { status: SaleStatus.RETURNED } });
      if (sale.customerId) await tx.customer.update({ where: { id: sale.customerId }, data: { points: { decrement: Math.floor(total / 100) } } });
      const ownerPayoutReturn = money(returnItems.reduce((sum, item) => sum + item.ownerPayout, 0)); const storeRevenueReturn = money(total - ownerPayoutReturn); const returnedCost = money(returnItems.reduce((sum, item) => sum + item.quantity * Number(item.saleItem.costAtSale), 0)); await postSystemJournal(tx, req.user!.sub, `مرتجع ${sale.invoiceNo}`, 'SaleReturn', record.id, [...(storeRevenueReturn > 0 ? [{ code: '4000', debit: storeRevenueReturn }] : []), ...(ownerPayoutReturn > 0 ? [{ code: '2200', debit: ownerPayoutReturn }] : []), { code: drawerPaymentAccount(refundMethod), credit: total }], occurredAt); if (returnedCost) await postSystemJournal(tx, req.user!.sub, `عكس تكلفة ${sale.invoiceNo}`, 'SaleReturn', record.id, [{ code: '1200', debit: returnedCost }, { code: '5000', credit: returnedCost }], occurredAt);
      return { record, invoiceNo: sale.invoiceNo, total };
    }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, 'RETURN', 'Sale', data.saleId, { returnId: returned.record.id, total: returned.total });
    return returned;
  }
  @Post('exchanges') @UseGuards(requirePermission('sales.exchange')) async exchange(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ saleId: z.string().uuid(), reason: z.string().min(3).max(180), returnItems: z.array(z.object({ saleItemId: z.string().uuid(), quantity: z.coerce.number().int().positive() })).min(1), newItems: z.array(z.object({ variantId: z.string().uuid(), quantity: z.coerce.number().int().positive(), discount: nonnegativeCurrency.default(0) })).min(1), payments: z.array(z.object({ method: z.enum(['CASH','CARD','VODAFONE_CASH','INSTAPAY']), amount: positiveCurrency, reference: z.string().max(100).optional() })).default([]), refundMethod: z.enum(['CASH','CARD','VODAFONE_CASH','INSTAPAY']).default('CASH'), idempotencyKey: z.string().min(12) }), body);
    const payments = data.payments ?? [];
    if (new Set(data.returnItems.map(item => item.saleItemId)).size !== data.returnItems.length || new Set(data.newItems.map(item => item.variantId)).size !== data.newItems.length) throw new BadRequestException('لا يمكن تكرار صنف في عملية الاستبدال');
    const exchangeDrawerSession = await prisma.drawerSession.findFirst({ where: { userId: req.user!.sub, status: DrawerStatus.OPEN }, orderBy: { openedAt: 'desc' } });
    if (!exchangeDrawerSession) throw new BadRequestException('افتح وردية الدرج قبل الاستبدال');
    const result = await prisma.$transaction(async tx => {
      const previous = await tx.sale.findUnique({ where: { id: data.saleId }, include: { items: { include: { variant: true, returnItems: true } } } }); if (!previous || previous.status !== SaleStatus.COMPLETED) throw new BadRequestException('الفاتورة غير متاحة للاستبدال');
      const returns = data.returnItems.map(item => { const line = previous.items.find(value => value.id === item.saleItemId); if (!line) throw new BadRequestException('أحد أصناف الاستبدال لا ينتمي إلى الفاتورة'); const alreadyReturned = line.returnItems.reduce((sum, value) => sum + value.quantity, 0); if (alreadyReturned + item.quantity > line.quantity) throw new BadRequestException('كمية الاستبدال أكبر من المتاح للإرجاع'); return { line, quantity: item.quantity, total: money(Number(line.unitPrice) * item.quantity) }; }); const returnedTotal = money(returns.reduce((sum, item) => sum + item.total, 0));
      const variants = await tx.productVariant.findMany({ where: { id: { in: data.newItems.map(item => item.variantId) } } }); if (variants.length !== data.newItems.length) throw new NotFoundException('أحد أصناف البيع البديل غير موجود');
      const newLines = data.newItems.map(item => { const variant = variants.find(value => value.id === item.variantId)!; const total = money(Math.max(0, Number(variant.price) * item.quantity - (item.discount ?? 0))); return { ...item, variant, unitPrice: Number(variant.price), costAtSale: Number(variant.cost), total }; }); const newTotal = money(newLines.reduce((sum, item) => sum + item.total, 0)); const difference = money(newTotal - returnedTotal);
      const tendered = money(payments.reduce((sum, item) => sum + item.amount, 0)); const nonCash = money(payments.filter(item => item.method !== PaymentMethod.CASH).reduce((sum, item) => sum + item.amount, 0)); const cashTendered = money(payments.filter(item => item.method === PaymentMethod.CASH).reduce((sum, item) => sum + item.amount, 0)); if (difference > 0 && (tendered < difference || nonCash > difference || cashTendered < difference - nonCash)) throw new BadRequestException('الدفعات لا تغطي فرق الاستبدال'); if (difference <= 0 && payments.length) throw new BadRequestException('لا تدخل دفعة عندما يكون الاستبدال استرداداً أو متعادلاً'); const settledPayments = difference > 0 ? [...payments.filter(item => item.method !== PaymentMethod.CASH), ...(difference > nonCash ? [{ method: PaymentMethod.CASH, amount: money(difference - nonCash), reference: payments.find(item => item.method === PaymentMethod.CASH)?.reference }] : [])] : [];
      for (const item of newLines) { const balance = await tx.stockBalance.findUnique({ where: { variantId_warehouseId: { variantId: item.variantId, warehouseId: previous.warehouseId } } }); const returnedHere = returns.filter(value => value.line.variantId === item.variantId).reduce((sum, value) => sum + value.quantity, 0); if ((!balance ? 0 : balance.quantity) + returnedHere < item.quantity) throw new BadRequestException('مخزون الصنف البديل غير كافٍ'); }
      const occurredAt = new Date(); const refundMethod = data.refundMethod ?? PaymentMethod.CASH; const returnRecord = await tx.saleReturn.create({ data: { saleId: previous.id, drawerSessionId: exchangeDrawerSession.id, total: returnedTotal, reason: data.reason, refundMethod, refundAmount: difference < 0 ? Math.abs(difference) : 0, businessDate: businessDate(occurredAt), createdById: req.user!.sub, items: { create: returns.map(item => ({ saleItemId: item.line.id, variantId: item.line.variantId, quantity: item.quantity, total: item.total })) } } });
      for (const item of returns) { await tx.stockBalance.upsert({ where: { variantId_warehouseId: { variantId: item.line.variantId, warehouseId: previous.warehouseId } }, update: { quantity: { increment: item.quantity }, version: { increment: 1 } }, create: { variantId: item.line.variantId, warehouseId: previous.warehouseId, quantity: item.quantity } }); await tx.stockMovement.create({ data: { variantId: item.line.variantId, warehouseId: previous.warehouseId, quantity: item.quantity, type: MovementType.RETURN, reference: `EXCHANGE:${previous.invoiceNo}`, createdById: req.user!.sub } }); }
      const replacement = await tx.sale.create({ data: { invoiceNo: `EX-${Date.now().toString().slice(-8)}-${Math.floor(Math.random()*900+100)}`, warehouseId: previous.warehouseId, customerId: previous.customerId, cashierId: req.user!.sub, drawerSessionId: exchangeDrawerSession.id, paymentMethod: (settledPayments[0]?.method ?? refundMethod) as PaymentMethod, subtotal: newTotal, discount: 0, total: newTotal, paid: newTotal, idempotencyKey: data.idempotencyKey, businessDate: businessDate(occurredAt), items: { create: newLines.map(item => ({ variantId: item.variantId, quantity: item.quantity, unitPrice: item.unitPrice, costAtSale: item.costAtSale, total: item.total })) }, payments: { create: settledPayments.map(item => ({ method: item.method as PaymentMethod, amount: item.amount, reference: item.reference, businessDate: businessDate(occurredAt) })) } } });
      for (const item of newLines) { const changed = await tx.stockBalance.updateMany({ where: { variantId: item.variantId, warehouseId: previous.warehouseId, quantity: { gte: item.quantity } }, data: { quantity: { decrement: item.quantity }, version: { increment: 1 } } }); if (!changed.count) throw new BadRequestException('تعارض في رصيد الصنف البديل'); await tx.stockMovement.create({ data: { variantId: item.variantId, warehouseId: previous.warehouseId, quantity: -item.quantity, type: MovementType.SALE, reference: `EXCHANGE:${replacement.invoiceNo}`, createdById: req.user!.sub } }); }
      const totalReturnedItems = previous.items.reduce((sum, line) => sum + line.returnItems.reduce((inner, value) => inner + value.quantity, 0), 0) + returns.reduce((sum, value) => sum + value.quantity, 0); if (totalReturnedItems === previous.items.reduce((sum, line) => sum + line.quantity, 0)) await tx.sale.update({ where: { id: previous.id }, data: { status: SaleStatus.RETURNED } });
      const returnedCost = money(returns.reduce((sum, item) => sum + item.quantity * Number(item.line.costAtSale), 0)); const saleCost = money(newLines.reduce((sum, item) => sum + item.quantity * item.costAtSale, 0)); const appliedCredit = Math.min(returnedTotal, newTotal); await postSystemJournal(tx, req.user!.sub, `استبدال مرتجع ${previous.invoiceNo}`, 'SaleReturn', returnRecord.id, [{ code: '4000', debit: returnedTotal }, { code: '2100', credit: returnedTotal }], occurredAt); await postSystemJournal(tx, req.user!.sub, `استبدال بيع ${replacement.invoiceNo}`, 'Sale', replacement.id, [{ code: '2100', debit: appliedCredit }, ...paymentJournalLines(settledPayments as { method: PaymentMethod; amount: number }[], 'debit', drawerPaymentAccount), { code: '4000', credit: newTotal }], occurredAt); if (difference < 0) await postSystemJournal(tx, req.user!.sub, `استرداد فرق الاستبدال ${previous.invoiceNo}`, 'SaleReturn', returnRecord.id, [{ code: '2100', debit: Math.abs(difference) }, { code: drawerPaymentAccount(refundMethod), credit: Math.abs(difference) }], occurredAt); if (returnedCost) await postSystemJournal(tx, req.user!.sub, `عكس تكلفة استبدال ${previous.invoiceNo}`, 'SaleReturn', returnRecord.id, [{ code: '1200', debit: returnedCost }, { code: '5000', credit: returnedCost }], occurredAt); if (saleCost) await postSystemJournal(tx, req.user!.sub, `تكلفة استبدال ${replacement.invoiceNo}`, 'Sale', replacement.id, [{ code: '5000', debit: saleCost }, { code: '1200', credit: saleCost }], occurredAt);
      return { returnId: returnRecord.id, replacementInvoiceNo: replacement.invoiceNo, returnedTotal, replacementTotal: newTotal, difference, change: difference > 0 ? money(tendered - difference) : 0, refund: difference < 0 ? Math.abs(difference) : 0, refundMethod: difference < 0 ? data.refundMethod : undefined };
    }, { isolationLevel: 'Serializable' }); await audit(req.user!.sub, 'EXCHANGE', 'Sale', data.saleId, result); return result;
  }
  @Post('cancel') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async cancel(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ saleId: z.string().uuid(), reason: z.string().min(3).max(180) }), body);
    const sale = await prisma.$transaction(async tx => {
      const row = await tx.sale.findUnique({ where: { id: data.saleId }, include: { items: true, returns: true, payments: true, drawerSession: true } });
      if (!row || row.status !== SaleStatus.COMPLETED) throw new BadRequestException('يمكن إلغاء فاتورة مكتملة فقط');
      if (row.returns.length) throw new BadRequestException('لا يمكن إلغاء فاتورة لها مرتجعات؛ أكمل المرتجع بدلاً من ذلك');
      if (!row.drawerSession || row.drawerSession.status !== DrawerStatus.OPEN || row.drawerSession.userId !== req.user!.sub) throw new BadRequestException('إلغاء الفاتورة متاح فقط قبل إغلاق وردية البائع؛ استخدم المرتجع بعد الإغلاق');
      await tx.sale.update({ where: { id: row.id }, data: { status: SaleStatus.CANCELLED } });
      for (const item of row.items) {
        await tx.stockBalance.upsert({ where: { variantId_warehouseId: { variantId: item.variantId, warehouseId: row.warehouseId } }, update: { quantity: { increment: item.quantity }, version: { increment: 1 } }, create: { variantId: item.variantId, warehouseId: row.warehouseId, quantity: item.quantity } });
        await tx.stockMovement.create({ data: { variantId: item.variantId, warehouseId: row.warehouseId, quantity: item.quantity, type: MovementType.RETURN, reference: `CANCEL:${row.invoiceNo}`, createdById: req.user!.sub } });
      }
      if (row.customerId) await tx.customer.update({ where: { id: row.customerId }, data: { points: { decrement: Math.floor(Number(row.total) / 100) } } }); const occurredAt = new Date(); const cost = money(row.items.reduce((sum, item) => sum + item.quantity * Number(item.costAtSale), 0)); await postSystemJournal(tx, req.user!.sub, `إلغاء ${row.invoiceNo}`, 'SaleCancel', row.id, [{ code: '4000', debit: Number(row.total) }, ...paymentJournalLines(row.payments.map(payment => ({ method: payment.method, amount: Number(payment.amount) })), 'credit', drawerPaymentAccount)], occurredAt); if (cost) await postSystemJournal(tx, req.user!.sub, `عكس تكلفة إلغاء ${row.invoiceNo}`, 'SaleCancel', row.id, [{ code: '1200', debit: cost }, { code: '5000', credit: cost }], occurredAt);
      return row;
    }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, 'CANCEL', 'Sale', sale.id, { invoiceNo: sale.invoiceNo, reason: data.reason }); return { id: sale.id, invoiceNo: sale.invoiceNo, status: SaleStatus.CANCELLED };
  }
  @Get('shipping-orders/variants') @UseGuards(requirePermission('sales.create')) async shippingReplacementVariants() { return prisma.productVariant.findMany({ where: { product: { deletedAt: null, active: true } }, include: { product: true, balances: { select: { warehouseId: true, quantity: true } } }, orderBy: [{ product: { name: 'asc' } }, { name: 'asc' }], take: 1000 }); }
  @Get('shipping-orders') @UseGuards(requirePermission('sales.view')) async shippingOrders() {
    const include = {
      customer: true,
      cashier: { select: { name: true } },
      items: { include: { variant: { include: { product: true } }, returnItems: true } },
      payments: true,
      returns: {
        include: {
          items: true,
          replacementSale: {
            select: {
              id: true, invoiceNo: true, total: true, paid: true,
              items: { include: { variant: { include: { product: true } } } }
            }
          }
        }
      }
    };
    const rows = await prisma.sale.findMany({
      where: { channel: SaleChannel.ONLINE },
      include,
      orderBy: { createdAt: 'desc' }, take: 300
    });
    return rows.map(sale => {
      const returnedTotal = sale.returns.reduce((sum, row) => sum + Number(row.total), 0);
      const replacementTotal = sale.returns.reduce((sum, row) => sum + Number(row.replacementSale?.total ?? 0), 0);
      const refunds = sale.returns.reduce((sum, row) => sum + Number(row.refundAmount), 0);
      const received = sale.items.reduce((sum, line) => sum + line.quantity - line.returnItems.reduce((inner, item) => inner + item.quantity, 0), 0);
      const total = money(Number(sale.total) + replacementTotal - returnedTotal);
      const paid = money(Number(sale.paid) - refunds);
      return { ...sale, netTotal: total, netPaid: paid, due: money(Math.max(0, total - paid)), refundable: money(Math.max(0, paid - total)), returnedTotal, replacementTotal, receivedQuantity: received };
    });
  }
  @Post('shipping-orders/:id/status') @UseGuards(requirePermission('sales.create')) async updateShippingStatus(@Param('id') id: string, @Body() body: unknown, @Req() req: AuthRequest) { const { status } = parse(z.object({ status: z.nativeEnum(ShippingStatus) }), body); const sale = await prisma.sale.findUnique({ where: { id } }); if (!sale || sale.channel !== SaleChannel.ONLINE || !sale.shippingStatus) throw new NotFoundException('أوردر الشحن غير موجود'); const next: Record<ShippingStatus, ShippingStatus[]> = { PENDING: [ShippingStatus.PREPARING], PREPARING: [ShippingStatus.SHIPPED], SHIPPED: [], DELIVERED: [], PARTIALLY_DELIVERED: [], RETURNED: [] }; if (!next[sale.shippingStatus].includes(status)) throw new BadRequestException('يجب تسجيل نتيجة الاستلام عند وصول الشحنة'); const updated = await prisma.sale.update({ where: { id }, data: { shippingStatus: status } }); await audit(req.user!.sub, 'SHIPPING_STATUS', 'Sale', id, { from: sale.shippingStatus, to: status }); return updated; }
  @Post('shipping-orders/:id/closeout') @UseGuards(requirePermission('sales.create')) async closeoutShippingOrder(@Param('id') id: string, @Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ reason: z.string().min(3).max(180).default('نتيجة تسليم شحنة'), refundMethod: z.nativeEnum(PaymentMethod).default(PaymentMethod.CASH), returnedItems: z.array(z.object({ saleItemId: z.string().uuid(), quantity: z.coerce.number().int().positive(), replacementVariantId: z.string().uuid().optional(), replacementQuantity: z.coerce.number().int().positive().optional() })).default([]), payments: z.array(z.object({ method: z.nativeEnum(PaymentMethod), amount: positiveCurrency, reference: z.string().max(100).optional() })).default([]) }), body);
    const returnedItemsInput = data.returnedItems ?? [];
    const paymentsInput = data.payments ?? [];
    const reason = data.reason ?? 'نتيجة تسليم شحنة';
    const refundMethod = data.refundMethod ?? PaymentMethod.CASH;
    if (new Set(returnedItemsInput.map(item => item.saleItemId)).size !== returnedItemsInput.length) throw new BadRequestException('لا يمكن تكرار الصنف نفسه في نتيجة التسليم');
    const occurredAt = new Date();
    const result = await prisma.$transaction(async tx => {
      const sale = await tx.sale.findUnique({ where: { id }, include: { items: { include: { variant: true, returnItems: true } }, returns: { include: { items: true, replacementSale: { include: { items: true } } } } } });
      if (!sale || sale.channel !== SaleChannel.ONLINE || sale.status !== SaleStatus.COMPLETED || sale.shippingStatus !== ShippingStatus.SHIPPED) throw new BadRequestException('سجل نتيجة الشحنة بعد تأكيد خروجها للتوصيل فقط');
      const returnLines = returnedItemsInput.map(item => {
        const line = sale.items.find(value => value.id === item.saleItemId);
        if (!line) throw new BadRequestException('أحد الأصناف لا ينتمي إلى أوردر الشحن');
        const alreadyReturned = line.returnItems.reduce((sum, row) => sum + row.quantity, 0);
        if (alreadyReturned + item.quantity > line.quantity) throw new BadRequestException('كمية المرتجع أكبر من المتبقي من الصنف');
        if (item.replacementQuantity && !item.replacementVariantId) throw new BadRequestException('اختر مقاس/صنف البديل');
        return { line, quantity: item.quantity, total: money(Number(line.unitPrice) * item.quantity), replacementVariantId: item.replacementVariantId, replacementQuantity: item.replacementVariantId ? (item.replacementQuantity ?? item.quantity) : 0 };
      });
      const returnedTotal = money(returnLines.reduce((sum, line) => sum + line.total, 0));
      const replacementVariantIds = [...new Set(returnLines.flatMap(line => line.replacementVariantId ? [line.replacementVariantId] : []))];
      const variants = replacementVariantIds.length ? await tx.productVariant.findMany({ where: { id: { in: replacementVariantIds }, product: { active: true, deletedAt: null } } }) : [];
      if (variants.length !== replacementVariantIds.length) throw new NotFoundException('أحد المقاسات البديلة غير موجود أو غير نشط');
      const replacementLines = returnLines.filter(line => line.replacementVariantId).map(line => { const variant = variants.find(value => value.id === line.replacementVariantId)!; const quantity = line.replacementQuantity; return { variant, quantity, unitPrice: Number(variant.price), costAtSale: Number(variant.cost), total: money(Number(variant.price) * quantity) }; });
      const replacementTotal = money(replacementLines.reduce((sum, line) => sum + line.total, 0));
      const previousReturns = sale.returns.reduce((sum, row) => sum + Number(row.total), 0);
      const previousRefunds = sale.returns.reduce((sum, row) => sum + Number(row.refundAmount), 0);
      const previousReplacementTotal = sale.returns.reduce((sum, row) => sum + Number(row.replacementSale?.total ?? 0), 0);
      const previousReplacementPaid = sale.returns.reduce((sum, row) => sum + Number(row.replacementSale?.paid ?? 0), 0);
      const priorDue = money(Math.max(0, Number(sale.total) + previousReplacementTotal - previousReturns - Number(sale.paid) - previousReplacementPaid + previousRefunds));
      const paymentTotal = money(paymentsInput.reduce((sum, payment) => sum + payment.amount, 0));
      const balanceBeforeCollection = money(priorDue + replacementTotal - returnedTotal);
      if (paymentTotal > Math.max(0, balanceBeforeCollection)) throw new BadRequestException('مبلغ التحصيل أكبر من المستحق بعد المرتجع/الاستبدال');
      const remainingDue = money(Math.max(0, balanceBeforeCollection - paymentTotal));
      const refundAmount = money(Math.max(0, -balanceBeforeCollection));
      const arChange = money(remainingDue - priorDue);
      let replacementSale: { id: string; invoiceNo: string } | null = null;
      if (replacementLines.length) {
        const record = await tx.sale.create({ data: { invoiceNo: `EX-SH-${Date.now().toString().slice(-8)}-${Math.floor(Math.random() * 900 + 100)}`, channel: SaleChannel.ONLINE, shippingStatus: ShippingStatus.DELIVERED, shippingName: sale.shippingName, shippingPhone: sale.shippingPhone, shippingAddress: sale.shippingAddress, warehouseId: sale.warehouseId, customerId: sale.customerId, cashierId: req.user!.sub, paymentMethod: paymentsInput[0]?.method ?? sale.paymentMethod, subtotal: replacementTotal, discount: 0, total: replacementTotal, paid: 0, idempotencyKey: randomUUID(), businessDate: businessDate(occurredAt), items: { create: replacementLines.map(line => ({ variantId: line.variant.id, quantity: line.quantity, unitPrice: line.unitPrice, costAtSale: line.costAtSale, total: line.total })) } }, select: { id: true, invoiceNo: true } });
        replacementSale = record;
      }
      let returnRecord: { id: string } | null = null;
      if (returnLines.length) returnRecord = await tx.saleReturn.create({ data: { saleId: sale.id, total: returnedTotal, reason, refundMethod, refundAmount, replacementSaleId: replacementSale ? replacementSale.id : null, createdById: req.user!.sub, businessDate: businessDate(occurredAt), items: { create: returnLines.map(line => ({ saleItemId: line.line.id, variantId: line.line.variantId, quantity: line.quantity, total: line.total })) } }, select: { id: true } });
      for (const line of returnLines) { await tx.stockBalance.upsert({ where: { variantId_warehouseId: { variantId: line.line.variantId, warehouseId: sale.warehouseId } }, update: { quantity: { increment: line.quantity }, version: { increment: 1 } }, create: { variantId: line.line.variantId, warehouseId: sale.warehouseId, quantity: line.quantity } }); await tx.stockMovement.create({ data: { variantId: line.line.variantId, warehouseId: sale.warehouseId, quantity: line.quantity, type: MovementType.RETURN, reference: `SHIP-RETURN:${sale.invoiceNo}`, createdById: req.user!.sub } }); }
      for (const line of replacementLines) { const changed = await tx.stockBalance.updateMany({ where: { variantId: line.variant.id, warehouseId: sale.warehouseId, quantity: { gte: line.quantity } }, data: { quantity: { decrement: line.quantity }, version: { increment: 1 } } }); if (!changed.count) throw new BadRequestException(`مخزون البديل ${line.variant.name} غير كافٍ`); await tx.stockMovement.create({ data: { variantId: line.variant.id, warehouseId: sale.warehouseId, quantity: -line.quantity, type: MovementType.SALE, reference: `SHIP-EXCHANGE:${replacementSale!.invoiceNo}`, createdById: req.user!.sub } }); }
      const returnCount = sale.returns.reduce((sum, row) => sum + row.items.reduce((inner, item) => inner + item.quantity, 0), 0) + returnLines.reduce((sum, line) => sum + line.quantity, 0);
      const soldCount = sale.items.reduce((sum, line) => sum + line.quantity, 0);
      const acceptedCount = soldCount - returnCount + replacementLines.reduce((sum, line) => sum + line.quantity, 0);
      const shippingStatus = returnCount === 0 || acceptedCount >= soldCount ? ShippingStatus.DELIVERED : acceptedCount === 0 ? ShippingStatus.RETURNED : ShippingStatus.PARTIALLY_DELIVERED;
      const saleStatus = returnCount === soldCount && replacementLines.length === 0 ? SaleStatus.RETURNED : SaleStatus.COMPLETED;
      const updatedSale = await tx.sale.update({ where: { id: sale.id }, data: { paid: money(Number(sale.paid) + paymentTotal), shippingStatus, status: saleStatus } });
      const payments = [];
      for (const payment of paymentsInput) payments.push(await tx.salePayment.create({ data: { saleId: sale.id, method: payment.method, amount: payment.amount, reference: payment.reference, businessDate: businessDate(occurredAt) } }));
      if (sale.customerId) { if (returnedTotal) await tx.customer.update({ where: { id: sale.customerId }, data: { points: { decrement: Math.floor(returnedTotal / 100) } } }); if (replacementTotal) await tx.customer.update({ where: { id: sale.customerId }, data: { points: { increment: Math.floor(replacementTotal / 100) } } }); }
      const journalLines = [ ...(returnedTotal ? [{ code: '4000', debit: returnedTotal }] : []), ...(replacementTotal ? [{ code: '4000', credit: replacementTotal }] : []), ...paymentJournalLines(paymentsInput, 'debit', paymentAccount), ...(refundAmount ? [{ code: paymentAccount(refundMethod), credit: refundAmount }] : []), ...(arChange > 0 ? [{ code: '1100', debit: arChange }] : arChange < 0 ? [{ code: '1100', credit: Math.abs(arChange) }] : []) ];
      if (journalLines.length) await postSystemJournal(tx, req.user!.sub, `تسوية شحنة ${sale.invoiceNo}`, 'SaleReturn', returnRecord?.id ?? sale.id, journalLines, occurredAt);
      const returnedCost = money(returnLines.reduce((sum, line) => sum + line.quantity * Number(line.line.costAtSale), 0)); const replacementCost = money(replacementLines.reduce((sum, line) => sum + line.quantity * line.costAtSale, 0));
      if (returnedCost) await postSystemJournal(tx, req.user!.sub, `عكس تكلفة مرتجع شحنة ${sale.invoiceNo}`, 'SaleReturn', returnRecord!.id, [{ code: '1200', debit: returnedCost }, { code: '5000', credit: returnedCost }], occurredAt);
      if (replacementCost) await postSystemJournal(tx, req.user!.sub, `تكلفة بديل شحنة ${replacementSale!.invoiceNo}`, 'Sale', replacementSale!.id, [{ code: '5000', debit: replacementCost }, { code: '1200', credit: replacementCost }], occurredAt);
      return { sale: updatedSale, shippingStatus, returnedTotal, replacementTotal, refundAmount, collected: paymentTotal, due: remainingDue, replacementInvoiceNo: replacementSale?.invoiceNo };
    }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, 'SHIPPING_CLOSEOUT', 'Sale', id, { ...result, reason });
    return result;
  }
  @Post('shipping-orders/:id/payments') @UseGuards(requirePermission('sales.create')) async collectShippingPayment(@Param('id') id: string, @Body() body: unknown, @Req() req: AuthRequest) { const data = parse(z.object({ method: z.nativeEnum(PaymentMethod), amount: positiveCurrency, reference: z.string().max(100).optional() }), body); const occurredAt = new Date(); const result = await prisma.$transaction(async tx => { const sale = await tx.sale.findUnique({ where: { id }, include: { returns: { include: { replacementSale: true } } } }); if (!sale || sale.channel !== SaleChannel.ONLINE || sale.status !== SaleStatus.COMPLETED || (sale.shippingStatus !== ShippingStatus.DELIVERED && sale.shippingStatus !== ShippingStatus.PARTIALLY_DELIVERED)) throw new NotFoundException('أوردر الشحن غير متاح للتحصيل'); const returned = sale.returns.reduce((sum, row) => sum + Number(row.total), 0); const replacements = sale.returns.reduce((sum, row) => sum + Number(row.replacementSale?.total ?? 0), 0); const refunds = sale.returns.reduce((sum, row) => sum + Number(row.refundAmount), 0); const due = money(Math.max(0, Number(sale.total) + replacements - returned - Number(sale.paid) + refunds)); if (data.amount > due) throw new BadRequestException('المبلغ أكبر من المتبقي على الأوردر'); const updated = await tx.sale.update({ where: { id }, data: { paid: money(Number(sale.paid) + data.amount) } }); const payment = await tx.salePayment.create({ data: { saleId: id, method: data.method, amount: data.amount, reference: data.reference, businessDate: businessDate(occurredAt) } }); await postSystemJournal(tx, req.user!.sub, `تحصيل أوردر الشحن ${sale.invoiceNo}`, 'SalePayment', payment.id, [{ code: paymentAccount(data.method), debit: data.amount }, { code: '1100', credit: data.amount }], occurredAt); return { sale: updated, payment, due: money(due - data.amount) }; }, { isolationLevel: 'Serializable' }); await audit(req.user!.sub, 'SHIPPING_PAYMENT', 'Sale', id, { amount: data.amount, method: data.method, remaining: result.due }); return result; }
  @Get('sales') @UseGuards(requirePermission('sales.view')) async sales(@Query('drawerSessionId') drawerSessionId?: string, @Req() req?: AuthRequest, @Query('search') search?: string) {
    const manager = req!.user!.role === RoleCode.OWNER || req!.user!.role === RoleCode.ACCOUNTANT;
    if (drawerSessionId) { const session = await prisma.drawerSession.findUnique({ where: { id: drawerSessionId }, select: { userId: true } }); if (!session) throw new NotFoundException('الوردية غير موجودة'); if (!manager && session.userId !== req!.user!.sub) throw new ForbiddenException('لا تملك صلاحية عرض هذه الوردية'); }
    const scope = drawerSessionId ? { drawerSessionId } : manager ? {} : { drawerSession: { userId: req!.user!.sub } };
    const query = search?.trim().slice(0, 100);
    const where = query ? { ...scope, OR: [{ invoiceNo: { contains: query, mode: 'insensitive' as const } }, { items: { some: { variant: { OR: [{ barcode: { contains: query, mode: 'insensitive' as const } }, { product: { sku: { contains: query, mode: 'insensitive' as const } } }] } } } }] } : scope;
    return prisma.sale.findMany({ where, include: { customer: true, cashier: { select: { name: true } }, items: { include: { variant: { include: { product: true } }, returnItems: true } }, returns: true, payments: true }, orderBy: { createdAt: 'desc' }, take: 500 });
  }
}

@Controller('inventory') @UseGuards(JwtGuard)
class InventoryController {
  @Get('summary') async summary() {
    const balances = await prisma.stockBalance.findMany({ include: { warehouse: { include: { branch: true } }, variant: { include: { product: true } } }, orderBy: [{ warehouse: { name: 'asc' } }, { updatedAt: 'desc' }] });
    const [movementCount, lowStock] = await Promise.all([prisma.stockMovement.count(), prisma.stockBalance.count({ where: { quantity: { lte: 3 } } })]);
    return { balances, movementCount, lowStock };
  }
  @Get('movements') async movements() { return prisma.stockMovement.findMany({ include: { warehouse: true, variant: { include: { product: true } } }, orderBy: { createdAt: 'desc' }, take: 150 }); }
  @Post('adjust') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async adjust(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ variantId: z.string().uuid(), warehouseId: z.string().uuid(), quantityDelta: z.coerce.number().int().refine(value => value !== 0), reference: z.string().min(3).max(180) }), body);
    const result = await prisma.$transaction(async tx => {
      const balance = await tx.stockBalance.findUnique({ where: { variantId_warehouseId: { variantId: data.variantId, warehouseId: data.warehouseId } } });
      if (!balance) throw new NotFoundException('لا يوجد رصيد لهذا الصنف في المخزن المحدد');
      const nextQuantity = balance.quantity + data.quantityDelta;
      if (nextQuantity < 0) throw new BadRequestException('لا يمكن أن يصبح رصيد المخزون سالباً');
      const updated = await tx.stockBalance.update({ where: { id: balance.id }, data: { quantity: nextQuantity, version: { increment: 1 } } });
      const movement = await tx.stockMovement.create({ data: { variantId: data.variantId, warehouseId: data.warehouseId, quantity: data.quantityDelta, type: MovementType.ADJUSTMENT, reference: data.reference, createdById: req.user!.sub } });
      return { balance: updated, movement };
    });
    await audit(req.user!.sub, 'ADJUST', 'StockBalance', result.balance.id, { quantityDelta: data.quantityDelta, reference: data.reference });
    return result;
  }
  @Post('transfer') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async transfer(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ variantId: z.string().uuid(), fromWarehouseId: z.string().uuid(), toWarehouseId: z.string().uuid(), quantity: z.coerce.number().int().positive(), reference: z.string().min(3).max(180) }), body);
    if (data.fromWarehouseId === data.toWarehouseId) throw new BadRequestException('اختر مخزنين مختلفين للتحويل');
    const moved = await prisma.$transaction(async tx => {
      const warehouses = await tx.warehouse.count({ where: { id: { in: [data.fromWarehouseId, data.toWarehouseId] } } });
      if (warehouses !== 2) throw new NotFoundException('أحد المخازن غير موجود');
      const changed = await tx.stockBalance.updateMany({ where: { variantId: data.variantId, warehouseId: data.fromWarehouseId, quantity: { gte: data.quantity } }, data: { quantity: { decrement: data.quantity }, version: { increment: 1 } } });
      if (!changed.count) throw new BadRequestException('رصيد المصدر غير كافٍ للتحويل');
      await tx.stockBalance.upsert({ where: { variantId_warehouseId: { variantId: data.variantId, warehouseId: data.toWarehouseId } }, update: { quantity: { increment: data.quantity }, version: { increment: 1 } }, create: { variantId: data.variantId, warehouseId: data.toWarehouseId, quantity: data.quantity } });
      const reference = `TRANSFER:${data.reference}`;
      await tx.stockMovement.createMany({ data: [
        { variantId: data.variantId, warehouseId: data.fromWarehouseId, quantity: -data.quantity, type: MovementType.ADJUSTMENT, reference, createdById: req.user!.sub },
        { variantId: data.variantId, warehouseId: data.toWarehouseId, quantity: data.quantity, type: MovementType.ADJUSTMENT, reference, createdById: req.user!.sub }
      ] });
      return { quantity: data.quantity, reference };
    }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, 'TRANSFER', 'StockBalance', data.variantId, { ...data, quantity: moved.quantity }); return moved;
  }
  @Get('counts') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async counts() { return prisma.inventoryCount.findMany({ include: { warehouse: true, items: { include: { variant: { include: { product: { include: { category: true } } } } } } }, orderBy: { createdAt: 'desc' }, take: 50 }); }
  @Post('counts') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async createCount(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ warehouseId: z.string().uuid(), scope: z.enum(['FULL','CATEGORY','PRODUCT']).default('FULL'), categoryId: z.string().uuid().optional(), productId: z.string().uuid().optional(), notes: z.string().max(300).optional() }), body);
    if (data.scope === 'CATEGORY' && !data.categoryId) throw new BadRequestException('اختر القسم المطلوب جرده');
    if (data.scope === 'PRODUCT' && !data.productId) throw new BadRequestException('اختر المنتج المطلوب جرده');
    const balanceWhere: any = { warehouseId: data.warehouseId };
    if (data.scope === 'CATEGORY') balanceWhere.variant = { product: { categoryId: data.categoryId } };
    if (data.scope === 'PRODUCT') balanceWhere.variant = { productId: data.productId };
    const balances = await prisma.stockBalance.findMany({ where: balanceWhere }); if (!balances.length) throw new BadRequestException('لا توجد أرصدة مطابقة لنطاق الجرد المحدد');
    const number = `IC-${Date.now().toString().slice(-8)}`;
    const count = await prisma.inventoryCount.create({ data: { number, warehouseId: data.warehouseId, notes: data.notes, createdById: req.user!.sub, items: { create: balances.map(balance => ({ variantId: balance.variantId, expectedQuantity: balance.quantity })) } }, include: { items: { include: { variant: { include: { product: { include: { category: true } } } } } }, warehouse: true } });
    await audit(req.user!.sub, 'CREATE', 'InventoryCount', count.id, { number, warehouseId: data.warehouseId, scope: data.scope, categoryId: data.categoryId, productId: data.productId }); return count;
  }
  @Post('counts/items') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async countItem(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ countId: z.string().uuid(), variantId: z.string().uuid(), countedQuantity: z.coerce.number().int().nonnegative() }), body);
    const row = await prisma.inventoryCount.findUnique({ where: { id: data.countId } }); if (!row || row.status !== InventoryCountStatus.DRAFT) throw new BadRequestException('الجرد غير متاح للتعديل');
    const item = await prisma.inventoryCountItem.update({ where: { inventoryCountId_variantId: { inventoryCountId: data.countId, variantId: data.variantId } }, data: { countedQuantity: data.countedQuantity } });
    await audit(req.user!.sub, 'COUNT', 'InventoryCount', data.countId, { variantId: data.variantId, countedQuantity: data.countedQuantity }); return item;
  }
  @Post('counts/submit') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async submitCount(@Body() body: unknown, @Req() req: AuthRequest) {
    const { countId } = parse(z.object({ countId: z.string().uuid() }), body); const count = await prisma.inventoryCount.findUnique({ where: { id: countId }, include: { items: true } });
    if (!count || count.status !== InventoryCountStatus.DRAFT) throw new BadRequestException('الجرد غير متاح للإرسال');
    if (count.items.some(item => item.countedQuantity === null)) throw new BadRequestException('أدخل الكمية الفعلية لكل أصناف الجرد قبل الإرسال');
    const updated = await prisma.inventoryCount.update({ where: { id: countId }, data: { status: InventoryCountStatus.SUBMITTED } }); await audit(req.user!.sub, 'SUBMIT', 'InventoryCount', countId); return updated;
  }
  @Post('counts/approve') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async approveCount(@Body() body: unknown, @Req() req: AuthRequest) {
    const { countId } = parse(z.object({ countId: z.string().uuid() }), body);
    const count = await prisma.$transaction(async tx => {
      const row = await tx.inventoryCount.findUnique({ where: { id: countId }, include: { items: true } }); if (!row || row.status !== InventoryCountStatus.SUBMITTED) throw new BadRequestException('الجرد غير جاهز للاعتماد');
      for (const item of row.items) {
        const balance = await tx.stockBalance.findUnique({ where: { variantId_warehouseId: { variantId: item.variantId, warehouseId: row.warehouseId } } }); if (!balance || item.countedQuantity === null) throw new BadRequestException('تعذر اعتماد أحد أصناف الجرد');
        const delta = item.countedQuantity - balance.quantity; if (!delta) continue;
        await tx.stockBalance.update({ where: { id: balance.id }, data: { quantity: item.countedQuantity, version: { increment: 1 } } });
        await tx.stockMovement.create({ data: { variantId: item.variantId, warehouseId: row.warehouseId, quantity: delta, type: MovementType.ADJUSTMENT, reference: row.number, createdById: req.user!.sub } });
      }
      return tx.inventoryCount.update({ where: { id: countId }, data: { status: InventoryCountStatus.APPROVED, approvedById: req.user!.sub, approvedAt: new Date() } });
    }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, 'APPROVE', 'InventoryCount', countId); return count;
  }
  @Get('transfers') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async transfers() { return prisma.stockTransfer.findMany({ include: { fromWarehouse: true, toWarehouse: true, items: { include: { variant: { include: { product: true } } } } }, orderBy: { createdAt: 'desc' }, take: 100 }); }
  @Post('transfers') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async requestTransfer(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ fromWarehouseId: z.string().uuid(), toWarehouseId: z.string().uuid(), notes: z.string().max(300).optional(), items: z.array(z.object({ variantId: z.string().uuid(), quantity: z.coerce.number().int().positive() })).min(1) }), body);
    if (data.fromWarehouseId === data.toWarehouseId) throw new BadRequestException('اختر مخزنين مختلفين'); if (new Set(data.items.map(item => item.variantId)).size !== data.items.length) throw new BadRequestException('لا تكرر الصنف في طلب التحويل');
    const transfer = await prisma.stockTransfer.create({ data: { number: `ST-${Date.now().toString().slice(-8)}`, fromWarehouseId: data.fromWarehouseId, toWarehouseId: data.toWarehouseId, notes: data.notes, requestedById: req.user!.sub, status: TransferStatus.REQUESTED, items: { create: data.items.map(item => ({ variantId: item.variantId, requestedQuantity: item.quantity })) } }, include: { items: true } });
    await audit(req.user!.sub, 'REQUEST', 'StockTransfer', transfer.id); return transfer;
  }
  @Post('transfers/approve') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async approveTransfer(@Body() body: unknown, @Req() req: AuthRequest) {
    const { transferId } = parse(z.object({ transferId: z.string().uuid() }), body); const row = await prisma.stockTransfer.findUnique({ where: { id: transferId } }); if (!row || row.status !== TransferStatus.REQUESTED) throw new BadRequestException('طلب التحويل غير متاح للاعتماد');
    const transfer = await prisma.stockTransfer.update({ where: { id: transferId }, data: { status: TransferStatus.APPROVED, approvedById: req.user!.sub, approvedAt: new Date() } }); await audit(req.user!.sub, 'APPROVE', 'StockTransfer', transferId); return transfer;
  }
  @Post('transfers/dispatch') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async dispatchTransfer(@Body() body: unknown, @Req() req: AuthRequest) {
    const { transferId } = parse(z.object({ transferId: z.string().uuid() }), body);
    const transfer = await prisma.$transaction(async tx => { const row = await tx.stockTransfer.findUnique({ where: { id: transferId }, include: { items: true } }); if (!row || row.status !== TransferStatus.APPROVED) throw new BadRequestException('التحويل غير متاح للشحن');
      for (const item of row.items) { const changed = await tx.stockBalance.updateMany({ where: { variantId: item.variantId, warehouseId: row.fromWarehouseId, quantity: { gte: item.requestedQuantity } }, data: { quantity: { decrement: item.requestedQuantity }, version: { increment: 1 } } }); if (!changed.count) throw new BadRequestException('رصيد المصدر غير كافٍ للشحن'); await tx.stockMovement.create({ data: { variantId: item.variantId, warehouseId: row.fromWarehouseId, quantity: -item.requestedQuantity, type: MovementType.ADJUSTMENT, reference: `TRANSFER-OUT:${row.number}`, createdById: req.user!.sub } }); }
      for (const item of row.items) await tx.stockTransferItem.update({ where: { stockTransferId_variantId: { stockTransferId: row.id, variantId: item.variantId } }, data: { sentQuantity: item.requestedQuantity } });
      return tx.stockTransfer.update({ where: { id: row.id }, data: { status: TransferStatus.IN_TRANSIT, shippedAt: new Date() } }); }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, 'DISPATCH', 'StockTransfer', transferId); return transfer;
  }
  @Post('transfers/receive') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT)) async receiveTransfer(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ transferId: z.string().uuid(), items: z.array(z.object({ variantId: z.string().uuid(), quantity: z.coerce.number().int().nonnegative() })).min(1) }), body);
    const transfer = await prisma.$transaction(async tx => { const row = await tx.stockTransfer.findUnique({ where: { id: data.transferId }, include: { items: true } }); if (!row || row.status !== TransferStatus.IN_TRANSIT) throw new BadRequestException('التحويل غير متاح للاستلام');
      for (const received of data.items) { const item = row.items.find(value => value.variantId === received.variantId); if (!item || received.quantity > (item.sentQuantity ?? 0)) throw new BadRequestException('كمية الاستلام غير صالحة'); await tx.stockBalance.upsert({ where: { variantId_warehouseId: { variantId: received.variantId, warehouseId: row.toWarehouseId } }, update: { quantity: { increment: received.quantity }, version: { increment: 1 } }, create: { variantId: received.variantId, warehouseId: row.toWarehouseId, quantity: received.quantity } }); await tx.stockTransferItem.update({ where: { stockTransferId_variantId: { stockTransferId: row.id, variantId: received.variantId } }, data: { receivedQuantity: received.quantity } }); await tx.stockMovement.create({ data: { variantId: received.variantId, warehouseId: row.toWarehouseId, quantity: received.quantity, type: MovementType.ADJUSTMENT, reference: `TRANSFER-IN:${row.number}`, createdById: req.user!.sub } }); }
      return tx.stockTransfer.update({ where: { id: row.id }, data: { status: TransferStatus.RECEIVED, receivedById: req.user!.sub, receivedAt: new Date() } }); }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, 'RECEIVE', 'StockTransfer', data.transferId); return transfer;
  }
}

@Controller('drawer') @UseGuards(JwtGuard)
class DrawerController {
  @Get('registers') @UseGuards(requirePermission('drawer.view')) async registers() { return prisma.register.findMany({ where: { branch: { isActive: true } }, include: { branch: true }, orderBy: { name: 'asc' } }); }
  private manager(req: AuthRequest) { return req.user!.role === RoleCode.OWNER || req.user!.role === RoleCode.ACCOUNTANT; }
  private async safeBalances() {
    const rows = await prisma.cashMovement.findMany({ where: { status: CashMovementStatus.APPROVED }, select: { type: true, amount: true, paymentMethod: true } });
    const wallets = Object.values(PaymentMethod).reduce((result, method) => ({ ...result, [method]: 0 }), {} as Record<PaymentMethod, number>);
    for (const row of rows) wallets[row.paymentMethod] = money(wallets[row.paymentMethod] + (row.type === CashMovementType.SAFE_WITHDRAWAL ? -Number(row.amount) : Number(row.amount)));
    return wallets;
  }
  private async safeBalance(method?: PaymentMethod) { const wallets = await this.safeBalances(); return method ? wallets[method] : money(Object.values(wallets).reduce((total, amount) => total + amount, 0)); }
  private async sessionDetails(sessionId: string) {
    const session = await prisma.drawerSession.findUnique({ where: { id: sessionId }, select: { userId: true, businessDate: true, openedAt: true, closedAt: true, openingAmount: true } });
    if (!session) throw new NotFoundException('الوردية غير موجودة');
    const [sales, returns, expenses] = await Promise.all([
      prisma.sale.findMany({ where: { drawerSessionId: sessionId }, select: { id: true, invoiceNo: true, total: true, status: true, createdAt: true, payments: { select: { method: true, amount: true } }, items: { select: { quantity: true, costAtSale: true } } }, orderBy: { createdAt: 'asc' } }),
      prisma.saleReturn.findMany({ where: { drawerSessionId: sessionId }, include: { sale: { select: { invoiceNo: true, customer: { select: { name: true } } } }, items: { include: { variant: { include: { product: true } }, saleItem: { select: { costAtSale: true } } } } }, orderBy: { createdAt: 'desc' } }),
      prisma.expense.findMany({ where: { OR: [{ drawerSessionId: sessionId }, { drawerSessionId: null, createdById: session.userId, occurredAt: { gte: session.openedAt, lte: session.closedAt ?? new Date() } }] }, orderBy: { occurredAt: 'desc' } }),
    ]);
    const summary = summarizeDrawer(session.openingAmount, sales, returns, expenses);
    const completedSales = sales.filter(sale => sale.status !== SaleStatus.CANCELLED);
    return { ...summary, sales: completedSales.map(sale => ({ ...sale, total: Number(sale.total), cashAmount: money(sale.payments.filter(payment => payment.method === PaymentMethod.CASH).reduce((sum, payment) => sum + Number(payment.amount), 0)) })), returns, expenses };
  }
  @Get('current') @UseGuards(requirePermission('drawer.view')) async current(@Req() req: AuthRequest) { return prisma.drawerSession.findFirst({ where: { userId: req.user!.sub, status: DrawerStatus.OPEN }, include: { register: true }, orderBy: { openedAt: 'desc' } }); }
  @Get('history') @UseGuards(requirePermission('drawer.view')) async history(@Req() req: AuthRequest) { const owner = this.manager(req); return prisma.drawerSession.findMany({ where: owner ? {} : { userId: req.user!.sub }, include: { register: true, cashMovements: { orderBy: { createdAt: 'desc' } } }, orderBy: { openedAt: 'desc' }, take: 50 }); }
  @Get('overview') @UseGuards(requirePermission('drawer.view')) async overview(@Req() req: AuthRequest) {
    const owner = this.manager(req); const manageSafe = await hasPermission(req.user!, 'drawer.safe.manage'); const where = owner ? {} : { userId: req.user!.sub };
    const [current, sessions, movements, wallets] = await Promise.all([
      prisma.drawerSession.findFirst({ where: { userId: req.user!.sub, status: DrawerStatus.OPEN }, include: { register: true }, orderBy: { openedAt: 'desc' } }),
      prisma.drawerSession.findMany({ where, include: { register: true, cashMovements: { orderBy: { createdAt: 'desc' } } }, orderBy: { openedAt: 'desc' }, take: 30 }),
      prisma.cashMovement.findMany({ where: owner ? {} : { requestedById: req.user!.sub }, orderBy: { createdAt: 'desc' }, take: 50 }),
      this.safeBalances()
    ]);
    const currentSummary = current ? await this.sessionDetails(current.id) : undefined;
    const sessionSummaries = await Promise.all(sessions.map(async session => ({ ...session, ...await this.sessionDetails(session.id) })));
    const userIds = [...new Set([...sessions.map(session => session.userId), ...(current ? [current.userId] : [])])]; const users = userIds.length ? await prisma.user.findMany({ where: { id: { in: userIds } }, select: { id: true, name: true } }) : []; const nameById = new Map(users.map(user => [user.id, user.name]));
    const withCashier = sessionSummaries.map(session => ({ ...session, user: { name: nameById.get(session.userId) || '—' } }));
    return { current: current ? { ...current, user: { name: nameById.get(current.userId) || '—' }, ...currentSummary } : null, wallets: manageSafe ? wallets : undefined, safeBalance: manageSafe ? money(Object.values(wallets).reduce((total, amount) => total + amount, 0)) : undefined, sessions: withCashier.filter(session => session.status === DrawerStatus.CLOSED), allSessions: withCashier, movements, pendingCount: movements.filter(movement => movement.status === CashMovementStatus.PENDING).length };
  }
  @Post('open') @UseGuards(requirePermission('drawer.open')) async open(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ registerId: z.string().uuid(), openingAmount: nonnegativeCurrency.pipe(z.number().max(1_000_000)) }), body);
    const [existingUser, existingRegister, register] = await Promise.all([prisma.drawerSession.findFirst({ where: { userId: req.user!.sub, status: DrawerStatus.OPEN } }), prisma.drawerSession.findFirst({ where: { registerId: data.registerId, status: DrawerStatus.OPEN } }), prisma.register.findUnique({ where: { id: data.registerId } })]);
    if (!register) throw new NotFoundException('الكاشير غير موجود');
    if (existingUser) throw new BadRequestException('لديك وردية مفتوحة بالفعل');
    if (existingRegister) throw new BadRequestException('هذا الكاشير لديه وردية مفتوحة بالفعل');
    const occurredAt = new Date(); const session = await prisma.$transaction(async tx => { const opened = await tx.drawerSession.create({ data: { registerId: data.registerId, userId: req.user!.sub, openingAmount: data.openingAmount, businessDate: businessDate(occurredAt) } }); if (data.openingAmount) await postSystemJournal(tx, req.user!.sub, `عهدة افتتاح درج ${register.name}`, 'DrawerSession', opened.id, [{ code: '1001', debit: data.openingAmount }, { code: '2101', credit: data.openingAmount }], occurredAt); return opened; });
    await audit(req.user!.sub, 'OPEN', 'DrawerSession', session.id, { openingAmount: data.openingAmount });
    return session;
  }
  @Post('close') @UseGuards(requirePermission('drawer.close')) async close(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ closingAmount: nonnegativeCurrency.pipe(z.number().max(1_000_000)) }), body);
    const session = await prisma.drawerSession.findFirst({ where: { userId: req.user!.sub, status: DrawerStatus.OPEN }, include: { register: true }, orderBy: { openedAt: 'desc' } });
    if (!session) throw new NotFoundException('لا توجد وردية مفتوحة لإغلاقها');
    const details = await this.sessionDetails(session.id);
    const expectedAmount = details.expectedAmount;
    const difference = money(data.closingAmount - expectedAmount);
    const occurredAt = new Date(); const closed = await prisma.$transaction(async tx => { const updated = await tx.drawerSession.update({ where: { id: session.id }, data: { closingAmount: data.closingAmount, expectedAmount, cashSalesTotal: details.cashSalesTotal, cashSalesCount: details.cashSalesCount, status: DrawerStatus.CLOSED, closedAt: occurredAt } }); if (difference < 0) await postSystemJournal(tx, req.user!.sub, `عجز درج ${session.register.name}`, 'DrawerSession', session.id, [{ code: '6100', debit: Math.abs(difference) }, { code: '1001', credit: Math.abs(difference) }], occurredAt); if (difference > 0) await postSystemJournal(tx, req.user!.sub, `زيادة درج ${session.register.name}`, 'DrawerSession', session.id, [{ code: '1001', debit: difference }, { code: '4100', credit: difference }], occurredAt); return updated; });
    await audit(req.user!.sub, 'CLOSE', 'DrawerSession', closed.id, { closingAmount: data.closingAmount, expectedAmount, difference, cashSalesTotal: details.cashSalesTotal, cashExpenseTotal: details.cashExpenseTotal, cashSalesCount: details.cashSalesCount });
    return { session: closed, ...details, expectedAmount, difference };
  }
  @Post('transfer-to-safe') @UseGuards(requirePermission('drawer.transfer')) async transferToSafe(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ drawerSessionId: z.string().uuid(), reason: z.string().min(3).max(240) }), body);
    const session = await prisma.drawerSession.findUnique({ where: { id: data.drawerSessionId } });
    if (!session || session.status !== DrawerStatus.CLOSED) throw new BadRequestException('لا يمكن توريد درج غير مقفل');
    if (!this.manager(req) && session.userId !== req.user!.sub) throw new ForbiddenException('لا تملك صلاحية توريد هذا الدرج');
    const details = await this.sessionDetails(session.id); const targetTotals: Record<PaymentMethod, number> = { [PaymentMethod.CASH]: Number(session.closingAmount ?? 0), [PaymentMethod.CARD]: Number(details.paymentTotals[PaymentMethod.CARD] || 0), [PaymentMethod.VODAFONE_CASH]: Number(details.paymentTotals[PaymentMethod.VODAFONE_CASH] || 0), [PaymentMethod.INSTAPAY]: Number(details.paymentTotals[PaymentMethod.INSTAPAY] || 0) };
    for (const method of Object.values(PaymentMethod)) if (method !== PaymentMethod.CASH) targetTotals[method] = money(Math.max(0, Number(targetTotals[method] || 0) - Number(details.expenseTotals[method] || 0)));
    const immediate = this.manager(req); const occurredAt = new Date(); const movements = await prisma.$transaction(async tx => { await tx.$queryRaw`SELECT "id" FROM "DrawerSession" WHERE "id" = ${session.id} FOR UPDATE`; const existing = await tx.cashMovement.findMany({ where: { drawerSessionId: session.id, type: CashMovementType.DRAWER_TO_SAFE, status: { in: [CashMovementStatus.PENDING, CashMovementStatus.APPROVED] } }, select: { paymentMethod: true, amount: true } }); const alreadyTransferred = Object.values(PaymentMethod).reduce((result, method) => ({ ...result, [method]: 0 }), {} as Record<PaymentMethod, number>); for (const movement of existing) alreadyTransferred[movement.paymentMethod] = money(alreadyTransferred[movement.paymentMethod] + Number(movement.amount)); const transfers = Object.values(PaymentMethod).map(method => ({ paymentMethod: method, amount: money(targetTotals[method] - alreadyTransferred[method]) })).filter(row => row.amount > 0.009); if (!transfers.length) throw new BadRequestException('تم توريد جميع أرصدة هذه الوردية بالفعل'); const created = []; for (const row of transfers) { const movement = await tx.cashMovement.create({ data: { number: `TR-${Date.now().toString().slice(-8)}-${Math.floor(Math.random() * 900 + 100)}`, type: CashMovementType.DRAWER_TO_SAFE, status: immediate ? CashMovementStatus.APPROVED : CashMovementStatus.PENDING, amount: row.amount, paymentMethod: row.paymentMethod, reason: data.reason, drawerSessionId: session.id, requestedById: req.user!.sub, approvedById: immediate ? req.user!.sub : undefined, approvedAt: immediate ? occurredAt : undefined, businessDate: businessDate(occurredAt) } }); if (immediate) await postSystemJournal(tx, req.user!.sub, `توريد درج ${session.id.slice(0, 8)} — ${movement.paymentMethod}`, 'CashMovement', movement.id, cashMovementJournalLines(movement), occurredAt); created.push(movement); } return created; });
    await audit(req.user!.sub, 'DRAWER_TO_SAFE', 'DrawerSession', session.id, { movements: movements.map(movement => ({ paymentMethod: movement.paymentMethod, amount: movement.amount, status: movement.status })) }); return { movements, status: immediate ? CashMovementStatus.APPROVED : CashMovementStatus.PENDING };
  }
  @Post('safe/deposit') @UseGuards(requirePermission('drawer.safe.manage')) async deposit(@Body() body: unknown, @Req() req: AuthRequest) { return this.createSafeMovement(CashMovementType.SAFE_DEPOSIT, body, req); }
  @Post('safe/withdraw') @UseGuards(requirePermission('drawer.safe.manage')) async withdraw(@Body() body: unknown, @Req() req: AuthRequest) { return this.createSafeMovement(CashMovementType.SAFE_WITHDRAWAL, body, req); }
  private async createSafeMovement(type: CashMovementType, body: unknown, req: AuthRequest) {
    const data = parse(z.object({ businessDay: z.string().optional(), source: z.enum(['GENERAL','OWNER_CAPITAL']).default('GENERAL'), amount: positiveCurrency.pipe(z.number().max(1_000_000)), paymentMethod: z.nativeEnum(PaymentMethod), reason: z.string().min(3).max(240) }), body); const immediate = this.manager(req); if (data.source === 'OWNER_CAPITAL' && (req.user!.role !== RoleCode.OWNER || type !== CashMovementType.SAFE_DEPOSIT || !immediate)) throw new ForbiddenException('تمويل رأس المال متاح لإيداع المالك فقط'); const day = selectedBusinessDate(data.businessDay, req.user!);
    const occurredAt = new Date(); const movement = await prisma.$transaction(async tx => { await ensureOpenBusinessDate(tx, day); if (data.source === 'OWNER_CAPITAL') { const capital = await tx.account.findUnique({ where: { code: '3001' } }); if (!capital || capital.type !== 'EQUITY' || !capital.active) throw new BadRequestException('حساب رأس مال المالك غير مهيأ بصورة صحيحة'); } if (type === CashMovementType.SAFE_WITHDRAWAL && immediate) { const walletRows = await tx.cashMovement.findMany({ where: { status: CashMovementStatus.APPROVED, paymentMethod: data.paymentMethod }, select: { type: true, amount: true } }); if (data.amount > safeWalletBalance(walletRows)) throw new BadRequestException('رصيد وسيلة الدفع المختارة لا يكفي لهذا السحب'); } const created = await tx.cashMovement.create({ data: { number: `${type === CashMovementType.SAFE_DEPOSIT ? 'DEP' : 'WDR'}-${Date.now().toString().slice(-8)}-${Math.floor(Math.random() * 900 + 100)}`, type, status: immediate ? CashMovementStatus.APPROVED : CashMovementStatus.PENDING, amount: data.amount, paymentMethod: data.paymentMethod, reason: data.reason, requestedById: req.user!.sub, approvedById: immediate ? req.user!.sub : undefined, approvedAt: immediate ? occurredAt : undefined, businessDate: day } }); if (immediate) await postSystemJournal(tx, req.user!.sub, `${type === CashMovementType.SAFE_DEPOSIT ? 'إيداع خزنة' : 'سحب خزنة'} — ${created.paymentMethod}`, 'CashMovement', created.id, cashMovementJournalLines(created, data.source === 'OWNER_CAPITAL'), occurredAt, day); return created; }, { isolationLevel: 'Serializable' });
    await audit(req.user!.sub, type, 'CashMovement', movement.id, { amount: data.amount, paymentMethod: data.paymentMethod, status: movement.status, source: data.source, businessDay: day.toISOString().slice(0, 10) }); return movement;
  }
  @Post('movements/:id/approve') @UseGuards(requirePermission('drawer.safe.manage')) async approve(@Param('id') id: string, @Req() req: AuthRequest) {
    const result = await prisma.$transaction(async tx => { const movement = await tx.cashMovement.findUnique({ where: { id } }); if (!movement || movement.status !== CashMovementStatus.PENDING) throw new BadRequestException('الطلب غير متاح للاعتماد'); if (movement.type === CashMovementType.SAFE_WITHDRAWAL) { const approved = await tx.cashMovement.findMany({ where: { status: CashMovementStatus.APPROVED, paymentMethod: movement.paymentMethod }, select: { type: true, amount: true } }); if (Number(movement.amount) > safeWalletBalance(approved)) throw new BadRequestException('رصيد وسيلة الدفع المختارة لا يكفي لاعتماد السحب'); } const occurredAt = new Date(); const approved = await tx.cashMovement.update({ where: { id }, data: { status: CashMovementStatus.APPROVED, approvedById: req.user!.sub, approvedAt: occurredAt, businessDate: businessDate(occurredAt) } }); const advanceLines = approved.type === CashMovementType.SAFE_WITHDRAWAL && approved.purchaseAdvanceId ? [{ code: '1210', debit: Number(approved.amount) }, { code: paymentAccount(approved.paymentMethod), credit: Number(approved.amount) }] : cashMovementJournalLines(approved); await postSystemJournal(tx, req.user!.sub, `اعتماد حركة خزنة ${approved.number}`, approved.purchaseAdvanceId ? 'PurchaseAdvance' : 'CashMovement', approved.purchaseAdvanceId || approved.id, advanceLines, occurredAt); return approved; }, { isolationLevel: 'Serializable' }); await audit(req.user!.sub, 'APPROVE', 'CashMovement', result.id, { type: result.type, amount: result.amount, paymentMethod: result.paymentMethod }); return result;
  }
}

@Controller('accounts') @UseGuards(allow(RoleCode.OWNER, RoleCode.ACCOUNTANT))
class AccountsController {
  @Get() async accounts() { return prisma.account.findMany({ orderBy: { code: 'asc' } }); }
  @Post() async createAccount(@Body() body: unknown, @Req() req: AuthRequest) { const data = parse(z.object({ code: z.string().min(2).max(30), name: z.string().min(2).max(100), type: z.enum(['ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE']) }), body); const account = await prisma.account.create({ data }); await audit(req.user!.sub, 'CREATE', 'Account', account.id, data); return account; }
  @Get('journal-entries') async entries() { return prisma.journalEntry.findMany({ include: { lines: { include: { account: true } } }, orderBy: { occurredAt: 'desc' }, take: 150 }); }
  @Post('journal-entries') async journal(@Body() body: unknown, @Req() req: AuthRequest) {
    const data = parse(z.object({ occurredAt: z.coerce.date().optional(), description: z.string().min(3).max(300), referenceType: z.string().max(60).optional(), referenceId: z.string().max(100).optional(), lines: z.array(z.object({ accountId: z.string().uuid(), debit: nonnegativeCurrency.default(0), credit: nonnegativeCurrency.default(0), description: z.string().max(200).optional() }).refine(line => (line.debit > 0) !== (line.credit > 0))).min(2) }), body);
    const debit = money(data.lines.reduce((sum, line) => sum + (line.debit ?? 0), 0)); const credit = money(data.lines.reduce((sum, line) => sum + (line.credit ?? 0), 0)); if (debit !== credit) throw new BadRequestException('القيد غير متوازن: المدين يجب أن يساوي الدائن');
    const occurredAt = data.occurredAt ?? new Date(); const day = businessDate(occurredAt); const closed = await prisma.fiscalPeriod.findFirst({ where: { status: 'CLOSED', startsAt: { lte: day }, endsAt: { gte: day } } }); if (closed) throw new BadRequestException('لا يمكن الترحيل داخل فترة مالية مغلقة');
    const ids = data.lines.map(line => line.accountId); if ((await prisma.account.count({ where: { id: { in: ids }, active: true } })) !== new Set(ids).size) throw new BadRequestException('أحد الحسابات غير موجود أو غير نشط');
    const entry = await prisma.journalEntry.create({ data: { number: `JE-${Date.now().toString().slice(-8)}-${Math.floor(Math.random() * 900 + 100)}`, occurredAt, businessDate: day, description: data.description, referenceType: data.referenceType, referenceId: data.referenceId, createdById: req.user!.sub, lines: { create: data.lines } }, include: { lines: { include: { account: true } } } }); await audit(req.user!.sub, 'POST', 'JournalEntry', entry.id, { debit, credit }); return entry;
  }
  @Get('balances') async balances() { const rows = await prisma.account.findMany({ include: { journalLines: true }, orderBy: { code: 'asc' } }); return rows.map(account => ({ id: account.id, code: account.code, name: account.name, type: account.type, debit: money(account.journalLines.reduce((sum, line) => sum + Number(line.debit), 0)), credit: money(account.journalLines.reduce((sum, line) => sum + Number(line.credit), 0)) })); }
  @Get('periods') async periods() { return prisma.fiscalPeriod.findMany({ orderBy: { startsAt: 'desc' } }); }
  @Post('periods') async createPeriod(@Body() body: unknown, @Req() req: AuthRequest) { const data = parse(z.object({ name: z.string().min(3).max(60), startsAt: z.coerce.date(), endsAt: z.coerce.date() }).refine(value => value.endsAt > value.startsAt), body); const period = await prisma.fiscalPeriod.create({ data }); await audit(req.user!.sub, 'CREATE', 'FiscalPeriod', period.id); return period; }
  @Post('periods/close') @UseGuards(allow(RoleCode.OWNER)) async closePeriod(@Body() body: unknown, @Req() req: AuthRequest) { const { periodId } = parse(z.object({ periodId: z.string().uuid() }), body); const period = await prisma.fiscalPeriod.update({ where: { id: periodId }, data: { status: 'CLOSED', closedAt: new Date(), closedById: req.user!.sub } }); await audit(req.user!.sub, 'CLOSE', 'FiscalPeriod', periodId); return period; }
}

@Controller('governance') @UseGuards(allow(RoleCode.OWNER))
class GovernanceController {
  @Get('roles') async roles() { return prisma.role.findMany({ include: { permissions: { include: { permission: true } }, users: true }, orderBy: { code: 'asc' } }); }
  @Get('permissions') async permissions() { return prisma.permission.findMany({ orderBy: { code: 'asc' } }); }
  @Post('roles') async createRole(@Body() body: unknown, @Req() req: AuthRequest) { const data = parse(z.object({ code: z.string().min(2).max(50), name: z.string().min(2).max(100), permissionIds: z.array(z.string().uuid()).default([]) }), body); const role = await prisma.role.create({ data: { code: data.code, name: data.name, permissions: { create: (data.permissionIds ?? []).map(permissionId => ({ permissionId })) } }, include: { permissions: true } }); await audit(req.user!.sub, 'CREATE', 'Role', role.id, { code: data.code }); return role; }
  @Post('roles/:roleId/permissions') async replaceRolePermissions(@Param('roleId') roleId: string, @Body() body: unknown, @Req() req: AuthRequest) { const data = parse(z.object({ permissionIds: z.array(z.string().uuid()) }), body); const role = await prisma.role.findUnique({ where: { id: roleId } }); if (!role) throw new NotFoundException('الدور غير موجود'); await prisma.$transaction([prisma.rolePermission.deleteMany({ where: { roleId } }), prisma.rolePermission.createMany({ data: [...new Set(data.permissionIds)].map(permissionId => ({ roleId, permissionId })) })]); await audit(req.user!.sub, 'UPDATE_PERMISSIONS', 'Role', roleId, { permissionCount: data.permissionIds.length }); return prisma.role.findUnique({ where: { id: roleId }, include: { permissions: { include: { permission: true } } } }); }
  @Post('users/roles') async assignRole(@Body() body: unknown, @Req() req: AuthRequest) { const data = parse(z.object({ userId: z.string().uuid(), roleId: z.string().uuid() }), body); const assignment = await prisma.userRole.upsert({ where: { userId_roleId: data }, update: {}, create: data }); await audit(req.user!.sub, 'ASSIGN_ROLE', 'User', data.userId, { roleId: data.roleId }); return assignment; }
  @Get('audit') async auditLog() { return prisma.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: 300 }); }
}

@Controller('uploads') @UseGuards(JwtGuard)
class UploadsController {
  @Get() @UseGuards(requirePermission('products.view')) async list(@Query('entityType') entityType?: string, @Query('entityId') entityId?: string) { if (!entityType || !entityId) throw new BadRequestException('حدد نوع ومعرف الكيان'); return prisma.attachment.findMany({ where: { entityType, entityId }, orderBy: { createdAt: 'desc' } }); }
  @UseGuards(requirePermission('products.create'))
  @Post() @UseInterceptors(FileInterceptor('file', { storage: diskStorage({ destination: env('UPLOAD_DIR', 'uploads'), filename: (_req: any, file: any, callback: any) => callback(null, `${randomUUID()}${extname(file.originalname).toLowerCase()}`) }), limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (_req: any, file: any, callback: any) => callback(null, ['image/jpeg','image/png','image/webp','application/pdf'].includes(file.mimetype)) })) async upload(@UploadedFile() file: any, @Body() body: unknown, @Req() req: AuthRequest) {
    if (!file) throw new BadRequestException('الملف غير مدعوم؛ ارفع صورة JPG/PNG/WebP أو PDF بحجم 5MB كحد أقصى'); const data = parse(z.object({ entityType: z.string().min(2).max(50), entityId: z.string().uuid() }), body);
    const attachment = await prisma.attachment.create({ data: { ...data, fileName: file.filename, originalName: file.originalname, mimeType: file.mimetype, size: file.size, createdById: req.user!.sub } }); await audit(req.user!.sub, 'UPLOAD', data.entityType, data.entityId, { attachmentId: attachment.id }); return attachment;
  }
  @Get(':id') @UseGuards(requirePermission('products.view')) async download(@Param('id') id: string, @Res() res: any) { const attachment = await prisma.attachment.findUnique({ where: { id } }); if (!attachment) throw new NotFoundException('المرفق غير موجود'); return res.type(attachment.mimeType).sendFile(attachment.fileName, { root: env('UPLOAD_DIR', 'uploads') }); }
}

@Controller('health')
class HealthController {
  @Get() async health() { await prisma.$queryRaw`SELECT 1`; return { status: 'ok', timestamp: new Date().toISOString() }; }
  @Get('live') live() { return { status: 'live' }; }
  @Get('ready') async ready() { await prisma.$queryRaw`SELECT 1`; return { status: 'ready' }; }
}

@Controller('dashboard') @UseGuards(requirePermission('dashboard.view'))
class DashboardController {
  @Get() async summary() { const day = businessDate(); const [sales, refunds, lowStock, productCount] = await Promise.all([prisma.sale.aggregate({ where: { businessDate: day, status: { not: SaleStatus.CANCELLED } }, _sum: { total: true }, _count: true }), prisma.saleReturn.aggregate({ where: { businessDate: day }, _sum: { total: true } }), prisma.stockBalance.count({ where: { quantity: { lte: 3 } } }), prisma.product.count({ where: { deletedAt: null } })]); return { businessDate: day, todaySales: money(Number(sales._sum.total ?? 0) - Number(refunds._sum.total ?? 0)), saleCount: sales._count, lowStock, productCount }; }
}
async function audit(userId: string, action: string, entity: string, entityId: string, payload?: object) { await prisma.auditLog.create({ data: { userId, action, entity, entityId, payload } }); }

@Catch()
class JsonErrorFilter implements ExceptionFilter {
  private readonly logger = new Logger('HTTP');
  catch(exception: unknown, host: ArgumentsHost) {
    const context = host.switchToHttp(); const response = context.getResponse<any>(); const request = context.getRequest<Request & { id?: string }>();
    const status = exception instanceof HttpException ? exception.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR;
    const raw = exception instanceof HttpException ? exception.getResponse() : undefined; const message = typeof raw === 'object' && raw && 'message' in raw ? (raw as any).message : exception instanceof Error ? exception.message : 'حدث خطأ غير متوقع';
    const requestId = randomUUID(); const entry = JSON.stringify({ requestId, method: request.method, path: request.url, status, message });
    if (status >= HttpStatus.INTERNAL_SERVER_ERROR) this.logger.error(entry); else this.logger.warn(entry);
    response.status(status).json({ statusCode: status, message: status === 500 ? 'حدث خطأ داخلي في الخادم' : message, requestId, timestamp: new Date().toISOString() });
  }
}

@Module({ controllers: [AuthController, CatalogController, CustomerController, UsersController, PurchasesController, ExpensesController, ImportsController, ReportsController, PosController, InventoryController, DrawerController, AccountsController, GovernanceController, UploadsController, HealthController, DashboardController], providers: [JwtGuard] }) class AppModule implements NestModule { configure() {} }
async function seed() {
  const email = env('SEED_OWNER_EMAIL', 'owner@draft.local'); let owner = await prisma.user.findUnique({ where: { email } }); if (!owner) owner = await prisma.user.create({ data: { email, name: 'مالك DRAFT', role: RoleCode.OWNER, passwordHash: await argon2.hash(env('SEED_OWNER_PASSWORD', 'ChangeMe123!')) } });
  const branch = await prisma.branch.upsert({ where: { code: 'MAIN' }, update: {}, create: { name: 'الفرع الرئيسي', code: 'MAIN' } }); const warehouse = await prisma.warehouse.upsert({ where: { code: 'MAIN-WH' }, update: {}, create: { name: 'المخزن الرئيسي', code: 'MAIN-WH', branchId: branch.id } }); await prisma.register.upsert({ where: { code: 'POS-01' }, update: {}, create: { name: 'كاشير 1', code: 'POS-01', branchId: branch.id } });
  for (const account of [{ code: '1000', name: 'الخزنة النقدية', type: 'ASSET' }, { code: '1001', name: 'نقدية الدرج', type: 'ASSET' }, { code: '1010', name: 'البطاقات والمحافظ', type: 'ASSET' }, { code: '1011', name: 'تسويات البطاقات البنكية', type: 'ASSET' }, { code: '1012', name: 'محفظة Vodafone Cash', type: 'ASSET' }, { code: '1013', name: 'محفظة InstaPay', type: 'ASSET' }, { code: '1100', name: 'ذمم أوردرات الشحن', type: 'ASSET' }, { code: '1111', name: 'تحصيل بطاقات لدى الدرج', type: 'ASSET' }, { code: '1112', name: 'تحصيل Vodafone Cash لدى الدرج', type: 'ASSET' }, { code: '1113', name: 'تحصيل InstaPay لدى الدرج', type: 'ASSET' }, { code: '1200', name: 'المخزون', type: 'ASSET' }, { code: '1210', name: 'عهد مشتريات غير مسواة', type: 'ASSET' }, { code: '2000', name: 'ذمم الموردين', type: 'LIABILITY' }, { code: '2100', name: 'مقاصة استبدالات العملاء', type: 'LIABILITY' }, { code: '2101', name: 'مقاصة تمويل وسحب الخزنة', type: 'LIABILITY' }, { code: '2200', name: 'مستحقات أصحاب بضاعة الأمانة', type: 'LIABILITY' }, { code: '4000', name: 'إيرادات المبيعات', type: 'REVENUE' }, { code: '4100', name: 'زيادة الجرد النقدي', type: 'REVENUE' }, { code: '5000', name: 'تكلفة البضاعة المباعة', type: 'EXPENSE' }, { code: '6000', name: 'مصروفات التشغيل', type: 'EXPENSE' }, { code: '6100', name: 'عجز الجرد النقدي', type: 'EXPENSE' }]) await prisma.account.upsert({ where: { code: account.code }, update: { name: account.name, type: account.type }, create: account });
  await prisma.account.upsert({ where: { code: '3001' }, update: {}, create: { code: '3001', name: 'رأس مال المالك', type: 'EQUITY' } });
  const permissions = ['dashboard.view','pos.use','sales.view','sales.create','sales.cancel','sales.return','sales.exchange','products.view','products.create','products.view_cost','inventory.view','inventory.adjust','inventory.approve','expenses.view','expenses.create','suppliers.manage','reports.view','reports.export','drawer.view','drawer.open','drawer.close','drawer.transfer','drawer.safe.manage','settings.manage','users.manage','audit.view'];
  for (const code of permissions) await prisma.permission.upsert({ where: { code }, update: {}, create: { code, name: code } });
  const roleDefaults: Record<RoleCode, { name: string; permissions: string[] }> = {
    [RoleCode.OWNER]: { name: 'المالك', permissions },
    [RoleCode.ACCOUNTANT]: { name: 'المحاسب', permissions: permissions.filter(code => !['users.manage'].includes(code)) },
    [RoleCode.CASHIER]: { name: 'كاشير محدود', permissions: ['pos.use','sales.view','sales.create','products.view','products.view_cost','expenses.view','expenses.create','drawer.view','drawer.open','drawer.close','drawer.transfer'] }
  };
  for (const code of Object.values(RoleCode)) {
    const config = roleDefaults[code]; const role = await prisma.role.upsert({ where: { code }, update: { name: config.name, system: true }, create: { code, name: config.name, system: true } });
    const permissionRows = await prisma.permission.findMany({ where: { code: { in: config.permissions } }, select: { id: true } }); await prisma.rolePermission.createMany({ data: permissionRows.map(permission => ({ roleId: role.id, permissionId: permission.id })), skipDuplicates: true });
  }
  const users = await prisma.user.findMany({ select: { id: true, role: true } }); const roles = await prisma.role.findMany({ where: { code: { in: Object.values(RoleCode) } }, select: { id: true, code: true } }); const roleByCode = new Map(roles.map(role => [role.code, role.id])); await prisma.userRole.createMany({ data: users.map(user => ({ userId: user.id, roleId: roleByCode.get(user.role)! })).filter(item => item.roleId), skipDuplicates: true }); return warehouse;
}
async function bootstrap() { await prisma.$connect(); await seed(); const app = await NestFactory.create(AppModule, { logger: ['error', 'warn', 'log'] }); app.useGlobalFilters(new JsonErrorFilter()); app.enableCors({ origin: env('CORS_ORIGIN', 'http://localhost:5173'), credentials: true }); if (env('NODE_ENV') !== 'production' || env('ENABLE_API_DOCS') === 'true') { const config = new DocumentBuilder().setTitle('DRAFT POS API').setDescription('واجهة REST لنظام DRAFT').setVersion('1.0').addBearerAuth().build(); SwaggerModule.setup('api/docs', app, SwaggerModule.createDocument(app, config)); } await app.listen(Number(env('PORT', '3000')), env('LISTEN_HOST', '0.0.0.0')); }
void bootstrap();
