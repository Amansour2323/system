import assert from 'node:assert/strict';
const base = 'http://127.0.0.1:13089';
if (process.env.E2E_PRODUCT_EDIT_ISOLATED !== '1') throw new Error('Requires explicitly isolated product edit test');
async function request(path, body, token) {
  const response = await fetch(base + path, { method: body === undefined ? 'GET' : 'POST', headers: { ...(body === undefined ? {} : {'content-type':'application/json'}), ...(token ? {authorization:`Bearer ${token}`} : {}) }, ...(body === undefined ? {} : {body:JSON.stringify(body)}) });
  return {status:response.status, data:await response.json()};
}
const login = await request('/auth/login',{email:'product-edit-test@draft.local',password:'Product-Edit-Test-Only-123!'});
assert.equal(login.status,201); const token=login.data.accessToken;
const context=await request('/pos/context',undefined,token); assert.equal(context.status,200);
const suffix=Date.now().toString();
const created=await request('/catalog/products',{name:'Edit test product',sku:`EDIT-${suffix}`,variants:[{name:'M',barcode:`EDIT${suffix}`,price:100,cost:40,openingQty:10,warehouseId:context.data.warehouseId}]},token);
assert.equal(created.status,201);const id=created.data.variants[0].id;
const input={name:'Edited product',sku:`UPDATED-${suffix}`,categoryId:null,price:150,cost:60,warehouseId:context.data.warehouseId,expectedQuantity:10,quantity:8,reason:'E2E inventory correction'};
const edited=await request(`/catalog/variants/${id}/edit`,input,token);assert.equal(edited.status,201,JSON.stringify(edited.data));
const rows=await request('/catalog/products',undefined,token);const product=rows.data.find(p=>p.id===created.data.id);assert.equal(product.name,input.name);assert.equal(product.sku,input.sku);assert.equal(Number(product.variants[0].price),150);assert.equal(Number(product.variants[0].cost),60);assert.equal(product.variants[0].balances[0].quantity,8);
const moves=await request('/inventory/movements',undefined,token);assert(moves.data.some(m=>m.variantId===id&&m.quantity===-2&&m.reference===input.reason));
const entries=await request('/accounts/journal-entries',undefined,token);const entry=entries.data.find(e=>e.referenceType==='InventoryCostAdjustment'&&e.description.includes(input.reason));assert(entry);assert.equal(entry.lines.reduce((s,l)=>s+Number(l.debit),0),entry.lines.reduce((s,l)=>s+Number(l.credit),0));
const stale=await request(`/catalog/variants/${id}/edit`,{...input,quantity:7},token);assert.equal(stale.status,400);
const negative=await request(`/catalog/variants/${id}/edit`,{...input,expectedQuantity:8,quantity:-1},token);assert.equal(negative.status,400);
const fresh=await request('/catalog/products',undefined,token);assert.equal(fresh.data.find(p=>p.id===created.data.id).variants[0].balances[0].quantity,8);
console.log('PASS: edit, quantity, inventory movement, balanced journal, stale and negative rejection');
