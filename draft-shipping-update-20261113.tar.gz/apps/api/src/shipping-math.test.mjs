import assert from 'node:assert/strict';
import { test } from 'node:test';
import { courierRemittance, shippingReturnValue, shippingSettlement, shippingCharges, shippingItemDiscount } from './shipping-math.ts';

test('returns use net discounted line price and preserve cents across partial returns', () => {
  assert.equal(shippingReturnValue(1800, 2, 0, 1, 0), 900);
  assert.equal(shippingReturnValue(1800, 2, 0, 2, 0), 1800);
  const a = shippingReturnValue(100, 3, 0, 1, 0);
  const b = shippingReturnValue(100, 3, 1, 1, a);
  const c = shippingReturnValue(100, 3, 2, 1, a + b);
  assert.equal(Math.round((a + b + c) * 100), 10000);
  assert.throws(() => shippingReturnValue(100, 3, 2, 2, 0));
  assert.throws(() => shippingReturnValue(100, 3, 1, 1, 90));
});

test('free shipping can have separate carrier and packaging costs', () => {
  assert.deepEqual(shippingCharges(0, 75, 12.5), { customerFee: 0, carrierCost: 87.5 });
  assert.deepEqual(shippingCharges(80, 75, 12.5), { customerFee: 80, carrierCost: 87.5 });
  assert.throws(() => shippingCharges(0, -1, 0));
  assert.throws(() => shippingCharges(0, 0.001, 0));
});

test('courier settlement deducts shipping and packaging without touching the till early', () => {
  assert.deepEqual(courierRemittance(1200, 80, 20), { collected: 1200, costs: 100, netReceivable: 1100, outstandingCourierCost: 0 });
  assert.deepEqual(courierRemittance(0, 80, 20), { collected: 0, costs: 100, netReceivable: 0, outstandingCourierCost: 100 });
  assert.deepEqual(courierRemittance(80, 80, 0), { collected: 80, costs: 80, netReceivable: 0, outstandingCourierCost: 0 });
  assert.throws(() => courierRemittance(100, -1, 0));
});

test('defect discounts are limited to the retained value of the specified item', () => {
  assert.deepEqual(shippingItemDiscount(900, 450, 100), { discount: 100, retainedValue: 350 });
  assert.throws(() => shippingItemDiscount(900, 450, 451));
  assert.throws(() => shippingItemDiscount(900, 901, 0));
});

test('partial and full returns only refund what was actually prepaid', () => {
  assert.deepEqual(shippingSettlement(1800, 500, 1800, 0, 0), { priorDue: 1300, due: 0, refund: 500 });
  assert.deepEqual(shippingSettlement(1800, 500, 900, 0, 0), { priorDue: 1300, due: 400, refund: 0 });
  assert.deepEqual(shippingSettlement(1800, 1800, 900, 0, 0), { priorDue: 0, due: 0, refund: 900 });
  assert.deepEqual(shippingSettlement(1800, 500, 900, 200, 300), { priorDue: 1300, due: 300, refund: 0 });
  assert.throws(() => shippingSettlement(1800, 500, 900, 0, 401));
});

test('consignment return allocations preserve the owner entitlement and store commission', () => {
  const firstValue = shippingReturnValue(300, 3, 0, 1, 0);
  const firstOwner = shippingReturnValue(240, 3, 0, 1, 0);
  assert.equal(firstValue, 100);
  assert.equal(firstOwner, 80);
  assert.equal(firstValue - firstOwner, 20);
  const lastValue = shippingReturnValue(300, 3, 1, 2, firstValue);
  const lastOwner = shippingReturnValue(240, 3, 1, 2, firstOwner);
  assert.equal(lastValue, 200);
  assert.equal(lastOwner, 160);
  assert.equal(lastValue - lastOwner, 40);
});
