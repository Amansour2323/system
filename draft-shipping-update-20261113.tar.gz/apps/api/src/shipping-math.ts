const cents = (value: number) => Math.round((value + Number.EPSILON) * 100);

/** Allocate the original net line amount by cumulative quantity, preserving cents. */
export function shippingReturnValue(total: number, quantity: number, returned: number, requested: number, priorValue: number): number {
  if (!Number.isInteger(quantity) || quantity <= 0 || !Number.isInteger(returned) || !Number.isInteger(requested) || requested <= 0 || returned < 0 || returned + requested > quantity) throw new Error('Invalid return quantity');
  const target = Math.round(cents(total) * (returned + requested) / quantity);
  const result = target - cents(priorValue);
  if (result < 0 || result > cents(total) - cents(priorValue)) throw new Error('Previous return value exceeds the original sale line');
  return result / 100;
}

export function shippingSettlement(netTotal: number, netPaid: number, returned: number, replacement: number, collected: number) {
  const before = cents(netTotal) - cents(netPaid);
  const after = before + cents(replacement) - cents(returned);
  if (cents(collected) > Math.max(0, after)) throw new Error('Collection exceeds balance');
  return { priorDue: Math.max(0, before) / 100, due: Math.max(0, after - cents(collected)) / 100, refund: Math.max(0, -after) / 100 };
}

/** Shipping fees charged to the customer are separate from the carrier's cost. */
export function shippingCharges(customerFee: number, carrierFee: number, packagingFee: number) {
  const values = [customerFee, carrierFee, packagingFee];
  if (values.some(value => !Number.isFinite(value) || value < 0 || Math.abs(value * 100 - Math.round(value * 100)) > 0.00001)) throw new Error('Invalid shipping charge');
  return { customerFee: cents(customerFee) / 100, carrierCost: (cents(carrierFee) + cents(packagingFee)) / 100 };
}

/** An item-specific discount cannot exceed the value of units kept by the customer. */
export function shippingItemDiscount(lineNet: number, returnedValue: number, discount: number) {
  if ([lineNet, returnedValue, discount].some(value => !Number.isFinite(value) || value < 0 || Math.abs(value * 100 - Math.round(value * 100)) > 0.00001)) throw new Error('Invalid adjustment');
  const remaining = cents(lineNet) - cents(returnedValue);
  if (remaining < 0 || cents(discount) > remaining) throw new Error('Discount exceeds retained item value');
  return { discount: cents(discount) / 100, retainedValue: (remaining - cents(discount)) / 100 };
}

/** Net amount expected from a courier after it withholds its shipping and packaging fees. */
export function courierRemittance(collected: number, carrierFee: number, packagingFee: number) {
  const values = [collected, carrierFee, packagingFee];
  if (values.some(value => !Number.isFinite(value) || value < 0 || Math.abs(value * 100 - Math.round(value * 100)) > 0.00001)) throw new Error('Invalid courier settlement');
  const collectedCents = cents(collected);
  const costCents = cents(carrierFee) + cents(packagingFee);
  return {
    collected: collectedCents / 100,
    costs: costCents / 100,
    netReceivable: Math.max(0, collectedCents - costCents) / 100,
    outstandingCourierCost: Math.max(0, costCents - collectedCents) / 100
  };
}
