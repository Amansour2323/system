CREATE TABLE "ShippingOutcome" (
  "id" TEXT NOT NULL,
  "saleId" TEXT NOT NULL,
  "customerShippingFee" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "carrierShippingCost" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "packagingCost" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "courierCollected" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "courierReference" TEXT,
  "settledAmount" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "settlementMethod" "PaymentMethod",
  "settlementReference" TEXT,
  "settledAt" TIMESTAMP(3),
  "createdById" TEXT NOT NULL,
  "businessDate" DATE NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ShippingOutcome_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "ShippingOutcome_saleId_key" ON "ShippingOutcome"("saleId");
CREATE INDEX "ShippingOutcome_businessDate_settledAt_idx" ON "ShippingOutcome"("businessDate", "settledAt");
ALTER TABLE "ShippingOutcome" ADD CONSTRAINT "ShippingOutcome_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES "Sale"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "ShippingItemAdjustment" (
  "id" TEXT NOT NULL,
  "shippingOutcomeId" TEXT NOT NULL,
  "saleItemId" TEXT NOT NULL,
  "amount" DECIMAL(12,2) NOT NULL,
  "storeRevenueReduction" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "ownerPayoutReduction" DECIMAL(12,2) NOT NULL DEFAULT 0,
  "reason" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ShippingItemAdjustment_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "ShippingItemAdjustment_shippingOutcomeId_saleItemId_key" ON "ShippingItemAdjustment"("shippingOutcomeId", "saleItemId");
CREATE INDEX "ShippingItemAdjustment_saleItemId_idx" ON "ShippingItemAdjustment"("saleItemId");
ALTER TABLE "ShippingItemAdjustment" ADD CONSTRAINT "ShippingItemAdjustment_shippingOutcomeId_fkey" FOREIGN KEY ("shippingOutcomeId") REFERENCES "ShippingOutcome"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ShippingItemAdjustment" ADD CONSTRAINT "ShippingItemAdjustment_saleItemId_fkey" FOREIGN KEY ("saleItemId") REFERENCES "SaleItem"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

INSERT INTO "Account" ("id", "code", "name", "type", "active")
VALUES
  (gen_random_uuid()::text, '1120', 'تحصيلات لدى شركات الشحن', 'ASSET', true),
  (gen_random_uuid()::text, '2102', 'مستحقات شركات الشحن', 'LIABILITY', true),
  (gen_random_uuid()::text, '4010', 'إيرادات شحن العملاء', 'REVENUE', true),
  (gen_random_uuid()::text, '6010', 'تكلفة الشحن والتغليف', 'EXPENSE', true)
ON CONFLICT ("code") DO UPDATE SET "name" = EXCLUDED."name", "type" = EXCLUDED."type", "active" = true;
