export function getBusinessDate(at = new Date(), timezone = 'Africa/Cairo', rolloverHour = 1): Date {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(at);
  const value = (type: string) => parts.find(part => part.type === type)?.value || '';
  const date = new Date(Date.UTC(Number(value('year')), Number(value('month')) - 1, Number(value('day'))));
  if (Number(value('hour')) < rolloverHour) date.setUTCDate(date.getUTCDate() - 1);
  return date;
}

/** Parse an explicitly selected business day without applying a timezone rollover. */
export function parseBusinessDay(value: string): Date {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error('Invalid business date');
  const parsed = new Date(`${value}T00:00:00.000Z`);
  if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value) throw new Error('Invalid business date');
  return parsed;
}
