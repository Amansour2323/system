import test from 'node:test';
import assert from 'node:assert/strict';
import { getBusinessDate, parseBusinessDay } from './business-day.ts';

const day = at => getBusinessDate(new Date(at)).toISOString().slice(0, 10);

test('business day keeps late-night transactions with the previous day before 01:00 Cairo', () => {
  assert.equal(day('2026-09-30T21:30:00.000Z'), '2026-09-30'); // 00:30 Cairo
  assert.equal(day('2026-09-30T21:59:59.999Z'), '2026-09-30'); // 00:59:59 Cairo
});

test('business day rolls forward at 01:00 Cairo, not before', () => {
  assert.equal(day('2026-09-30T22:00:00.000Z'), '2026-10-01'); // 01:00 Cairo
  assert.equal(day('2026-09-30T09:00:00.000Z'), '2026-09-30'); // noon Cairo
});

test('explicit business date is preserved without timezone rollover', () => {
  assert.equal(parseBusinessDay('2026-10-31').toISOString(), '2026-10-31T00:00:00.000Z');
  for (const value of ['2026-02-30', '2026-13-01', '2026-10-1', 'not-a-date']) assert.throws(() => parseBusinessDay(value));
});
