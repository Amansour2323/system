import assert from 'node:assert/strict';
import { test } from 'node:test';
import { CashMovementType, PaymentMethod } from '@prisma/client';
import { cashMovementJournalLines, drawerPaymentAccount, paymentAccount, paymentJournalLines } from './cash-accounting.ts';

const wallets = [PaymentMethod.CASH, PaymentMethod.CARD, PaymentMethod.VODAFONE_CASH, PaymentMethod.INSTAPAY];
const total = (lines, side) => Math.round(lines.reduce((sum, line) => sum + (line[side] ?? 0), 0) * 100) / 100;

test('توريد كل وسيلة دفع ينقل القيمة من درجها إلى محفظتها فقط', () => {
  for (const paymentMethod of wallets) {
    const lines = cashMovementJournalLines({ type: CashMovementType.DRAWER_TO_SAFE, paymentMethod, amount: '149.75' });
    assert.deepEqual(lines, [{ code: paymentAccount(paymentMethod), debit: 149.75 }, { code: drawerPaymentAccount(paymentMethod), credit: 149.75 }]);
    assert.equal(total(lines, 'debit'), total(lines, 'credit'));
  }
});

test('الإيداع والسحب يوازنان محفظة الخزنة مع حساب المقاصة', () => {
  for (const paymentMethod of wallets) {
    const deposit = cashMovementJournalLines({ type: CashMovementType.SAFE_DEPOSIT, paymentMethod, amount: 50 });
    const withdrawal = cashMovementJournalLines({ type: CashMovementType.SAFE_WITHDRAWAL, paymentMethod, amount: 20 });
    assert.deepEqual(deposit, [{ code: paymentAccount(paymentMethod), debit: 50 }, { code: '2101', credit: 50 }]);
    assert.deepEqual(withdrawal, [{ code: '2101', debit: 20 }, { code: paymentAccount(paymentMethod), credit: 20 }]);
  }
});

test('إيداع رأس مال المالك لا يُسجّل إيرادًا أو مقاصة', () => {
  const lines = cashMovementJournalLines({ type: CashMovementType.SAFE_DEPOSIT, paymentMethod: PaymentMethod.CASH, amount: 113000 }, true);
  assert.deepEqual(lines, [{ code: '1000', debit: 113000 }, { code: '3001', credit: 113000 }]);
  assert.equal(total(lines, 'debit'), total(lines, 'credit'));
  assert.throws(() => cashMovementJournalLines({ type: CashMovementType.SAFE_WITHDRAWAL, paymentMethod: PaymentMethod.CASH, amount: 10 }, true));
});

test('يُقرب قيود الدفع إلى أقرب قرش بطريقة متماثلة', () => {
  const lines = paymentJournalLines([{ method: PaymentMethod.CASH, amount: 1.005 }], 'debit');
  assert.equal(lines[0].debit, 1.01);
});
