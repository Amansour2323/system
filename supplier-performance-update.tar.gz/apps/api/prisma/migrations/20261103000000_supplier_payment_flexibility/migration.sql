ALTER TABLE "Supplier" ADD COLUMN "paymentFlexibility" INTEGER,
ADD COLUMN "creditTermDays" INTEGER,
ADD COLUMN "paymentNotes" TEXT;
ALTER TABLE "Supplier" ADD CONSTRAINT "Supplier_paymentFlexibility_check" CHECK ("paymentFlexibility" IS NULL OR "paymentFlexibility" BETWEEN 1 AND 5),
ADD CONSTRAINT "Supplier_creditTermDays_check" CHECK ("creditTermDays" IS NULL OR "creditTermDays" BETWEEN 0 AND 3650);
