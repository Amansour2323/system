import test from 'node:test';
import assert from 'node:assert/strict';
import { buildSupplierPerformance } from './supplier-performance.ts';

test('uses sale snapshot cost, discounted totals, returns and recorded consignment payout', () => {
  const suppliers = [{ id:'a', name:'A' }, { id:'b', name:'B' }];
  const lines = [
    { quantity:3,total:270,costAtSale:50,ownerSupplierId:null,ownerPayout:0,variant:{product:{supplierId:'a'}},returnItems:[{quantity:1,total:90,ownerPayout:0}] },
    { quantity:2,total:200,costAtSale:0,ownerSupplierId:'b',ownerPayout:160,variant:{product:{supplierId:'a'}},returnItems:[{quantity:1,total:100,ownerPayout:80}] },
    { quantity:1,total:30,costAtSale:10,ownerSupplierId:null,ownerPayout:0,variant:{product:{supplierId:null}},returnItems:[] }
  ];
  const out=buildSupplierPerformance(suppliers,lines,[{supplierId:'a',paymentTerms:'CASH'},{supplierId:'a',paymentTerms:'CREDIT'}]);
  assert.deepEqual(out.suppliers[0],{id:'a',name:'A',sales:180,profit:80,units:2,cashInvoices:1,creditInvoices:1});
  assert.deepEqual(out.suppliers[1],{id:'b',name:'B',sales:100,profit:20,units:1,cashInvoices:0,creditInvoices:0});
  assert.equal(out.unassignedLines,1);
});
