type MoneyValue = number | string | { toString(): string };
export type PerformanceLine = { quantity: number; total: MoneyValue; costAtSale: MoneyValue; ownerSupplierId: string | null; ownerPayout: MoneyValue; variant: { product: { supplierId: string | null } }; returnItems: { quantity: number; total: MoneyValue; ownerPayout: MoneyValue }[] };
type Supplier = { id: string; name: string; paymentFlexibility?: number | null; creditTermDays?: number | null; paymentNotes?: string | null };
type Purchase = { supplierId: string; paymentTerms: string };
const round = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;
export function buildSupplierPerformance(suppliers: Supplier[], lines: PerformanceLine[], purchases: Purchase[]) {
  const totals = new Map(suppliers.map(s => [s.id, { ...s, sales: 0, profit: 0, units: 0, cashInvoices: 0, creditInvoices: 0 }]));
  let unassignedLines = 0;
  for (const line of lines) {
    const supplierId = line.ownerSupplierId || line.variant.product.supplierId;
    const row = supplierId ? totals.get(supplierId) : undefined;
    if (!row) { unassignedLines++; continue; }
    const returnedQuantity = line.returnItems.reduce((sum, item) => sum + item.quantity, 0);
    const netSales = Number(line.total) - line.returnItems.reduce((sum, item) => sum + Number(item.total), 0);
    const netPayout = Number(line.ownerPayout) - line.returnItems.reduce((sum, item) => sum + Number(item.ownerPayout), 0);
    row.units += line.quantity - returnedQuantity;
    row.sales += netSales;
    row.profit += netSales - (line.quantity - returnedQuantity) * Number(line.costAtSale) - netPayout;
  }
  for (const purchase of purchases) { const row = totals.get(purchase.supplierId); if (row) { if (purchase.paymentTerms === 'CASH') row.cashInvoices++; else if (purchase.paymentTerms === 'CREDIT') row.creditInvoices++; } }
  return { suppliers: [...totals.values()].map(row => ({ ...row, sales: round(row.sales), profit: round(row.profit) })), unassignedLines };
}
