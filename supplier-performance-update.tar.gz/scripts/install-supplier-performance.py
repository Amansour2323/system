from pathlib import Path
import shutil, sys

target = Path(sys.argv[1]).resolve()
payload = Path(sys.argv[2]).resolve()
api = target / 'apps/api/src/main.ts'
schema = target / 'apps/api/prisma/schema.prisma'
web = target / 'apps/web/src/main.tsx'
a, s, w = (p.read_text(encoding='utf8') for p in (api, schema, web))
method = (payload / 'scripts/supplier-performance-endpoint.txt').read_text(encoding='utf8') + '\n'
if not method.startswith("  @Get('supplier-performance')") or "updateSupplierPerformance" not in method:
    raise SystemExit('Bad feature payload')
if a.count('class ReportsController {') != 1 or 'supplier-performance' in a:
    raise SystemExit('API anchor mismatch; no changes applied')
if s.count('model Supplier {') != 1 or 'paymentFlexibility' in s:
    raise SystemExit('Schema anchor mismatch; no changes applied')
checks = ["import { SupplierManagementPage } from './supplier-management';", "suppliers:'suppliers.manage',purchases:", "const canPage=(user:User,page:string)=>{const needed=pagePermission[page];", "['suppliers','الموردون',Truck],['purchases'", 'suppliers:<SupplierManagementPage/>,purchases:']
if any(w.count(x) != 1 for x in checks) or 'supplierPerformance' in w:
    raise SystemExit('Web anchor mismatch; no changes applied')
import_line = "import { buildSupplierPerformance } from './supplier-performance.js';\n"
a = import_line + a
a = a.replace('class ReportsController {\n', 'class ReportsController {\n' + method, 1)
start = s.index('model Supplier {')
end = s.index('\n}', start)
part = s[start:end]
if part.count(' notes String?') != 1:
    raise SystemExit('Supplier schema anchor mismatch')
part = part.replace(' notes String?', ' notes String?\n paymentFlexibility Int?\n creditTermDays Int?\n paymentNotes String?', 1)
s = s[:start] + part + s[end:]
w = w.replace(checks[0], checks[0] + "\nimport { SupplierPerformancePage } from './supplier-performance';", 1)
w = w.replace(checks[1], "suppliers:'suppliers.manage',supplierPerformance:'reports.view',purchases:", 1)
w = w.replace(checks[2], "const canPage=(user:User,page:string)=>{if(page==='supplierPerformance') return can(user,'reports.view') && can(user,'suppliers.manage'); const needed=pagePermission[page];", 1)
w = w.replace(checks[3], "['suppliers','الموردون',Truck],['supplierPerformance','أداء الموردين',BarChart3],['purchases'", 1)
w = w.replace(checks[4], 'suppliers:<SupplierManagementPage/>,supplierPerformance:<SupplierPerformancePage/>,purchases:', 1)
paths = ['apps/api/src/supplier-performance.ts', 'apps/api/src/supplier-performance.test.mjs', 'apps/api/prisma/migrations/20261103000000_supplier_payment_flexibility/migration.sql', 'apps/web/src/supplier-performance.tsx', 'apps/web/src/supplier-performance.css']
for name in paths:
    dest = target / name
    if dest.exists(): raise SystemExit('Feature destination exists: ' + name)
for path, content in ((api,a),(schema,s),(web,w)):
    path.write_text(content, encoding='utf8')
for name in paths:
    dest = target / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(payload / name, dest)
print('Feature applied to', target)
